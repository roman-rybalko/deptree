#!/bin/sh
java -jar `dirname $0`/AXMLPrinter2.jar "$@"
