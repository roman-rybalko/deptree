#!/bin/sh
java -jar `dirname $0`/smali-1.3.2.jar "$@"
