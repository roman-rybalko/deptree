package com.emilio.jdc.core.operation.expr;

/**
 * 
 * @author Emilio Liang
 *
 */
public class SyncEnterExpr implements Expression{
    
    public String toText(){
        return null;
    }

}
