package com.emilio.jdc.core;

import static com.emilio.jdc.core.type.ConstantType.CONSTANT_Double;
import static com.emilio.jdc.core.type.ConstantType.CONSTANT_Long;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.emilio.jdc.core.constant.Constant;
import com.emilio.jdc.core.constant.ConstantClass;
import com.emilio.jdc.core.constant.ConstantDouble;
import com.emilio.jdc.core.constant.ConstantFieldRef;
import com.emilio.jdc.core.constant.ConstantFloat;
import com.emilio.jdc.core.constant.ConstantInteger;
import com.emilio.jdc.core.constant.ConstantInterfaceMethodRef;
import com.emilio.jdc.core.constant.ConstantLong;
import com.emilio.jdc.core.constant.ConstantMethodRef;
import com.emilio.jdc.core.constant.ConstantNameAndType;
import com.emilio.jdc.core.constant.ConstantString;
import com.emilio.jdc.core.constant.ConstantUtf8;
import com.emilio.jdc.core.exception.BadFormatException;
import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.operation.expr.ListExpression;
import com.emilio.jdc.core.type.ConstantType;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent constant pool structure in class file.
 *
 */
public class ConstantPoolInfo implements LoadableInfo, ResolvableInfo, ListExpression {
    private Map<Integer,Constant> pool = new TreeMap<Integer,Constant>();
    

    /**
     * Default Constructor
     */
    public ConstantPoolInfo(){
    }
    
    /**
     * @param cis
     */
    public void load(ClassInputStream cis) throws IOException {
        int cpSize = cis.readU2();

        for (int index = 1; index < cpSize; index++) {
            int tag = cis.readU1();
            
            ConstantType type = ConstantType.of(tag);

            pool.put(index,loadConstant(index, type, cis));
            
            //For double and long cost two index in row
            if (type == CONSTANT_Double || type == CONSTANT_Long) {
                ++index;
            }
        }
    }
    
    /**
     * 
     * loadConstant
     * @param index
     * @param type
     * @param cis
     * @return Constant
     * @throws IOException
     */
    private Constant loadConstant(int index, ConstantType type, ClassInputStream cis)
            throws IOException {
        Constant cpItem = null;
        switch (type) {
        case CONSTANT_Utf8:
            cpItem = new ConstantUtf8(index, type);
            break;
        case CONSTANT_Integer:
            cpItem = new ConstantInteger(index, type);
            break;
        case CONSTANT_Float:
            cpItem = new ConstantFloat(index, type);
            break;
        case CONSTANT_Long:
            cpItem = new ConstantLong(index, type);
            break;
        case CONSTANT_Double:
            cpItem = new ConstantDouble(index, type);
            break;
        case CONSTANT_Class:
            cpItem = new ConstantClass(index, type);
            break;
        case CONSTANT_String:
            cpItem = new ConstantString(index, type);
            break;
        case CONSTANT_Fieldref:
            cpItem = new ConstantFieldRef(index, type);
            break;
        case CONSTANT_Methodref:
            cpItem = new ConstantMethodRef(index, type);
            break;
        case CONSTANT_InterfaceMethodref:
            cpItem = new ConstantInterfaceMethodRef(index, type);
            break;
        case CONSTANT_NameAndType:
            cpItem = new ConstantNameAndType(index, type);
            break;
        default:
            throw new BadFormatException(
                    "Invalid constant pool item type=%s,position=%s", type, cis
                            .getReadBytes());
        }

        cpItem.load(cis);
        return cpItem;
    }

    /**
     * @param clazz
     */
    public void resolve(Class clazz) {
        ConstantPoolInfo pool = clazz.getPoolInfo();
        
        Collection<Constant> list =  pool.getConstantPool();
        Iterator<Constant> it = list.iterator();
        while(it.hasNext()){
            Constant constant= it.next();
            
            if(! constant.isResolved()){
                constant.resolve(clazz);
                
                //Avoid resolve twice
                constant.setResolved(true);
            }
        }
    }

    /**
     * 
     * @return Collection<Constant>
     */
    private Collection<Constant> getConstantPool() {
        return Collections.unmodifiableCollection(pool.values());
    }

    /**
     * 
     * @param index
     * @return Constant
     */
    public Constant getContantPoolItem(int index) {
        return pool.get(index);
    }
    
    /**
     * 
     */
    public List<Expression> listExpressions(){
        //TODO
        List<Expression> list = new ArrayList<Expression>();
        for (Constant c: pool.values()){
            list.add(c);
        }
        
        return list;
    }
    
    @Override
    public String toString() {
        return String.format("[%s:poolSize=%d]", 
                this.getClass().getSimpleName(),
                pool.size());
    }
}
