package com.emilio.jdc.core.attribute;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.LazyLoadableInfo;
import com.emilio.jdc.core.ResolvableInfo;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class ExceptionTable implements LazyLoadableInfo, ResolvableInfo {
    private int exceptionCount;
    private List<ExceptionTableEntry> exceptions = new ArrayList<ExceptionTableEntry>();

    /**
     * Constructor
     */
    public ExceptionTable() {
    }
    
    /**
     * @param cis
     */
    public void load(ClassInputStream cis) throws IOException {
        exceptionCount = cis.readU2();

        if (exceptionCount > 0) {
            for (int i = 0; i < exceptionCount; i++) {
                exceptions.add(new ExceptionTableEntry());
                exceptions.get(i).load(cis);
            }
        }
    }
    
    /**
     * @param clazz
     */
    public void resolve(Class clazz) throws IOException {
        for (ExceptionTableEntry exTable :exceptions){
            exTable.resolve(clazz);
        }
    }
    
    /**
     * 
     * @return List<ExceptionTableEntry>
     */
    public List<ExceptionTableEntry> getExceptionTableList(){
        return Collections.unmodifiableList(exceptions);
    }

    @Override
    public String toString() {
        return String.format("[%s:exceptionCount=%d,exceptions=%s]", this
                .getClass().getSimpleName(), exceptionCount, exceptions);
    }

}
