package com.emilio.jdc.core.exception;

/**
 * 
 * @author Emilio Liang
 *
 */
public class ResolveException extends RuntimeException {
    /**
     * serialVersionUID used to identify the version of the serializable object
     */
    private static final long serialVersionUID = 8841053606293651586L;
    private static final String DEFAULT_MESSAGE = "Class format validation error";

    public ResolveException() {
        this(DEFAULT_MESSAGE);
    }

    public ResolveException(String message) {
        super(message);
    }

    public ResolveException(String message, Throwable cause) {
        super(message, cause);
    }

    public ResolveException(Throwable cause) {
        super(cause);
    }
}
