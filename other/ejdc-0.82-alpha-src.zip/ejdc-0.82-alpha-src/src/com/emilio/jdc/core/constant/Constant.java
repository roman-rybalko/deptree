package com.emilio.jdc.core.constant;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.LoadableInfo;
import com.emilio.jdc.core.ResolvableInfo;
import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.type.ConstantType;
import com.emilio.jdc.core.type.ObjectType;
import com.emilio.jdc.core.type.Value;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 * 
 * Parent class for all constant pool entry 
 */
public abstract class Constant implements LoadableInfo, ResolvableInfo, Value, Expression {
    private boolean isResolved = false;
    final int index;
    final ConstantType type;

    /**
     * Constructor
     * 
     * @param index
     * @param tag
     */
    Constant(int index, ConstantType type) {
        this.index = index;
        this.type = type;
    }

    /**
     * @param cis
     */
    public abstract void load(ClassInputStream cis) throws IOException;

    /**
     * @param clazz
     */
    public abstract void resolve(Class clazz);

    /**
     * 
     */
    public abstract String getValue();

    /**
     * Get the index of constant entry
     * @return int 
     */
    public abstract int getIndex();

    /**
     * 
     * @return
     */
    public boolean isResolved(){
        return isResolved;
    }
    
    /**
     * 
     * @param isResolved
     */
    public void setResolved(boolean isResolved) {
        this.isResolved = isResolved;
    }

    String getClassName() {
        return this.getClass().getSimpleName();
    }

    
    public ObjectType getType(){
        return ObjectType.STRING;
    }
    
    public ConstantType getConstantType(){
        return type;
    }
    
    public String toText(){
        return type.toString();
    }

    @Override
    public String toString() {
        return String.format("[%s:index=%d,type=%s]", this.getClass()
                .getSimpleName(), index, type);
    }

}