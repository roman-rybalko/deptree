package com.emilio.jdc.core.attribute;

import java.io.IOException;

import com.emilio.jdc.core.Class;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class Deprecated extends AttributeInfoItem {

    /**
     * 
     * @param item
     */
    public Deprecated(AttributeInfoItem item) {
        super(item);
    }
    
    /**
     * 
     */
    public Deprecated() {
        super();
    }

    @Override
    public AttributeInfoItem resolve(Class pool) throws IOException {
        return this;
    }
}
