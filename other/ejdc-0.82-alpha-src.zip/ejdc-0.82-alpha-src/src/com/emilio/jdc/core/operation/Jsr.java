package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Jsr extends Operation {
    private long targetIndex;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public Jsr(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }

    @Override
    public void parseParams() {
        int offset = 0;
        switch (getOP()) {
        case JSR:
            offset = mergeSignedBytes(parameters[ZERO],parameters[ONE]);
            break;
        case JSR_W:
            offset = mergeSignedBytes(parameters[ZERO],parameters[ONE],parameters[TWO],parameters[THREE]);
            break;
        }
        
        targetIndex = this.getByteIndex() + offset;
        
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){       
    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:offset=%d]", this
                        .getClass().getSimpleName(),targetIndex);
    }
    
}
