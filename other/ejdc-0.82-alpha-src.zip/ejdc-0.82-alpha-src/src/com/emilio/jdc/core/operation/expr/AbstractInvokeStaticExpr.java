package com.emilio.jdc.core.operation.expr;

/**
 * 
 * @author Emilio Liang
 *
 */
public abstract class AbstractInvokeStaticExpr extends AbstractInvokeExpr{
    protected String fullClassName;

    public String toText(){
        StringBuilder buffer = new StringBuilder();
        
        buffer.append(LEFT_PARENTHESIS);
        
        //buffer.append(Jimple.STATICINVOKE + " " + methodRef.getSignature() + "(");
        buffer.append(fullClassName);
        buffer.append(DOT);        
        buffer.append(methodName);
        buffer.append(LEFT_PARENTHESIS);
        
        for(int i = 0; i < arguments.size(); i++){
            if(i != 0){
                buffer.append(", ");
            }

            buffer.append(arguments.get(i).getValue());
        }

        buffer.append(RIGHT_PARENTHESIS);
        buffer.append(RIGHT_PARENTHESIS);

        return buffer.toString();
    }
}
