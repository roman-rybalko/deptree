package com.emilio.jdc.core.constant;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.type.ConstantType;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 * 
 * Parent class for all constant ref type 
 * 
 */
abstract class ConstantRefType extends Constant {
    protected int classIndex;
    protected int nameTypeIndex;
    protected ConstantClass refClass;
    protected ConstantNameAndType refNameAndType; 

    /**
     * Constructor
     * 
     * @param index
     * @param type
     */
    public ConstantRefType(int index, ConstantType type) {
        super(index, type);
    }

    @Override
    public void load(ClassInputStream cis) throws IOException {
        classIndex = cis.readU2();
        nameTypeIndex = cis.readU2();
    }

    @Override
    public void resolve(Class clazz) {
        ConstantPoolInfo pool = clazz.getPoolInfo();
        refClass = (ConstantClass)pool.getContantPoolItem(classIndex);
        
        refClass.resolve(clazz);
        
        refNameAndType = (ConstantNameAndType)pool.getContantPoolItem(nameTypeIndex);
        
        refNameAndType.resolve(clazz);
        
    }

    /**
     * 
     * @return
     */
    public ConstantClass getRefClass() {
        return refClass;
    }

    /**
     * 
     * @return
     */
    public String getName(){
        return refNameAndType.getValue();
    }
    
    /**
     * 
     * @return
     */
    public ConstantNameAndType getRefNameAndType() {
        return refNameAndType;
    }

    @Override
    public String getValue() {
        return null;
    }

    @Override
    public int getIndex() {
        return nameTypeIndex;
    }

    @Override
    public String toString() {
        return String.format(
                "[%s:index=%d,type=%s,classIndex=%d,nameTypeIndex=%d]", 
                this.getClass().getSimpleName(),
                index,
                type,
                classIndex,
                nameTypeIndex);
    }

}
