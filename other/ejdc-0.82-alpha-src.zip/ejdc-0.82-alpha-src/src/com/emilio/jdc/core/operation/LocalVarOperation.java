package com.emilio.jdc.core.operation;

import com.emilio.jdc.core.attribute.LocalVariableInfo;

/**
 * 
 * @author Emilio Liang
 *
 */
public interface LocalVarOperation {
    public int getVarNum();
    public LocalVariableInfo getLocalVariable();
}
