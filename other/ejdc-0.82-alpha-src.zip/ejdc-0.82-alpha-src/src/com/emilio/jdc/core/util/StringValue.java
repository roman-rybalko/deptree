package com.emilio.jdc.core.util;

import com.emilio.jdc.core.type.ObjectType;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 * 
 * Wrapper class for string, wrapped string will be treated as a Value class 
 *
 */
public class StringValue implements Value {
    private String value;
    
    public static Value valueOf(String value){
        return new StringValue(value);
    }
    
    private StringValue(String value){
        this.value = value;
    }
    

    public ObjectType getType() {
        // TODO Auto-generated method stub
        return null;
    }

    public Object getValue() {
        // TODO Auto-generated method stub
        return value;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }
}
