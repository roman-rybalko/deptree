package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.util.OperandStack;
import com.emilio.jdc.decompile.structure.Loop;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Goto extends Operation {
    private int targetIndex;
    private boolean isContinue;
    private boolean isBreak;
    private Loop loop;

    public Goto(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }

    @Override
    public void mergeStack(OperandStack<Operation> stack,
            LocalVariableTable table) {
        // TODO Auto-generated method stub
    }
    
    public void parseParams() {
        int offset = 0;
        switch (getOP()) {
        case GOTO:
            offset = mergeSignedBytes(parameters[ZERO],parameters[ONE]);
            break;
        case GOTO_W:
            offset = mergeSignedBytes(parameters[ZERO],parameters[ONE],parameters[TWO],parameters[THREE]);
            break;
        }
        
        targetIndex = super.getByteIndex() + offset;
    }
    
    /**
     * 
     * @return
     */
    public int getTargetIndex() {
        return targetIndex;
    }
    
    public Loop getLoop() {
        return loop;
    }

    public void setLoop(Loop loop) {
        this.loop = loop;
    }
    
    public boolean isContinue() {
        return isContinue;
    }

    public void setContinue(boolean isContinue) {
        this.isContinue = isContinue;
    }
    
    public boolean isBreak() {
        return isBreak;
    }

    public void setBreak(boolean isBreak) {
        this.isBreak = isBreak;
    }

    /**
     * 
     * @return
     */
    public boolean isForward(){
        //TODO remove duplicate loop method
        return targetIndex > super.getByteIndex();
    }

}
