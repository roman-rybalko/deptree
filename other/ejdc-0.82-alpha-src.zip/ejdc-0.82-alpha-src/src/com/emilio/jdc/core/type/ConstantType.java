package com.emilio.jdc.core.type;

import java.util.HashMap;
import java.util.Map;

import com.emilio.jdc.core.constant.ConstantClass;
import com.emilio.jdc.core.constant.ConstantDouble;
import com.emilio.jdc.core.constant.ConstantFieldRef;
import com.emilio.jdc.core.constant.ConstantFloat;
import com.emilio.jdc.core.constant.ConstantInteger;
import com.emilio.jdc.core.constant.ConstantInterfaceMethodRef;
import com.emilio.jdc.core.constant.ConstantLong;
import com.emilio.jdc.core.constant.ConstantMethodRef;
import com.emilio.jdc.core.constant.ConstantNameAndType;
import com.emilio.jdc.core.constant.ConstantString;
import com.emilio.jdc.core.constant.ConstantUtf8;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum ConstantType {
    CONSTANT_Utf8(1,ConstantUtf8.class),
    CONSTANT_Integer(3,ConstantInteger.class),
    CONSTANT_Float(4,ConstantFloat.class),
    CONSTANT_Long(5,ConstantLong.class),
    CONSTANT_Double(6,ConstantDouble.class),
    CONSTANT_Class(7,ConstantClass.class),
    CONSTANT_String(8,ConstantString.class),
    CONSTANT_Fieldref(9,ConstantFieldRef.class),
    CONSTANT_Methodref(10,ConstantMethodRef.class),
    CONSTANT_InterfaceMethodref(11,ConstantInterfaceMethodRef.class),
    CONSTANT_NameAndType(12,ConstantNameAndType.class);
    
    private final int tag;
    private final Class<?> clazz;
    
    private static final Map<Integer,ConstantType> MAP = new HashMap<Integer,ConstantType>();
    
    static{
        for(ConstantType type: ConstantType.values()){
            MAP.put(type.tag, type);
        }
    }
    
    /**
     * Constructor
     * @param tag
     * @param clazz
     */
    private ConstantType(int tag,Class<?> clazz){
        this.tag = tag;
        this.clazz = clazz;
    }
    
    public static ConstantType of(int type){
        return MAP.get(type);
    }
    
    public int getTag(){
        return tag;
    }
    
    public Class<?> getClassType(){
        return clazz;
    }
}
