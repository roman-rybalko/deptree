package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.OperatorsType;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public abstract class AbstractUniOpExpr implements UniOpExpr {
    protected Value value;
    protected OperatorsType operatorSymbol;

    public abstract String toText();

    /**
     * 
     */
    public Value getOp() {
        return value;
    }

    /**
     * 
     */
    public void setOp(Value value) {
        this.value = value;
    }
    
    String getOperatorSymbol() {
        return operatorSymbol.toString();
    }
}
