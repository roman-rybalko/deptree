package com.emilio.jdc.core.operation;

import java.util.ArrayList;
import java.util.List;

import com.emilio.jdc.core.MethodDescriptor;
import com.emilio.jdc.core.ReturnDescriptor;
import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.constant.ConstantClass;
import com.emilio.jdc.core.constant.ConstantInterfaceMethodRef;
import com.emilio.jdc.core.constant.ConstantMethodRef;
import com.emilio.jdc.core.constant.ConstantNameAndType;
import com.emilio.jdc.core.operation.expr.InvokeInterfaceExpr;
import com.emilio.jdc.core.operation.expr.InvokeStaticExpr;
import com.emilio.jdc.core.type.ConstantType;
import com.emilio.jdc.core.type.Value;
import com.emilio.jdc.core.util.OperandStack;
import com.emilio.jdc.core.util.TypeSafeMap;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Invoke extends Operation{
    private static final String INIT_METHOD =  "<init>";
    private int index;
    private int argNum;
    private ConstantInterfaceMethodRef interfaceMethodRef;
    private ConstantMethodRef methodRef;
    private ConstantNameAndType nameAndType;
    //private MethodInfoItem method;
    private ConstantType type;
    private SpecialInvokeType staticType;
    private MethodDescriptor methodDesc;
    private ReturnDescriptor returnDesc;
    private String methodName;
    private TypeSafeMap map = new TypeSafeMap();
    private List<Value> methodParams = new ArrayList<Value>();
    
    public enum SpecialInvokeType {
        SUPER, INIT, PRIVATE;
    }

    /**
     * 
     * @param byteCode
     * @param index
     * @param code
     */
    public Invoke(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }

    @Override
    public void parseParams() {
        index = mergeUnsignedBytes(parameters[ZERO],parameters[ONE]);

        switch(getOP()){
        case INVOKEVIRTUAL:
        case INVOKESPECIAL:
            methodRef = (ConstantMethodRef)context.getConstantPoolInfo().getContantPoolItem(index);
            methodName = methodRef.getName();
            type = methodRef.getConstantType(); 
            map.put(type.getClassType(), methodRef); 
            methodDesc = methodRef.getMethodDescriptor();
           
            ConstantClass refClass = methodRef.getRefClass();
            
            ConstantClass thisClass = context.getClazz().getClassInfo().getThisClass();
            
            if(methodName.equals(INIT_METHOD)){
                staticType = SpecialInvokeType.INIT;
            }else if(refClass.equals(thisClass)){
                staticType = SpecialInvokeType.SUPER;
            }else{
                staticType = SpecialInvokeType.PRIVATE;
            }

            break;
        case INVOKESTATIC:
            methodRef = (ConstantMethodRef)context.getConstantPoolInfo().getContantPoolItem(index);
            methodName = methodRef.getName();
            type = methodRef.getConstantType(); 
            map.put(type.getClassType(), methodRef); 
            methodDesc = methodRef.getMethodDescriptor();
            break;
        case INVOKEDYNAMIC:
            nameAndType = (ConstantNameAndType)context.getConstantPoolInfo().getContantPoolItem(index);
            methodName = nameAndType.getName();
            type = nameAndType.getConstantType();
            methodDesc = new MethodDescriptor();
            methodDesc.parse(nameAndType.getDescriptor());
            map.put(type.getClassType(), nameAndType);  
            break;
        case INVOKEINTERFACE:
            argNum = parameters[TWO];
            interfaceMethodRef = (ConstantInterfaceMethodRef)context.getConstantPoolInfo().getContantPoolItem(index);
            methodDesc = interfaceMethodRef.getMethodDescriptor();
            methodName = interfaceMethodRef.getName();
            type = interfaceMethodRef.getConstantType();
            map.put(type.getClassType(), interfaceMethodRef);   
        }
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        switch(getOP()){
        case INVOKEVIRTUAL:
        case INVOKESPECIAL:
            //TODO
            //invokeSpecial(stack);
            //break;
        case INVOKESTATIC:
            invokeStatic(stack);
            break;
        case INVOKEDYNAMIC:
            break;
        case INVOKEINTERFACE:
            invokeInterface(stack);
            break;
        }
        
        returnDesc = methodDesc.getReturnType();
        
        if(!returnDesc.isVoid()){
            stack.push(this);
        }
    }
    
    public ReturnDescriptor getReturnDescriptor(){
        return returnDesc;
    }
    
    /**
     * 
     * @param stack
     */
    private void invokeStatic(OperandStack<Operation> stack){
        popParameters(stack);
        expr = InvokeStaticExpr.of(methodRef.getRefClass().getName(), methodName, methodParams);        
    }
    
    /**
     * 
     * @param stack
     */
    private void invokeInterface(OperandStack<Operation> stack){
        popParameters(stack);
        
        expr = InvokeInterfaceExpr.of(stack.pop(), methodName, methodParams);
    }
    
    /**
     * 
     * @param stack
     */
//    private void invokeSpecial(OperandStack<Operation> stack){
//        popParameters(stack);
//        
//        expr = InvokeSpecialExpr.of(stack.pop(), methodName, methodParams, staticType);
//    }
    
    /**
     * 
     * @param stack
     */
    private void popParameters(OperandStack<Operation> stack){
        for (int i = 0; i < methodDesc.getParamNum(); i++) {
            methodParams.add(stack.pop());
        }
    }
    
    public SpecialInvokeType getStaticType(){
        return staticType;
    }
    
//    @Override
//    public void resolve(MethodInfoItem method){
//        this.method = method;
//    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:byteCode=%d,index=%d,argNum=%d,methodRef=%s,interfaceMethodRef=%s]", this
                        .getClass().getSimpleName(),byteCode,index,argNum,methodRef,interfaceMethodRef);
    }
}
