package com.emilio.jdc.core.operation;

import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.constant.Constant;
import com.emilio.jdc.core.operation.expr.InstanceOfExpr;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class InstanceOf extends Operation{
    private Constant castClass = null;
    private int index;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public InstanceOf(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void parseParams(){ 
        index = mergeUnsignedBytes(parameters);
        castClass = context.getConstantPoolInfo().getContantPoolItem(index);
    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:byteCode=%d,constClass=%s]", this
                        .getClass().getSimpleName(),byteCode,castClass);
    }
    
    @Override
    public Object getValue(){
        return castClass.getValue();
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        expr = InstanceOfExpr.of(stack.pop(), castClass);
        
        stack.push(this);
        
        //OperationView prev = context.pop();
        //view = new Object[]{prev, " instanceof " + alias(((InstanceOf) operation).getCastClass())};
        //context.push(this);
    }

}
