package com.emilio.jdc.core;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.emilio.jdc.core.exception.BadFormatException;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent method descriptor for one method.
 */
public final class MethodDescriptor {
    private static final Pattern METHOD_PATTERN = Pattern.compile("\\((.*)\\)(.*)");
    private List<FieldDescriptor> parameters = new ArrayList<FieldDescriptor>();
    //private FieldDescriptor returnType;
    private ReturnDescriptor returnDescriptor;
    private int paramNum;

    /**
     * @param args
     */
    public static void main(String[] args) {
        MethodDescriptor m = new MethodDescriptor();
        String test = "(Ljava/lang/String;I)Ljava/lang/String;";
        test="()V";
        //m.parse("([[Lru/andrew/jclazz/core/constants/CONSTANT_Utf8;[[Lru/andrew/jclazz/core/Clazz;)I");
        m.parse(test);
        System.out.println(m.getReturnType());
    }

    /**
     * 
     * @param desc
     */
    public void parse(String desc) {
        
        desc = desc.trim();
        Matcher m = METHOD_PATTERN.matcher(desc);
        if (m.matches()) {
            String paramDesc = m.group(1);
            String returnDesc = m.group(2);

            while (!paramDesc.equals("")) {
                FieldDescriptor param = new FieldDescriptor();
                paramDesc = param.parse(paramDesc);
                parameters.add(param);
            }
            
            paramNum = parameters.size();

            FieldDescriptor returnType = new FieldDescriptor();
            returnType.parse(returnDesc);
            
            returnDescriptor = new ReturnDescriptor(returnType);
            
        } else {
            throw new BadFormatException("Not supported method descriptor��%s",desc);
        }
    }

    /**
     * 
     * @return
     */
    public List<FieldDescriptor> getParameters() {
        return Collections.unmodifiableList(parameters);
    }
    
    /**
     * 
     * @return
     */
    public int getParamNum() {
        return paramNum;
    }

    /**
     * 
     * @return
     */
    public ReturnDescriptor getReturnType() {
        return returnDescriptor;
    }

    @Override
    public String toString() {
        return String.format("[%s:ParameterDescriptor=%s,returnType=%s]", 
                this.getClass().getSimpleName(), 
                parameters,returnDescriptor);
    }
}
