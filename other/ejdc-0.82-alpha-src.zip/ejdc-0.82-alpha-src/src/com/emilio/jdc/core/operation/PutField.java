package com.emilio.jdc.core.operation;

import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.constant.ConstantFieldRef;
import com.emilio.jdc.core.opcode.ByteCode;
import com.emilio.jdc.core.operation.expr.PutFieldExpr;
import com.emilio.jdc.core.operation.expr.PutStaticExpr;
import com.emilio.jdc.core.type.Value;
import com.emilio.jdc.core.util.OperandStack;
import com.emilio.jdc.core.util.StringValue;

/**
 * 
 * @author Emilio Liang
 *
 */
public class PutField extends Operation{
    private int index;
    private ConstantFieldRef fieldRef;
    private String refClassName;
    //private FieldDescriptor fieldDescriptor;
    private Object value;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public PutField(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    /**
     * 
     */
    public void parseParams() {
        index = mergeUnsignedBytes(parameters);
        fieldRef = (ConstantFieldRef)context.getConstantPoolInfo().getContantPoolItem(index);
        
        if(getOP().equals(ByteCode.PUTSTATIC)){
            value = fieldRef.getRefNameAndType().getName();
            refClassName = fieldRef.getRefClass().getName();
        }else{
            value = fieldRef.getValue(); 
        }
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){       
        switch(getOP()){
        case PUTSTATIC:
            mergeStatic(stack,table);
            break;
        case PUTFIELD:
            mergeField(stack,table);
            break;       
        }
    }
    
    public void mergeStatic(OperandStack<Operation> stack, LocalVariableTable table){
        Value value = stack.pop();
        //TODO ugly here
        expr = PutStaticExpr.of(StringValue.valueOf(refClassName),this, value);
    }
    
    public void mergeField(OperandStack<Operation> stack, LocalVariableTable table){
        Value value = stack.pop();
        Operation objRef = stack.pop();
        
        expr = PutFieldExpr.of(objRef,this,value);
        
    }
    
    @Override
    public Object getValue(){
        return value;
    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:byteCode=%d,index=%d,fieldRef=%s]", this
                        .getClass().getSimpleName(),byteCode,index,fieldRef);
    }
}
