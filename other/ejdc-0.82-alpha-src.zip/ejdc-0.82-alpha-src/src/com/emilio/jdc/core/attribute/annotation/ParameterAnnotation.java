package com.emilio.jdc.core.attribute.annotation;

import java.io.IOException;

import com.emilio.jdc.core.LazyLoadableInfo;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
class ParameterAnnotation implements LazyLoadableInfo{
    private int numAnnotations;
    private Annotation[] annotations = new Annotation[0];

    /**
     * @param cis
     */
    public void load(ClassInputStream cis) throws IOException {
        numAnnotations = cis.readU2();
        
        annotations = new Annotation[numAnnotations];
        
        for(int i = 0 ;i < numAnnotations ;i++){
            annotations[i] = new Annotation();
            annotations[i].load(cis);
        }
    }
}
