package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class GetStaticExpr extends AbstractBinaryOpExpr{
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     * @return
     */
    public static GetStaticExpr of(Value value1, Value value2){
        return new GetStaticExpr(value1, value2);
    }
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     */
    private GetStaticExpr(Value value1,Value value2){
        this.value1 = value1;
        this.value2 = value2;
    }
    
    @Override
    public String toText() {
        StringBuilder text = new StringBuilder(50);
        text.append(LEFT_PARENTHESIS);
        text.append(value1.getValue());
        text.append(DOT);        
        text.append(value2.getValue());
        text.append(RIGHT_PARENTHESIS);
        
        return text.toString();
    }

}
