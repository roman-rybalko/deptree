package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.exception.UnsupportedTypeException;
import com.emilio.jdc.core.opcode.ByteCode;
import com.emilio.jdc.core.operation.expr.ArithmeticExpr;
import com.emilio.jdc.core.operation.expr.NegExpr;
import com.emilio.jdc.core.type.OperatorsType;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Arithmetic extends Operation{
    private OperatorsType operator;
    //private BaseType type;

    /**
     * 
     * @param byteCode
     * @param index
     * @param code
     */
    public Arithmetic(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void parseParams() {
        ByteCode code = getOP();
        
        //Set operator
        setOperator(code);
        
        //Set value
        //setValueType(code);
    }
    
    /**
     * 
     * @param code
     */
    private void setOperator(ByteCode code){
        if (code.isInRange(ByteCode.IADD, ByteCode.DADD) ){
            operator = OperatorsType.ADD;
        }else if (code.isInRange(ByteCode.ISUB, ByteCode.DSUB) ){
            operator = OperatorsType.SUB;
        }else if (code.isInRange(ByteCode.IMUL, ByteCode.DMUL) ){
            operator = OperatorsType.MUL;
        }else if (code.isInRange(ByteCode.IDIV, ByteCode.DDIV) ){
            operator = OperatorsType.DIV;
        }else if (code.isInRange(ByteCode.IREM, ByteCode.DREM) ){
            operator = OperatorsType.MOD;
        }else if (code.isInRange(ByteCode.INEG, ByteCode.DNEG) ){
            operator = OperatorsType.NEG;
        }else{
            throw new UnsupportedTypeException(code.toString());
        }
    }
    
    /**
     * 
     * @param code
     */
//    private void setValueType(ByteCode code){
//        switch (code.getByteCode() % 4){
//            case 0:type = BaseType.I;break;
//            case 1:type = BaseType.J;break;
//            case 2:type = BaseType.F;break;
//            case 3:type = BaseType.D;break;
//            default:throw new UnsupportedTypeException(code.toString());
//        }        
//    }
    
    @Override 
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        ByteCode code = getOP();
        
        if ( code.isInRange(ByteCode.INEG, ByteCode.DNEG) ){
            expr = NegExpr.of(stack.pop(), operator);
            stack.push(this);
        }else{
            expr = ArithmeticExpr.of(stack.pop(), stack.pop(),operator);
            stack.push(this);
        }
    }
    
    @Override
    public Object getValue(){
        //TODO need to put this method to parent ?
        return expr.toText();
    }

}
