package com.emilio.jdc.core.operation;

import com.emilio.jdc.core.attribute.LocalVariableInfo;
import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.operation.expr.IincExpr;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Iinc extends Operation {
    private int varSlotNum;
    private int increment;
    private LocalVariableInfo localVar;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }

    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public Iinc(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void parseParams() {
        varSlotNum = parameters[ZERO];
        increment = toSignedByte(parameters[ONE]);
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        if(table != null){
             localVar = table.get(varSlotNum, getStartPc());
        }
        
        expr = IincExpr.of(localVar, increment);
        
        //lvar = block.getLocalVariable(((Iinc) operation).getLocalVariableNumber(), null, (int) getStartByte());
        //view = new Object[]{lvar.getView(), (((Iinc) operation).getIncValue() == 1 ? "++" : " += " + ((Iinc) operation).getIncValue())};

    }
    
    /**
     * 
     * @return
     */
    public Object getValue(){
        return expr.toText();
    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:varSlotNum=%d,increment=%d]", this
                        .getClass().getSimpleName(),varSlotNum,increment);
    }
}
