package com.emilio.jdc.core.type;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum OperandType{
    STACK(true),
    MIXED(true),
    CONSTANT_POOL(false),
    NONE(false);
    
    private final boolean pushType;
    
    private OperandType(boolean pushType){
        this.pushType = pushType;
    }
    
    public boolean isPushType(){
        return this.pushType;
    }
}
