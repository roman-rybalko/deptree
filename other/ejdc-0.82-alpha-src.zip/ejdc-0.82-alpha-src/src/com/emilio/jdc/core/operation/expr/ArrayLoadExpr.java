package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class ArrayLoadExpr extends AbstractBinaryOpExpr{
    /**
     * 
     * @param value
     * @param operator
     * @return
     */
    public static ArrayLoadExpr of(Value value1, Value value2){
        return new ArrayLoadExpr(value1, value2);
    }
    
    /**
     * 
     * @param value
     * @param operator
     */
    private ArrayLoadExpr(Value value1, Value value2){
        this.value1 = value1;
        this.value2 = value2;
    }
    
    @Override
    public String toText(){
        StringBuilder text = new StringBuilder(50);
        text.append(value1.getValue());
        text.append(LEFT_BRACKET);
        text.append(value2.getValue());
        text.append(RIGHT_BRACKET);        
        return text.toString();
    }
}
