package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public interface UniOpExpr extends Expression{
    Value getOp();
    void setOp(Value op);
}
