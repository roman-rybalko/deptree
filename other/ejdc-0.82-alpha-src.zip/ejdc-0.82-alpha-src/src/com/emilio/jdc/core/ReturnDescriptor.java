package com.emilio.jdc.core;

import java.io.PrintWriter;

import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.type.BaseType;
import com.emilio.jdc.core.type.FieldType;
import com.emilio.jdc.core.type.ObjectType;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent return descriptor in class file, based on field descriptor
 *
 */
public final class ReturnDescriptor implements Value, Expression{
    private FieldDescriptor fd;
    
    ReturnDescriptor(FieldDescriptor fd){
        this.fd = fd;
    }
    
    public boolean isVoid() {
        if (fd.getFieldTypes().contains(FieldType.BASE)) {
            if (fd.getBaseType().equals(BaseType.V)) {
                return true;
            }else{
                return false;
            }
        } else {
            return false;
        }
    }
    
//    public ReturnType getReturnType(){
//        if(fd.getFieldTypes().contains(FieldType.ARRAY)){
//            if(fd.getBaseType().equals(BaseType.V)){
//                return ReturnType.VOID;
//            }else{
//                //TODO
//                return null;
//            }
//            
//        }else{
//            //TODO tobe done
//            return null;
//        }
//    }
    
    /**
     * 
     * @return
     */
    public ObjectType getType(){
        return ObjectType.STRING;
    }
    
    public void print(PrintWriter pw) {
        fd.print(pw);
    }
    
    public String toText(){
        return fd.toText();
    }

    /**
     * 
     * @return
     */
    public Object getValue() {
        if (fd.getFieldTypes().contains(FieldType.OBJECT)) {
            return fd.getObjectType();
        } else {
            return fd.getBaseType();
        }
    }
}
