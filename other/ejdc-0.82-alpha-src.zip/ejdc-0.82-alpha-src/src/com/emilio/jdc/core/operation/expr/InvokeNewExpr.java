package com.emilio.jdc.core.operation.expr;

/**
 * 
 * @author Emilio Liang
 *
 */
public class InvokeNewExpr extends AbstractInvokeExpr{
    
    @Override
    public String toText() {
        StringBuilder text = new StringBuilder(50);
        text.append("");
        
        return text.toString();
    }
}
