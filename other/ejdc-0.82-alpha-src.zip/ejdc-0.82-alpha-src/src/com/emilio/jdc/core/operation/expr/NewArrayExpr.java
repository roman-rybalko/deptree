package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class NewArrayExpr implements Expression{
    private static final String NEW = "new";
    private Value count;
    private Value type;
    
    /**
     * 
     * @param count
     * @param type
     * @return
     */
    public static NewArrayExpr of(Value count,Value type){
        return new NewArrayExpr(count, type);
    }

    /**
     * 
     * @param count
     * @param type
     */
    private NewArrayExpr(Value count,Value type){
        this.count = count;
        this.type = type;
    }
    
    
    public String toText(){
        StringBuilder text = new StringBuilder(50);
        text.append(NEW);
        text.append(BLANK_SPACE);
        text.append(type.getValue());
        text.append(LEFT_BRACKET);
        text.append(count.getValue());
        text.append(RIGHT_BRACKET);
        
        return text.toString();
    }

}
