package com.emilio.jdc.core.operation.expr;

/**
 * 
 * @author Emilio Liang
 *
 */
public interface Stmt {
    public boolean containsInvokeExpr();
    //public InvokeExpr getInvokeExpr();

    public boolean containsArrayRef();
    //public ArrayRef getArrayRef();

    public boolean containsFieldRef();
    //public FieldRef getFieldRef();
    
}
