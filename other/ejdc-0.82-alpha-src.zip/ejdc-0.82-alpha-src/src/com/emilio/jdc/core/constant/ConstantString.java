package com.emilio.jdc.core.constant;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.type.ConstantType;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent CONSTANT_String table in constant_pool 
 * 
 */
public final class ConstantString extends Constant {
    private int nameIndex;
    private String stringVal;

    /**
     * Constructor
     * 
     * @param num
     * @param type
     */
    public ConstantString(int num, ConstantType type) {
        super(num, type);
    }

    @Override
    public void load(ClassInputStream jis) throws IOException {
        nameIndex = jis.readU2();
    }

    @Override
    public void resolve(Class clazz) {
        ConstantPoolInfo pool = clazz.getPoolInfo();
        stringVal = pool.getContantPoolItem(nameIndex).getValue();
    }

    @Override
    public int getIndex() {
        return nameIndex;
    }
    
    @Override
    public String getValue() {
        return "\""+stringVal+"\"";
    }

    @Override
    public String toString() {
        return String.format("[%s:index=%d,type=%s,nameIndex=%d,stringVal=%s]", this
                .getClass().getSimpleName(), 
                index, 
                type, 
                nameIndex,
                stringVal
        );
    }
}
