package com.emilio.jdc.core.type;

/**
 * 
 * @author Emilio Liang
 *
 */
public class SymbolWrapper implements Symbol {

    private final String symbol;
    
    public static SymbolWrapper fromString(String symbol){
        if(symbol == null || symbol.length() == 0){
            throw new NullPointerException();
        }
        
        return new SymbolWrapper(symbol);
    }
    
    private SymbolWrapper(String symbol){
        this.symbol = symbol;
    }
    
    public String toSymbol() {
        return symbol;
    }

}
