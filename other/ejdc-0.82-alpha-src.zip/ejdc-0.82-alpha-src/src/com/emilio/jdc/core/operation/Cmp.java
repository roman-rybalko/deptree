package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.operation.expr.CmpExpr;
import com.emilio.jdc.core.type.Value;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Cmp extends Operation{

    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public Cmp(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }

    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        Value value1 = stack.pop();
        Value value2 = stack.pop();
        expr = CmpExpr.of(value1, value2);
        
        stack.push(this);
    }

    @Override
    public Object getValue(){
        return expr.toText();
    }
}
