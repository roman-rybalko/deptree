package com.emilio.jdc.core.operation.expr;

import java.util.List;

import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class NewMultiArrayExpr implements Expression{
    private static final String NEW = "new";
    private List<Value> dimensions;
    private Value type;
    
    /**
     * 
     * @param value
     * @param operator
     * @return
     */
    public static NewMultiArrayExpr of(List<Value> dimensions, Value type){
        return new NewMultiArrayExpr(dimensions, type);
    }
    
    /**
     * 
     * @param value
     * @param operator
     */
    private NewMultiArrayExpr(List<Value> dimensions,Value type){
        this.dimensions = dimensions;
        this.type = type;
    }
    
    public String toText(){
        StringBuilder text = new StringBuilder(50);
        //TODO if dimensions is null
        
        text.append(NEW);
        text.append(BLANK_SPACE);
        text.append(type.getValue());
        
        for(Value value : dimensions){
            text.append(LEFT_BRACKET);            
            text.append(value.getValue());
            text.append(RIGHT_BRACKET);
        }
        
        return text.toString();
    }
}
