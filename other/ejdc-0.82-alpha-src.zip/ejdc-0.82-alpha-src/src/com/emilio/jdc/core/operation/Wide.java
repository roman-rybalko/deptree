package com.emilio.jdc.core.operation;

import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.opcode.ByteCode;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Wide extends Operation {
    public enum WideType {IINC,OTHER};
    
    private int byteCode;
    private int varNum;
    private int n;
    private WideType type;

    
    public Wide(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){       
    }
    
    @Override
    public int loadParams(int next, int[] byteContent) {
        ByteCode code = ByteCode.of(byteContent[next++]);
        int byteNum = 0;
        
        switch (code) {
        case ALOAD:
        case ILOAD:
        case FLOAD:
        case DLOAD:
        case LLOAD:
        case ASTORE:
        case FSTORE:
        case ISTORE:
        case DSTORE:
        case LSTORE:
        case RET:
            byteNum = loadParams(next, 3, byteContent);
            type = WideType.OTHER;
            break;
        case IINC:
            byteNum = loadParams(next, 5, byteContent);
            type = WideType.IINC;
            break;
        }
        
        return byteNum;
    }
    
    @Override
    public void parseParams() {
        switch(type){
        case IINC:
            byteCode = parameters[ZERO];
            varNum = mergeUnsignedBytes(parameters[ONE],parameters[TWO]);
            n = mergeUnsignedBytes(parameters[THREE],parameters[FOUR]);
            break;
        case OTHER: 
            byteCode = parameters[ZERO];
            varNum = mergeUnsignedBytes(parameters[ONE],parameters[TWO]);
            break;
        }
    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:type=%s,byteCode=%d,varNum=%d,n=%d]", this
                        .getClass().getSimpleName(),type,byteCode,varNum,n);
    }
}
