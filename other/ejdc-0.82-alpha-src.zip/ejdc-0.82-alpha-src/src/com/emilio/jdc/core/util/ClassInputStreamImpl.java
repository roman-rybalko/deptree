package com.emilio.jdc.core.util;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

/**
 * 
 * @author Emilio Liang
 * 
 * Implementation for ClassInputStream
 *
 */
public class ClassInputStreamImpl implements ClassInputStream {
    private static final int UNSIGNED_UTF_LEN_SIZE = 2;
    private DataInputStream dis = null;
    private int bytesCount = 0;

    /**
     * Constructor
     * 
     * @param file
     * @throws IOException
     */
    ClassInputStreamImpl(File file) throws IOException {
        this(readClassFile(file));
    }

    /**
     * Constructor
     * 
     * @param buf
     * @throws IOException
     */
    ClassInputStreamImpl(byte[] buf) throws IOException {
        dis = new DataInputStream(new ByteArrayInputStream(buf));
    }
    
	/**
	 * Read unsigned bytes into int[]
	 * @param buf
	 * @throws IOException
	 */
    public void read(int[] buf) throws IOException {

        for(int i = 0 ;i < buf.length ;i++){
            buf[i]=dis.readUnsignedByte();
        }
        
        bytesCount += buf.length;
    }
    
    /**
     * Read bytes into byte array
     * @param buf
     * @throws IOException
     */
    public void read(byte[] buf) throws IOException {
        if (buf == null || buf.length == 0) {
            throw new IOException("Empty byte[]");
        }

        int count = dis.read(buf);
        
        assert(buf.length == count);
        
        bytesCount += buf.length;
    }

    /**
     * 
     * @param inputFile
     * @return
     * @throws IOException
     */
    private static byte[] readClassFile(File inputFile) throws IOException {
        if (!inputFile.exists()) {
            throw new IOException(inputFile.getName().concat(" not exist"));
        }

        FileInputStream fin = null;
        FileChannel inc = null;

        ByteBuffer buffer = ByteBuffer.allocate((int) inputFile.length());

        try {
            fin = new FileInputStream(inputFile);
            inc = fin.getChannel();
            inc.read(buffer);

        } finally {
            try {
                if (fin != null) {
                    fin.close();
                }
            } catch (IOException ex) {
            }
        }

        return buffer.array();
    }

    /**
     * 
     */
    public void close() {
        // For ByteArrayInputStream, empty method
    }

    /**
     * @return int
     */
    public int readU1() throws IOException {
        bytesCount++;
        return dis.readUnsignedByte();
    }

    /**
     * Read 1 unsigned integer into int
     * @return
     * @throws IOException
     */
    public int readU2() throws IOException {
        bytesCount += 2;
        return dis.readUnsignedShort();
    }

    /**
     * @return long
     */
    public long readU4() throws IOException {
        long high = dis.readUnsignedShort();
        long low = dis.readUnsignedShort();
        bytesCount += 4;
        return (high << 16) + low;
    }

    /**
     * @return float
     */
    public float readFloat() throws IOException {
        bytesCount += 4;
        return dis.readFloat();
    }

    /**
     * @return double
     */
    public double readDouble() throws IOException {
        bytesCount += 8;
        return dis.readDouble();
    }

    /**
     * @return int
     */
    public int readInt() throws IOException {
        bytesCount += 4;
        return dis.readInt();
    }

    /**
     * @return long
     */
    public long readLong() throws IOException {
        bytesCount += 8;
        return dis.readLong();
    }

    /**
     * 
     * @return String
     */
    public String readUTF() throws IOException {
    	//mark and reset stream, so that UTF size can be get for getReadBytes method, and UTF content not changed
        dis.mark(UNSIGNED_UTF_LEN_SIZE);
        int utfLen = dis.readUnsignedShort();
        dis.reset();
        bytesCount += (utfLen + UNSIGNED_UTF_LEN_SIZE);
        return dis.readUTF();
    }

    /**
     * Count read bytes, useful for debug about how many bytes have been read.
     * @return int
     */
    public int getReadBytes() {
        return bytesCount;
    }

}
