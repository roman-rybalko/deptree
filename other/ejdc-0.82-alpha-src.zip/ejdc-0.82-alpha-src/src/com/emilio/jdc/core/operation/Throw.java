package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.operation.expr.ThrowExpr;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Throw extends Operation{

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public Throw(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }

    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        expr = ThrowExpr.of(stack.pop());
        stack.push(this);
    }
    
    /**
     * 
     * @return
     */
    public Object getValue(){
        return this;
    }

}
