package com.emilio.jdc.core.operation.expr;

import java.util.List;

import com.emilio.jdc.core.MethodInfoItem;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public abstract class AbstractInvokeExpr implements InvokeExpr {
    //TODO remove MethodInfoItem and used interface?
    protected MethodInfoItem method;
    protected String methodName;
    protected List<? extends Value> arguments;
    
    public Value getArg(int index){
        return arguments.get(index);
    }

    public List<? extends Value> getArgs(){
        //List l = new ArrayList();
        //for (ValueBox element : argBoxes)
        //                l.add(element.getValue());

        //return l;
        
        return arguments;
    }

    public int getArgCount(){
        return arguments.size();
    }
    
    public abstract String toText();
}
