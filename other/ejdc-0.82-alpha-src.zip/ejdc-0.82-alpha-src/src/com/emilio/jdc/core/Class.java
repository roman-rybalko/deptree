package com.emilio.jdc.core;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import com.emilio.jdc.core.attribute.AttributeInfo;
import com.emilio.jdc.core.exception.BadFormatException;
import com.emilio.jdc.core.exception.ResolveException;
import com.emilio.jdc.core.type.ClassElemType;
import com.emilio.jdc.core.util.ClassInputStream;
import com.emilio.jdc.core.util.ClassStreamFactory;

/**
 * 
 * @author Emilio Liang
 * 
 * In memory structure to represent java class file
 *
 */
public final class Class {
    private static final long MAGIC_NUMBER = 0xCAFEBABEL;
    private static final String RESOLVE_METHOD_NAME = "resolve";
    private static final java.lang.Class<?> RESOLVABLEINFO_CLASS = com.emilio.jdc.core.ResolvableInfo.class;
    private static final java.lang.Class<?> CONSTANTPOOLINFO_CLASS = com.emilio.jdc.core.Class.class;
    private VersionInfo versionInfo;
    private ConstantPoolInfo poolInfo;
    private ClassInfo classInfo;
    private InterfaceInfo interfaceInfo;
    private FieldInfo fieldInfo;
    private MethodInfo methodInfo;
    private AttributeInfo attributeInfo;
    private ClassInputStream cis;
    private MethodInfoItem currentMethod;
    private Map<ClassElemType, Object> classElements = new EnumMap<ClassElemType, Object>(ClassElemType.class);

    //private static final String FILE = "D:/Projects";
    //private static final String FILE = "D:/errors/YangHui.class";
    //private static final String FILE = "C:/TRY.class";
    //private static final String FILE = "c:/TestFor.class";
    //private static final String FILE = "D:/Projects/JavaDeCompiler/bin/TestIF.class";
    //private static final String FILE = "D:\\tools\\rt\\";
    //private static final String FILE = "C:/TestParam.class";
    //private static final String FILE = "C:/TestIfCondition.class";
    private static final String FILE = "c:/TestIf2.class";
    //private static final String FILE = "C:/rt/com/sun/corba/se/impl/activation/RepositoryImpl.class";
    //private static final String FILE = "D:/tools/rt/com/sun/corba/se/impl/naming/pcosnaming/PersistentBindingIterator.class";    
    //private static final String FILE="D:/Projects/JavaDeCompiler_2010_09_27/bin/com/emilio/jdc/core/util/StringFormatUtil.class";
    //private static final String FILE="D:/Projects/AuthServer/WEB-INF/classes/com/ge/hc/mr/ipp/web/servlet/ActionServlet.class";
    
    /**
     * @param args
     */
    public static void main(String[] args) throws Exception {
        Class clas = new Class();
        List<File> list = new ArrayList<File>();
        
        File root = new File(FILE);
        
        if(root.isDirectory()){
            findClassFile(root,list);
        }else{
            list.add(root);
        }
        for(File file: list){
            System.out.println(file);
            clas.load(file);
        }
    }

    /**
     * 
     * @return
     */
    public ClassInputStream getInputStream() {
        return cis;
    }

    /**
     * 
     * @param root
     * @param list
     */
    static void findClassFile(File root, List<File> list) {
        if (root.isFile()){
            list.add(root);
            
        }
        File[] files = root.listFiles(new FileFilter(){
            public boolean accept(File pathname){
                String[] names = new String[]{"ActionServlet.class",
                        "EvaluateExpression.class",
                        "GraphicalVerifier.class",
                        "CdrUtils.class",
                        "MainForm$5.class",
                        "decompiler\\Main.class",
                        "bin\\CountOpcodes.class",
                        "WiclAccessC.class",
                        "RunningJobTopic.class",
                        "ShellTaskAdaptor.class",
                        "RunningJobQueueTest.class",
                        "JMSTest.class",
                        "ShellTaskServer.class",
                        "MDITest3.class",
                        "SystemContextService.class",
                        "TestDataRepository.class",
                        "PurgeThreadTest.class",
                        "ProbCauseConvertTest.class",
                        "notifserver\\unittest",
                        "NotifIdGenerator.class",
                        "NotifServerStore.class",
                        "CDRFileConverter2.class",
                        "DBConnection.class",
                        "NetStatistics.class",
                        "ai.class",
                        "versant\\core",
                        "YangHui.class",
                        "JavaScriptEngineFactory.class",
                        "Base64Test.class",
                        "Cat1Cat2.class"
                        
                };
                
                for (String name : names) {
                    if (pathname.getAbsolutePath().indexOf(name) != -1) {
                        return false;
                    }
                }

                return true;
                
            }}

        );

        for (File file : files) {
            if (file.isDirectory()) {
                findClassFile(file, list);
            } else if (file.getName().endsWith(".class")) {
                list.add(file);
            }
        }
    }

    /**
     * load
     * @param file
     * @throws Exception
     */
    public void load(File file) throws IOException {
        ClassInputStream cis = ClassStreamFactory.getInputStream(file);

        long magicNumber = cis.readU4();

        validateMagicNumber(magicNumber);

        versionInfo = new VersionInfo();
        poolInfo = new ConstantPoolInfo();
        classInfo = new ClassInfo();
        interfaceInfo = new InterfaceInfo();
        fieldInfo = new FieldInfo();
        methodInfo = new MethodInfo();
        attributeInfo = new AttributeInfo();

        List<LoadableInfo> infoList = Arrays.asList(versionInfo, poolInfo,
                classInfo, interfaceInfo, fieldInfo, methodInfo, attributeInfo);

        try {
            for (LoadableInfo info : infoList) {
                info.load(cis);
                // System.out.println(info);
            }
        } catch (Exception e) {
            System.err.println(cis.getReadBytes());
            e.printStackTrace();
        }

        if (file.length() != cis.getReadBytes()) {
            throw new RuntimeException("Wrong size");
        }

        //for (Constant item : poolInfo.getConstantPool()) {
            //System.out.println(item);
        //}

        resolve(infoList, this);
        
        //TODO move to another method?
        classElements.put(ClassElemType.VERSION, versionInfo);
        classElements.put(ClassElemType.CLASS, classInfo);
        classElements.put(ClassElemType.CONSTANT_POOL, poolInfo);
        classElements.put(ClassElemType.INTERFACE, interfaceInfo);
        classElements.put(ClassElemType.FIELD, fieldInfo);
        classElements.put(ClassElemType.METHOD, methodInfo);
        classElements.put(ClassElemType.ATTRIBUTE, attributeInfo);
        
        //for (LoadableInfo info : infoList) {
            //System.out.println(info);
        //}
        
        //print(System.out);
    }

    /**
     * 
     * @param infoList
     * @param cpi
     * @throws Exception
     */
    private void resolve(List<LoadableInfo> infoList, Class cpi)
            throws ResolveException {
        for (LoadableInfo info : infoList) {
            java.lang.Class<?> clas = info.getClass();
            List<?> list = Arrays.asList(clas.getInterfaces());

            try {
                if (list.contains(RESOLVABLEINFO_CLASS)) {
                    Method method = clas.getMethod(RESOLVE_METHOD_NAME,
                            CONSTANTPOOLINFO_CLASS);
                    method.invoke(info, cpi);
                }
            } catch (Exception e) {
                e.printStackTrace();
                throw new ResolveException(e);
            }
        }
    }

    /**
     * validate class file Magic Number
     * 
     * @param magicNumber
     */
    private void validateMagicNumber(long magicNumber) {
        if (magicNumber != MAGIC_NUMBER) {
            throw new BadFormatException();
        }
    }

    void print(PrintWriter pw) {
        fieldInfo.print(pw);
        methodInfo.print(pw);
    }

    public final ConstantPoolInfo getPoolInfo() {
        return poolInfo;
    }

    public final ClassInfo getClassInfo() {
        return classInfo;
    }

    public Map<ClassElemType, Object> getClassElements() {
        return classElements;
    }

    public final MethodInfoItem getCurrentMethod() {
        return currentMethod;
    }
    
    void setCurrentMethod(final MethodInfoItem  method){
        this.currentMethod = method;
    }

    public InterfaceInfo getInterfaceInfo() {
        return interfaceInfo;
    }

    public FieldInfo getFieldInfo() {
        return fieldInfo;
    }

    public MethodInfo getMethodInfo() {
        return methodInfo;
    }
}
