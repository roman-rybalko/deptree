package com.emilio.jdc.core.util;

import java.util.Stack;

public class OperandStack<E> {
    private Stack<E> stack = new Stack<E>();
    
    public boolean empty(){
        return stack.empty();
    }
    
    public E peek(){
        return stack.peek();
    }
    
    public E pop(){
        return stack.pop();
    }
    
    public E push(E item){
        return stack.push(item);
    }
    
    public int search(Object o){
        return stack.search(o);
    }
    
    public int size(){
        return stack.size();
    }
}
