package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class FakeConditionOp extends Operation {
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public FakeConditionOp(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        
    }

}
