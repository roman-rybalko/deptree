package com.emilio.jdc.core.type;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum CmpType {
    EQ("=="),
    LE("<="),
    GE(">="),
    GT(">"),
    LT("<");
 
    private final String mark;
    
    private CmpType(String mark){
        this.mark = mark;
    }
    
    @Override
    public String toString(){
        return mark;
    }
}
