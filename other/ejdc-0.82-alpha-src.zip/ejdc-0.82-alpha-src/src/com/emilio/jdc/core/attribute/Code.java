package com.emilio.jdc.core.attribute;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.MethodInfoItem;
import com.emilio.jdc.core.operation.Operation;
import com.emilio.jdc.core.operation.OperationType;
import com.emilio.jdc.core.util.ClassInputStream;
import com.emilio.jdc.core.util.StringFormatUtil;
import com.emilio.jdc.decompile.engine.Decompiler;
import com.emilio.jdc.decompile.structure.Block;

/**
 * 
 * @author Emilio Liang
 *
 * Represent code attribute, byte code array included in this attribute.
 */
public final class Code extends AttributeInfoItem {
    private int maxStack;
    private int maxLocals;
    private long codeLength;
    private int[] codeContent;
    private int exceptionLength;
    private List<Operation> operations = new ArrayList<Operation>();
    private ExceptionTable exceptionTable;
    private AttributeInfo attributeInfo;
    private MethodContext context;

    private Class clazz;
    private MethodInfoItem method;
    private LineNumberTable lineNumTable;
    private LocalVariableTable localVarTable;
    private StackMapTable stackMapTable;
    
    private boolean existLocalVarTable = false;
    private boolean existLineNumTable = false;
    private boolean existStackMapTable = false;    

    /**
     * Constructor
     * 
     * @param item
     */
    public Code(AttributeInfoItem item) {
        super(item);
    }
    
    public Code() {
        super();
    }

    @Override
    public AttributeInfoItem resolve(Class clazz) throws IOException {
        
        //TODO
        this.clazz = clazz;        

        ClassInputStream cis = getStream();
        maxStack = cis.readU2();
        maxLocals = cis.readU2();
        codeLength = cis.readU4();
        codeContent = new int[(int) codeLength];
        cis.read(codeContent);        
        exceptionTable = new ExceptionTable();

        exceptionTable.load(cis);
        exceptionTable.resolve(clazz);

        //Load attribute in "Code"
        loadAttributeInfo(cis,clazz);

        //TODO other better way to handle this ?
        method = clazz.getCurrentMethod();
        
        method.setCode(this);
        
        this.context = new MethodContext(this);
               
        parseOperations(operations,codeContent);
        
        
        //if (method.getMethodName().indexOf("main") != -1){
        //    System.out.println("--------main");
        //    mergeStacks();
        //}
        
        //Link method with code
        

        decompile();
        return this;
        
    }
    
    /**
     * Parse byte code to Operation
     * @param operations
     * @param codeContent
     */
    private void parseOperations(List<Operation> operations, int[] codeContent) {
        //System.out.println("===============================");
        //System.out.println(attributeInfo);

        //for (int i = 0; i < codeContent.length; i++) {
            //int byteCode = codeContent[i];
            //System.out.println("byteCode="+byteCode);
        //}
        //System.out.println("===============================");        
        //System.out.println(attributeInfo);
        
        
        for (int next = 0;next < codeContent.length;) {

            int byteCode = codeContent[next];
            
            Operation op = OperationType.of(byteCode,next++,context);
            
            //TODO adjust index return here
            next += op.loadParams(next, codeContent);

            op.parseParams();
            
            //Need to remove?
            op.resolve(method);
            
            operations.add(op);
            
            //map.put(op.getByteCode(), op);
        }
        
        //for(Operation op : operations){
        //    System.out.println("op---"+op.getByteIndex());
        //}
        

    }
    
    public String decompile(){
        Block block = Decompiler.toBlock(operations,context);
        
        block = Decompiler.decompile(block, context);

//        StringBuilder source = new StringBuilder();        
//        for (CodeStruct line: block.getOperations()){
//            String lineCode = line.toText();
//            
//            if(lineCode != null){
//                source.append(lineCode);
//                System.out.println("-------" + line);
//                source.append(Expression.LINE_SEPARATOR);
//            }
//        }
        
        return block.toText();
    }
    
    /**
     * 
     *
    public String decompile(){
        OperandStack<Operation> stack = new OperandStack<Operation>();
        
        for (Operation op : operations){
            System.out.println(op);
            System.out.println("stack="+stack.size());
            System.out.println("index="+op.getByteIndex());            

             //op.mergeStack(stack, localVarTable);
        }
                
        StringBuilder content = new StringBuilder();
        for (Operation op : operations){
            if (op.getExpression() != null){
                System.out.println(op.getExpression().toText());
                content.append(op.getExpression().toText());
            }
        }
        
        return content.toString();
    }
    
    */
    /**
     * 
     * @param cis
     * @throws IOException
     */
    private void loadAttributeInfo(ClassInputStream cis,Class clazz)throws IOException {

        attributeInfo = new AttributeInfo();

        attributeInfo.load(cis);
        
        attributeInfo.resolve(clazz);
        
        localVarTable = attributeInfo.queryAttribute(LocalVariableTable.class);
        
        if(localVarTable != null){
            existLocalVarTable = true;
        }

        lineNumTable = attributeInfo.queryAttribute(LineNumberTable.class);

        if (lineNumTable != null){
            existLineNumTable = true;
        }

        stackMapTable = attributeInfo.queryAttribute(StackMapTable.class);
        
        if (stackMapTable != null){
            existStackMapTable = true;
        }
    }
    
    /**
     * 
     * @return boolean
     */
    public boolean existLocalVarTable() {
        return existLocalVarTable;
    }

    /**
     * 
     * @return boolean
     */
    public boolean existLineNumTable() {
        return existLineNumTable;
    }

    /**
     * 
     * @return boolean
     */
    public boolean existStackMapTable() {
        return existStackMapTable;
    }

    /**
     * 
     * @return
     */
    public ConstantPoolInfo getConstantPoolInfo(){
        return clazz.getPoolInfo();
    }
    
    /**
     * 
     * @return LineNumberTable
     */
    public LineNumberTable getLineNumTable() {
        return lineNumTable;
    }

    /**
     * 
     * @return LocalVariableTable 
     */
    public LocalVariableTable getLocalVarTable() {
        return localVarTable;
    }

    /**
     * 
     * @return StackMapTable
     */
    public StackMapTable getStackMapTable() {
        return stackMapTable;
    }
    
    /**
     * 
     * @return ExceptionTable
     */
    public ExceptionTable getExceptionTable(){
        return exceptionTable;
    }
    
    
    MethodInfoItem getMethodInfo(){
        return method;
    }
    
    /**
     * 
     * @return int[]
     */
    public int[] getCodeArray(){
        //Copy protection
        if(codeContent != null){
            return codeContent.clone();
        }else{
            return null;
        }
    }
    
    public void print(PrintWriter pw) {
        for (Operation op : operations){
            pw.printf("%d : %s%n", op.getByteIndex() ,op.getOP().getMnemonic());
        }
    }
    
    @Override
    public String toString() {
        return String
                .format(
                        "[%s:maxStack=%d,maxLocals=%d,codeLength=%d,codeConent=%s,exceptionLength=%d]",
                        this.getClass().getSimpleName(),
                        maxStack, 
                        maxLocals,
                        codeLength,
                        StringFormatUtil.toString(codeContent),
                        exceptionLength);
    }
}
