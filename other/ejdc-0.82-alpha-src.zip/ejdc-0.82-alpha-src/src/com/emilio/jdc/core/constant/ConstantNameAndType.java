package com.emilio.jdc.core.constant;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.type.ConstantType;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent CONSTANT_NameAndType table in constant_pool 
 * 
 */
public final class ConstantNameAndType extends Constant {
    private int classIndex;
    private int descIndex;
    private String name;
    private String descriptor;

    /**
     * Constructor
     * 
     * @param num
     * @param type
     */
    public ConstantNameAndType(int num, ConstantType type) {
        super(num, type);
    }

    @Override
    public void load(ClassInputStream jis) throws IOException {
        classIndex = jis.readU2();
        descIndex = jis.readU2();
    }

    @Override
    public void resolve(Class clazz) {
        ConstantPoolInfo pool = clazz.getPoolInfo();
        name = pool.getContantPoolItem(classIndex).getValue();
        descriptor = pool.getContantPoolItem(descIndex).getValue();        
    }
    
    /**
     * 
     * @return
     */
    public String getName(){
        return name;
    }
    
    /**
     * 
     * @return
     */
    public String getDescriptor() {
        return descriptor;
    }

    @Override
    public String getValue() {
        return name;
    }

    @Override
    public int getIndex() {
        return 0;
    }

    @Override
    public String toString() {
        return String.format("[%s:index=%d,type=%s,classIndex=%d,descIndex=%d]",
                this.getClass().getSimpleName(), index, type, classIndex,
                descIndex);
    }

}
