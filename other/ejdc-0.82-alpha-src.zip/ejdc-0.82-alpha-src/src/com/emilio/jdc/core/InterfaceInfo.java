package com.emilio.jdc.core;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.operation.expr.ListExpression;
import com.emilio.jdc.core.util.ClassInputStream;
import com.emilio.jdc.core.util.StringExpression;

/**
 * 
 * @author Emilio Liang
 * 
 * Wrapper class for class version, include all the interfaced indexes and names
 *
 */
public final class InterfaceInfo implements LoadableInfo, ResolvableInfo, ListExpression{
    private int interfaceCount = 0;
    private int interfaceIndexs[] = new int[0];
    private List<String> UTFNames = new ArrayList<String>();

    /**
     * Constructor
     */
    public InterfaceInfo() {
        
    }

    /**
     * @param cis
     */
    public void load(ClassInputStream cis) throws IOException {
        interfaceCount = cis.readU2();
        
        if (interfaceCount > 0) {
            interfaceIndexs = new int[interfaceCount];
            for (int i = 0; i < interfaceCount; i++) {
                interfaceIndexs[i] = cis.readU2();
            }
        }
    }

    /**
     * @param clazz
     */
    public void resolve(Class clazz) {
        ConstantPoolInfo  pool = clazz.getPoolInfo();
        
        for (int i = 0; i < interfaceIndexs.length ;i++) {
            UTFNames.add(pool.getContantPoolItem(interfaceIndexs[i]).getValue());
        }
    }
    
    /**
     * 
     * @return List<String>
     */
    public List<String> getUTFNames() {
        return UTFNames;
    }
    
    public List<Expression> listExpressions(){
        //TODO
        List<Expression> list = new ArrayList<Expression>();
        for(String item:UTFNames){
            list.add(StringExpression.valueOf(item));
        }
        
        return list;
    }

    @Override
    public String toString() {
        return String.format("[%s:interfaceCount=%d,interfaceIndexs=%s]",
                this.getClass().getSimpleName(),
                interfaceCount,
                Arrays.toString(interfaceIndexs));
    }
}
