package com.emilio.jdc.core.constant;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.type.ConstantType;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent CONSTANT_Long table in constant_pool 
 * 
 */
public final class ConstantLong extends Constant {
    protected long longVal;

    /**
     * Constructor
     * 
     * @param num
     * @param type
     */
    public ConstantLong(int num, ConstantType type) {
        super(num, type);
    }

    @Override
    public void load(ClassInputStream jis) throws IOException {
        longVal = jis.readLong();
    }

    @Override
    public void resolve(Class clazz) {
    }

    @Override
    public String getValue() {
        return String.valueOf(longVal);
    }

    @Override
    public int getIndex() {
        return 0;
    }

    @Override
    public String toString() {
        return String.format("[%s:index=%d,type=%s,longVal=%d]", this.getClass()
                .getSimpleName(), index, type, longVal);
    }
}
