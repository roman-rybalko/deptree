package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.OperatorsType;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class ArrayStoreExpr implements Expression{
    private Value arrayRef;
    private Value arrayIndex;
    private Value arrayValue;
    
    /**
     * 
     * @param arrayRef
     * @param arrayIndex
     * @param arrayValue
     * @return
     */
    public static ArrayStoreExpr of(Value arrayRef, Value arrayIndex, Value arrayValue){
        return new ArrayStoreExpr(arrayRef, arrayIndex, arrayValue);
    }
    
    /**
     * 
     * @param arrayRef
     * @param arrayIndex
     * @param arrayValue
     */
    private ArrayStoreExpr(Value arrayRef, Value arrayIndex, Value arrayValue){
        this.arrayRef = arrayRef;
        this.arrayIndex = arrayIndex;
        this.arrayValue = arrayValue;  
    }
    
    /**
     * 
     */
    public String toText(){
        StringBuilder text = new StringBuilder(50);
        text.append(arrayRef.getValue());
        text.append(LEFT_BRACKET);
        text.append(arrayIndex.getValue());
        text.append(RIGHT_BRACKET);
        text.append(OperatorsType.ASSIGN);
        text.append(arrayValue.getValue());
        
        return text.toString();
    }
    
}
