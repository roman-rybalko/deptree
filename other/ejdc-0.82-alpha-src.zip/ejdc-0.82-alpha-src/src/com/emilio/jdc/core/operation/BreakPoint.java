package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class BreakPoint extends Operation {
    /**
     * @param arg
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }
    
    public BreakPoint(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override 
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        
    }
}
