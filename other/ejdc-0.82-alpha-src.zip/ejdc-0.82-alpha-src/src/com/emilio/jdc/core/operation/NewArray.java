package com.emilio.jdc.core.operation;

import java.util.HashMap;
import java.util.Map;

import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.operation.expr.NewArrayExpr;
import com.emilio.jdc.core.type.BaseType;
import com.emilio.jdc.core.type.ObjectType;
import com.emilio.jdc.core.type.Value;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class NewArray extends Operation{
    private ComponentType type;
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public NewArray(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }

    @Override
    public void parseParams(){ 
        type = ComponentType.ofType(parameters[ZERO]);
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        expr = NewArrayExpr.of(stack.pop(), type);
        
        stack.push(this);
    }

    @Override
    public Object getValue(){
        return expr.toText();
    }
    
    /**
     * ComponentType
     * 
     */
    enum ComponentType implements Value{
        BOOLEAN(4,BaseType.B),
        CHAR(5,BaseType.C),
        FLOAT(6,BaseType.F),
        DOUBLE(7,BaseType.D),
        BYTE(8,BaseType.B),
        SHORT(9,BaseType.S),
        INT(10,BaseType.I),
        LONG(11,BaseType.J);
        
        private static final Map<Integer, ComponentType> intToEnum = new HashMap<Integer, ComponentType>();
        private int paramCode;
        private BaseType type;
        
        static {
            for (ComponentType op : values()) {
                intToEnum.put(op.paramCode, op);
            }
        }
        
        /**
         * 
         * @return
         */
        public ObjectType getType(){
            return ObjectType.STRING; 
        }

        /**
         * 
         * @return
         */
        public Object getValue(){
            return type.toString();
        }
        
        ComponentType(int paramCode,BaseType type){
            this.paramCode = paramCode;
            this.type = type;
        }
        
        static ComponentType ofType(int paramCode){
            return intToEnum.get(paramCode);
        }
        
        @Override
        public String toString(){
            return type.toString();
        }
    }
}
