package com.emilio.jdc.core;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.operation.expr.ListExpression;
import com.emilio.jdc.core.util.ClassInputStream;
import com.emilio.jdc.core.util.StringFormatUtil;

/**
 * 
 * @author Emilio Liang
 * 
 * Collection for all methods in one class
 *
 */
public final class MethodInfo implements LoadableInfo, ResolvableInfo, ListExpression {
    private int methodCount = 0;
    private List<MethodInfoItem> methodInfoList = new ArrayList<MethodInfoItem>();

    /**
     * Default Constructor
     */
    public MethodInfo() {
    }

    public void load(ClassInputStream cis) throws IOException {
        methodCount = cis.readU2();

        if (methodCount > 0) {
            //methodInfoList = new MethodInfoItem[methodCount];
            for (int i = 0; i < methodCount; i++) {
                MethodInfoItem methodInfo = new MethodInfoItem();
                methodInfo.load(cis);
                methodInfoList.add(methodInfo);
            }
        }
    }

    /**
     * @param Class
     */
    public void resolve(Class clazz) throws IOException {        
        for (MethodInfoItem methodItem : methodInfoList) {
            methodItem.resolve(clazz);
        }
    }
    
    /**
     * 
     */
    public List<Expression> listExpressions(){
        //TODO
        List<Expression> list = new ArrayList<Expression>();
        for(MethodInfoItem item:methodInfoList){
            list.add(item);
        }
        
        return list;
    }
    
    /**
     * 
     * @param pw
     */
    public void print(PrintWriter pw) {
        if (methodCount > 0) {
            for(MethodInfoItem item : methodInfoList){
                item.print(pw);
            }
        }
    }
    
    public String toText(){
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        print(pw);
        return sw.toString();
    }
    
	public List<MethodInfoItem> getList(){
		return Collections.unmodifiableList(methodInfoList);
	}
	
    @Override
    public String toString() {
        return String.format("[%s:methodCount=%d,methodInfoList:%s]", this
                .getClass().getSimpleName(), 
                methodCount, 
                StringFormatUtil.toString(methodInfoList,1)
        );
    }

}
