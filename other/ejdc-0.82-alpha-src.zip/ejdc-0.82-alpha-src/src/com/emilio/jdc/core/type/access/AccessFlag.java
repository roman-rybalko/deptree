package com.emilio.jdc.core.type.access;
/**
 * 
 * @author Emilio Liang
 * 
 * Interface for all access flag wrapper classes;
 * getAccessFlag method will return the integer represented access flag  
 */
public interface AccessFlag {
    public int getAccessFlag();
}
