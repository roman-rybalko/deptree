package com.emilio.jdc.core.type;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum ClassElemType {
    VERSION("Class Version",true),
    CONSTANT_POOL("Cosntant Pool",true),
    CLASS("Class Info",true),
    INTERFACE("Interface Info",false),
    FIELD("Field Info",false),
    METHOD("Method Info",false),
    ATTRIBUTE("Attribute Info",false);
    
    private final String title;
    private final boolean isLeaf;

    private ClassElemType(String title, boolean isLeaf){
        this.title = title;
        this.isLeaf = isLeaf;
    }
    
    public String getTitle(){
        return title;
    }
    
    public boolean isLeaf(){
        return isLeaf;
    }
}
