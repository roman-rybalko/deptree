package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.operation.Switch;

/**
 * 
 * @author Emilio Liang
 *
 */
public class CaseBlockExpr implements Expression{
    private Switch.CaseBranch caseBranch;
    private boolean exitGoto; 
    
    
    public String toText() {
        //TODO needs to add indent
        StringBuilder text = new StringBuilder();

//        if (caseBranch.isDeafult() && isEmpty()){
//            return "";
//        }
        
        if (caseBranch.isDeafult()) {
            text.append("default");
        } else {
            text.append("case ");
            text.append(caseBranch.getValue());
        }
        
        text.append(":");
        text.append(LINE_SEPARATOR);

//        if (!isEmpty()) {
//            text.append(super.getOperationsSource());
//        } else {
//            // Empty case block
//        }
        
        if (exitGoto) {
            text.append("    break;");
            text.append(LINE_SEPARATOR);
        }
        
        return text.toString();
    }
}
