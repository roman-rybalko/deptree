package com.emilio.jdc.core.util;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Proxy;

/**
 * 
 * @author Emilio Liang
 * Factory method for ClassStream
 */
public class ClassStreamFactory {
    private static final String CLASS_FILE_STREAM_PROXY = "ClassFileProxy";
    private static final String ATTRIBUTE_STREAM_PROXY = "AttributeProxy";

    /**
     * getInputStream
     * @param file
     * @return
     * @throws IOException
     */
    public static ClassInputStream getInputStream(File file) throws IOException {
        ClassInputStreamImpl cis = new ClassInputStreamImpl(file);

        return getProxy(CLASS_FILE_STREAM_PROXY, cis);
    }

    /**
     * getInputStream
     * @param buf
     * @return
     * @throws IOException
     */
    public static ClassInputStream getInputStream(byte[] buf)
            throws IOException {
        ClassInputStreamImpl cis = new ClassInputStreamImpl(buf.clone());
        return getProxy(ATTRIBUTE_STREAM_PROXY, cis);
    }

    /**
     * getProxy
     * @param proxyName
     * @param cis
     * @return
     */
    private static ClassInputStream getProxy(String proxyName,
            ClassInputStream cis) {
        return (ClassInputStream) Proxy.newProxyInstance(cis.getClass()
                .getClassLoader(), cis.getClass().getInterfaces(),
                new ClassInputStreamProxy(proxyName, cis));
    }
}
