package com.emilio.jdc.core.type;

/**
 * 
 * @author Emilio Liang
 *
 */
public interface Symbol {
    public String toSymbol();
}
