package com.emilio.jdc.core.opcode;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.emilio.jdc.core.type.OperandType;
import com.emilio.jdc.core.type.PushType;

/**
 * 
 * @author Emilio Liang
 * Byte code(instruction) wrapper class, every byte code being wrapped with one field in enum.
 * 
 */
public enum ByteCode implements OpCode{
    NOP(0, "nop", "ConstPush null", 0, -1, false, PushType.NONE, OperandType.NONE),
    ACONST_NULL(1, "aconst_null", "ConstPush null", 0, -1, false, PushType.NULL,OperandType.STACK),                                                                                                                                                                                                                                                                                          
    ICONST_M1(2,"iconst_m1", "ConstPush int constant", 0, -1, false, PushType.INTEGER, OperandType.STACK),
    ICONST_0(3, "iconst_0", "ConstPush int constant", 0, 0, false, PushType.INTEGER, OperandType.STACK),
    ICONST_1(4, "iconst_1", "ConstPush int constant", 0, 1, false, PushType.INTEGER, OperandType.STACK),
    ICONST_2(5, "iconst_2", "ConstPush int constant", 0, 2, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                                  
    ICONST_3(6, "iconst_3", "ConstPush int constant", 0, 3, false, PushType.INTEGER, OperandType.STACK),
    ICONST_4(7, "iconst_4", "ConstPush int constant", 0, 4, false, PushType.INTEGER, OperandType.STACK),
    ICONST_5(8, "iconst_5", "ConstPush int constant", 0, 5, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                      
    LCONST_0(9, "lconst_0", "ConstPush long constant", 0, 0, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                                 
    LCONST_1(10, "lconst_1", "ConstPush long constant", 0, 1, false, PushType.LONG ,OperandType.STACK),
    FCONST_0(11, "fconst_0", "ConstPush float", 0, 0, false, PushType.FLOAT, OperandType.STACK),
    FCONST_1(12, "fconst_1", "ConstPush float", 0, 1, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                             
    FCONST_2(13, "fconst_2", "ConstPush float", 0, 2, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                                        
    DCONST_0(14, "dconst_0", "ConstPush double", 0, 0, false, PushType.DOUBLE, OperandType.STACK),
    DCONST_1(15, "dconst_1", "ConstPush double", 0, 1, false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                                       
    BIPUSH(16, "bipush", "ConstPush byte", 1 , -1, false, PushType.BYTE, OperandType.MIXED),//
    SIPUSH(17, "sipush", "ConstPush short", 2 , -1, false, PushType.SHORT, OperandType.MIXED),//
    LDC(18, "ldc", "ConstPush item from runtime constant pool", 1, -1, false, PushType.OBJECT, OperandType.MIXED),
    LDC_W(19, "ldc_w", "ConstPush item from runtime constant pool (wide index)", 2, -1, false, PushType.OBJECT, OperandType.MIXED),                                                                                                                                                                                                                                                                    
    LDC2_W(20, "ldc2_w", "ConstPush long or double from runtime constant pool (wide index)", 2, -1, false, PushType.OBJECT, OperandType.MIXED),                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
    ILOAD(21, "iload", "Load int from local variable", 1, -1, false, PushType.INTEGER, OperandType.MIXED),                                                                                                                                                                                                                                                                                         
    LLOAD(22, "lload", "Load long from local variable", 1, -1, false, PushType.LONG, OperandType.MIXED),                                                                                                                                                                                                                                                                                        
    FLOAD(23, "fload", "Load float from local variable", 1, -1, false, PushType.FLOAT, OperandType.MIXED),                                                                                                                                                                                                                                                                                       
    DLOAD(24, "dload", "Load double from local variable", 1, -1, false, PushType.DOUBLE, OperandType.MIXED),                                                                                                                                                                                                                                                                                      
    ALOAD(25, "aload", "Load reference from local variable", 1, -1, false, PushType.OBJECT, OperandType.MIXED), //local?                                                                                                                                                                                                                                                                                  
    ILOAD_0(26, "iload_0", "Load int from local variable", 0, 0, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                           
    ILOAD_1(27, "iload_1", "Load int from local variable", 0, 1, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                       
    ILOAD_2(28, "iload_2", "Load int from local variable", 0, 2, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                       
    ILOAD_3(29, "iload_3", "Load int from local variable", 0, 3, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                       
    LLOAD_0(30, "lload_0", "Load long from local variable", 0, 0, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                      
    LLOAD_1(31, "lload_1", "Load long from local variable", 0, 1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                      
    LLOAD_2(32, "lload_2", "Load long from local variable", 0, 2, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                      
    LLOAD_3(33, "lload_3", "Load long from local variable", 0, 3, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                      
    FLOAD_0(34, "fload_0", "Load float from local variable", 0, 0, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                     
    FLOAD_1(35, "fload_1", "Load float from local variable", 0, 1, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                     
    FLOAD_2(36, "fload_2", "Load float from local variable", 0, 2, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                     
    FLOAD_3(37, "fload_3", "Load float from local variable", 0, 3, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                     
    DLOAD_0(38, "dload_0", "Load double from local variable", 0, 0, false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                    
    DLOAD_1(39, "dload_1", "Load double from local variable", 0, 1, false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                    
    DLOAD_2(40, "dload_2", "Load double from local variable", 0, 2,false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                    
    DLOAD_3(41, "dload_3", "Load double from local variable", 0, 3, false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                    
    ALOAD_0(42, "aload_0", "Load reference from local variable", 0, 0, false, PushType.OBJECT, OperandType.STACK),                                                                                                                                                                                                                                                                                 
    ALOAD_1(43, "aload_1", "Load reference from local variable", 0, 1, false, PushType.OBJECT, OperandType.STACK),                                                                                                                                                                                                                                                                                 
    ALOAD_2(44, "aload_2", "Load reference from local variable", 0, 2, false, PushType.OBJECT, OperandType.STACK),                                                                                                                                                                                                                                                                                 
    ALOAD_3(45, "aload_3", "Load reference from local variable", 0, 3, false, PushType.OBJECT, OperandType.STACK),                                                                                                                                                                                                                                                                                 
    IALOAD(46, "iaload", "Load int from array", 0, -1, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                                 
    LALOAD(47, "laload", "Load long from array", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                                
    FALOAD(48, "faload", "Load float from array", 0, -1, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                               
    DALOAD(49, "daload", "Load double from array", 0,-1, false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                              
    AALOAD(50, "aaload", "Load reference from array", 0, -1, false, PushType.OBJECT, OperandType.STACK),                                                                                                                                                                                                                                                                                           
    BALOAD(51, "baload", "Load byte or boolean from array", 0, -1, false, PushType.BYTE, OperandType.STACK),                                                                                                                                                                                                                                                                                     
    CALOAD(52, "caload", "Load char from array", 0, -1, false, PushType.CHAR, OperandType.STACK),                                                                                                                                                                                                                                                                                                
    SALOAD(53, "saload", "Load short from array", 0, -1, false, PushType.SHORT, OperandType.STACK),                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
    ISTORE(54, "istore", "Store int into local variable", 1, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                       
    LSTORE(55, "lstore", "Store long into local variable", 1, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                      
    FSTORE(56, "fstore", "Store float into local variable", 1, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                     
    DSTORE(57, "dstore", "Store double into local variable", 1, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                    
    ASTORE(58, "astore", "Store reference into local variable", 1, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                 
    ISTORE_0(59, "istore_0", "Store int into local variable", 0, 0, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                     
    ISTORE_1(60, "istore_1", "Store int into local variable", 0, 1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                     
    ISTORE_2(61, "istore_2", "Store int into local variable", 0, 2, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                     
    ISTORE_3(62, "istore_3", "Store int into local variable", 0, 3, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                     
    LSTORE_0(63, "lstore_0", "Store long into local variable", 0, 0, true, PushType.NONE, OperandType.STACK),
    LSTORE_1(64, "lstore_1", "Store long into local variable", 0, 1, true, PushType.NONE, OperandType.STACK),
    LSTORE_2(65, "lstore_2", "Store long into local variable", 0, 2, true, PushType.NONE, OperandType.STACK),
    LSTORE_3(66, "lstore_3", "Store long into local variable", 0, 3, true, PushType.NONE, OperandType.STACK),
    FSTORE_0(67, "fstore_0", "Store float into local variable", 0, 0, true, PushType.NONE, OperandType.STACK),
    FSTORE_1(68, "fstore_1", "Store float into local variable", 0, 1, true, PushType.NONE, OperandType.STACK),
    FSTORE_2(69, "fstore_2", "Store float into local variable", 0, 2, true, PushType.NONE, OperandType.STACK),
    FSTORE_3(70, "fstore_3", "Store float into local variable", 0, 3, true, PushType.NONE, OperandType.STACK),
    DSTORE_0(71, "dstore_0", "Store double into local variable", 0, 0, true, PushType.NONE, OperandType.STACK),
    DSTORE_1(72, "dstore_1", "Store double into local variable", 0, 1, true, PushType.NONE, OperandType.STACK),
    DSTORE_2(73, "dstore_2", "Store double into local variable", 0, 2, true, PushType.NONE, OperandType.STACK),
    DSTORE_3(74, "dstore_3", "Store double into local variable", 0, 3, true, PushType.NONE, OperandType.STACK),
    ASTORE_0(75, "astore_0", "Store reference into local variable", 0, 0, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                               
    ASTORE_1(76, "astore_1", "Store reference into local variable", 0, 1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                               
    ASTORE_2(77, "astore_2", "Store reference into local variable", 0, 2, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                               
    ASTORE_3(78, "astore_3", "Store reference into local variable", 0, 3, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                               
    IASTORE(79, "iastore", "Store into int array", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                               
    LASTORE(80, "lastore", "Store into long array", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                              
    FASTORE(81, "fastore", "Store into float array", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                             
    DASTORE(82, "dastore", "Store into double array", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                            
    AASTORE(83, "aastore", "Store into reference array", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                         
    BASTORE(84, "bastore", "Store into byte or boolean array", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                   
    CASTORE(85, "castore", "Store into char array", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                              
    SASTORE(86, "sastore", "Store into short array", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                                                                     
    POP(87, "pop", "Pop the top operand stack value", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                        
    POP2(88, "pop2", "Pop the top one or two operand stack values", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                           
    DUP(89, "dup", "Duplicate the top operand stack value", 0, -1, false, PushType.OBJECT, OperandType.STACK),                                                                                                                                                                                                                                                                                  
    DUP_X1(90, "dup_x1", "Duplicate the top operand stack value and insert two values down", 0, -1, false, PushType.OBJECT, OperandType.STACK),
    DUP_X2(91, "dup_x2", "Duplicate the top operand stack value and insert two or three values down", 0, -1, false, PushType.OBJECT, OperandType.STACK),
    DUP2(92, "dup2", "Duplicate the top one or two operand stack values", 0, -1, false, PushType.OBJECT, OperandType.STACK),                                                                                                                                                                                                                                                          
    DUP2_X1(93, "dup2_x1", "Duplicate the top one or two operand stack values and insert two or three values down", 0, -1, false, PushType.OBJECT, OperandType.STACK),                                                                                                                                                                                                                              
    DUP2_X2(94, "dup2_x2", "Duplicate the top one or two operand stack values and insert two, three, or four values down", 0, -1, false, PushType.OBJECT, OperandType.STACK),                                                                                                                                                                                                                       
    SWAP(95, "swap", "Swap the top two operand stack values", 0, -1, false, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                                                                     
    IADD(96, "iadd", "Add int", 0, -1, false, PushType.INTEGER, OperandType.STACK),
    LADD(97, "ladd", "Add long", 0, -1, false, PushType.LONG, OperandType.STACK),
    FADD(98, "fadd", "Add float", 0, -1, false, PushType.FLOAT, OperandType.STACK),
    DADD(99, "dadd", "Add double", 0, -1, false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                                            
    ISUB(100, "isub", "Subtract int", 0, -1, false, PushType.INTEGER, OperandType.STACK),
    LSUB(101, "lsub", "Subtract long", 0, -1, false, PushType.INTEGER, OperandType.STACK),
    FSUB(102, "fsub", "Subtract float", 0, -1, false, PushType.FLOAT, OperandType.STACK),
    DSUB(103, "dsub", "Subtract double", 0, -1, false, PushType.DOUBLE, OperandType.STACK),
    IMUL(104, "imul", "Multiply int", 0, -1, false, PushType.INTEGER, OperandType.STACK),
    LMUL(105, "lmul", "Multiply long", 0, -1, false, PushType.LONG, OperandType.STACK),
    FMUL(106, "fmul", "Multiply float", 0, -1, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                                       
    DMUL(107, "dmul", "Multiply double", 0, -1, false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                                      
    IDIV(108, "idiv", "Divide int", 0, -1, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                                           
    LDIV(109, "ldiv", "Divide long", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                                          
    FDIV(110, "fdiv", "Divide float", 0, -1, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                                         
    DDIV(111, "ddiv", "Divide double", 0, -1, false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                                        
    IREM(112, "irem", "Remainder int", 0, -1, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                                        
    LREM(113, "lrem", "Remainder long", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                                       
    FREM(114, "frem", "Remainder float", 0, -1, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                                      
    DREM(115, "drem", "Remainder double", 0, -1, false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                                     
    INEG(116, "ineg", "Negate int", 0, -1, true, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                                           
    LNEG(117, "lneg", "Negate long", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                                          
    FNEG(118, "fneg", "Negate float", 0, -1, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                                         
    DNEG(119, "dneg", "Negate double", 0, -1, false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                                                                       
    ISHL(120, "ishl", "Shift left int", 0, -1, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                                       
    LSHL(121, "lshl", "Shift left", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                                           
    ISHR(122, "ishr", "Arithmetic shift right int", 0, -1, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                           
    LSHR(123, "lshr", "Arithmetic shift right long", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                          
    IUSHR(124, "iushr", "Logical shift right int", 0, -1, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                             
    LUSHR(125, "lushr", "Logical shift right long", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                            
    IAND(126, "iand", "Boolean AND int", 0, -1, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                                      
    LAND(127, "land", "Boolean AND long", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                                     
    IOR(128, "ior", "Boolean OR int", 0, -1, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                                        
    LOR(129, "lor", "Boolean OR long", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                                       
    IXOR(130, "ixor", "Boolean XOR int", 0, -1, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                                      
    LXOR(131, "lxor", "Boolean XOR long", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
    IINC(132, "iinc", "Increment local variable by constant", 2, -1, true, PushType.NONE, OperandType.MIXED),                                                                                                                                                                                                                                                                                                                
    I2L(133, "i2l", "Convert int to long", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                                   
    I2F(134, "i2f", "Convert int to float", 0, -1, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                                  
    I2D(135, "i2d", "Convert int to double", 0, -1, false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                                 
    L2I(136, "l2i", "Convert long to int", 0, -1, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                                   
    L2F(137, "l2f", "Convert long to float", 0, -1, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                                 
    L2D(138, "l2d", "Convert long to double", 0, -1, false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                                
    F2I(139, "f2i", "Convert float to int", 0, -1, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                                  
    F2L(140, "f2l", "Convert float to long", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                                 
    F2D(141, "f2d", "Convert float to double", 0, -1, false, PushType.DOUBLE, OperandType.STACK),                                                                                                                                                                                                                                                                                               
    D2I(142, "d2i", "Convert double to int", 0, -1, false, PushType.INTEGER, OperandType.STACK),                                                                                                                                                                                                                                                                                                 
    D2L(143, "d2l", "Convert double to long", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                                
    D2F(144, "d2f", "Convert double to float", 0, -1, false, PushType.FLOAT, OperandType.STACK),                                                                                                                                                                                                                                                                                               
    I2B(145, "i2b", "Convert int to byte", 0, -1, false, PushType.BYTE, OperandType.STACK),                                                                                                                                                                                                                                                                                                   
    I2C(146, "i2c", "Convert int to char", 0, -1, false, PushType.CHAR, OperandType.STACK),                                                                                                                                                                                                                                                                                                   
    I2S(147, "i2s", "Convert int to short", 0, -1, false, PushType.SHORT, OperandType.STACK),                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
    LCMP(148, "lcmp", "Compare long", 0, -1, false, PushType.LONG, OperandType.STACK),                                                                                                                                                                                                                                                                                                         
    FCMPL(149, "fcmpl", "Compare float", 0, -1, false, PushType.FLOAT, OperandType.STACK),
    FCMPG(150, "fcmpg", "Compare float", 0, -1, false, PushType.FLOAT, OperandType.STACK),
    DCMPL(151, "dcmpl", "Compare double", 0, -1, false, PushType.DOUBLE, OperandType.STACK),
    DCMPG(152, "dcmpg", "Compare double", 0, -1, false, PushType.DOUBLE, OperandType.STACK),
    IFEQ(153, "ifeq", "Branch if int comparison with zero succeeds", 2,-1, true, PushType.NONE, OperandType.STACK),
    IFNE(154, "ifne", "Branch if int comparison with zero succeeds", 2, -1, true, PushType.NONE, OperandType.STACK),
    IFLT(155, "iflt", "Branch if int comparison with zero succeeds", 2, -1, true, PushType.NONE, OperandType.STACK),
    IFGE(156, "ifge", "Branch if int comparison with zero succeeds", 2, -1, true, PushType.NONE, OperandType.STACK),
    IFGT(157, "ifgt", "Branch if int comparison with zero succeeds", 2, -1, true, PushType.NONE, OperandType.STACK),
    IFLE(158, "ifle", "Branch if int comparison with zero succeeds", 2, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                          
    IF_ICMPEQ(159, "if_icmpeq", "Branch if int comparison succeeds", 2, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                               
    IF_ICMPNE(160, "if_icmpne", "Branch if int comparison succeeds", 2, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                               
    IF_ICMPLT(161, "if_icmplt", "Branch if int comparison succeeds", 2, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                               
    IF_ICMPGE(162, "if_icmpge", "Branch if int comparison succeeds", 2, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                               
    IF_ICMPGT(163, "if_icmpgt", "Branch if int comparison succeeds", 2, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                               
    IF_ICMPLE(164, "if_icmple", "Branch if int comparison succeeds", 2, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                               
    IF_ACMPEQ(165, "if_acmpeq", "Branch if reference comparison succeeds", 2, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                         
    IF_ACMPNE(166, "if_acmpne", "Branch if reference comparison succeeds", 2, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                         
    GOTO(167, "goto", "Branch always", 2, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                                        
    JSR(168, "jsr", "Jsr subroutine", 2, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                                       
    RET(169, "ret", "Return from subroutine", 1, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                                
    TABLESWITCH(170, "tableswitch", "Access jump table by index and jump", -1, -1, true, PushType.NONE, OperandType.MIXED),                                                                                                                                                                                                                                                                          
    LOOKUPSWITCH(171, "lookupswitch", "Access jump table by key match and jump", -1, -1, true, PushType.NONE, OperandType.MIXED),                                                                                                                                                                                                                                                                     
    IRETURN(172, "ireturn", "Return int from method", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                            
    LRETURN(173, "lreturn", "Return long from method", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                           
    FRETURN(174, "freturn", "Return float from method", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                          
    DRETURN(175, "dreturn", "Return double from method", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                         
    ARETURN(176, "areturn", "Return reference from method", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                      
    RETURN(177, "return", "Return void from method", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                                                                       
    GETSTATIC(178, "getstatic", "Get static field from class", 2, -1, false, PushType.OBJECT, OperandType.MIXED),                                                                                                                                                                                                                                                                                     
    PUTSTATIC(179, "putstatic", "Set static field in class", 2, -1, true, PushType.NONE, OperandType.MIXED),                                                                                                                                                                                                                                                                                       
    GETFIELD(180, "getfield", "Fetch field from object", 2, -1, false, PushType.OBJECT, OperandType.MIXED),                                                                                                                                                                                                                                                                                          
    PUTFIELD(181, "putfield", "Set field in object", 2, -1, true, PushType.NONE, OperandType.MIXED),                                                                                                                                                                                                                                                                                              
    INVOKEVIRTUAL(182, "invokevirtual", "Invoke instance method, dispatch based on class", 2, -1, false, PushType.OBJECT, OperandType.MIXED),                                                                                                                                                                                                                                                             
    INVOKESPECIAL(183, "invokespecial", "Invoke instance method, special handling for superclass, private, and instance initialization method invocations", 2, -1, false, PushType.OBJECT, OperandType.MIXED),                                                                                                                                                                                            
    INVOKESTATIC(184, "invokestatic", "Invoke a class (static) method", 2, -1, false, PushType.OBJECT, OperandType.MIXED),                                                                                                                                                                                                                                                                               
    INVOKEINTERFACE(185, "invokeinterface", "Invoke interface method", 4, -1, false, PushType.OBJECT, OperandType.MIXED),                                                                                                                                                                                                                                                                                   
    INVOKEDYNAMIC(186, "invokedynamic", "Invoke instance method, resolve and dispatch based on class", 2, -1, false, PushType.OBJECT, OperandType.MIXED),  // Since Java 1.5
    NEW(187, "new", "Create new object", 2, -1, false, PushType.OBJECT, OperandType.MIXED),                                                                                                                                                                                                                                                                                            
    NEWARRAY(188, "newarray", "Create new array", 1, -1, false, PushType.OBJECT, OperandType.MIXED),
    ANEWARRAY(189, "anewarray", "Create new array of reference", 2, -1, false, PushType.OBJECT, OperandType.MIXED),
    ARRAYLENGTH(190, "arraylength", "Get length of array", 0, -1, false, PushType.INTEGER, OperandType.STACK),
    ATHROW(191, "athrow", "Throw exception or error", 0, -1, true, PushType.NONE, OperandType.STACK),
    CHECKCAST(192, "checkcast", "Check whether object is of given type", 2, -1, false, PushType.OBJECT, OperandType.MIXED), 
    INSTANCEOF(193, "instanceof", "Determine if object is of given type", 2, -1, false, PushType.OBJECT, OperandType.MIXED),
    MONITORENTER(194, "monitorenter", "Enter monitor for object", 0, -1 ,true, PushType.NONE, OperandType.STACK),
    MONITOREXIT(195, "monitorexit", "Exit monitor for object", 0, -1, true, PushType.NONE, OperandType.STACK),                                                                                                                                                                                                                                                                                                                      
    WIDE(196, "wide", "Extend local variable index by additional bytes", -1, -1, true, PushType.NONE, OperandType.MIXED),
    MULTIANEWARRAY(197, "multianewarray", "Create new multidimensional array", 3, -1, true, PushType.OBJECT, OperandType.MIXED),
    IFNULL(198, "ifnull", "Branch if reference is 0", 2, -1, true, PushType.NONE, OperandType.MIXED),
    IFNONNULL(199, "ifnonnull", "Branch if reference not 0", 2, -1, true, PushType.NONE, OperandType.MIXED),
    GOTO_W(200, "goto_w", "Branch always (wide index)", 4, -1, false, PushType.NONE, OperandType.MIXED),
    JSR_W(201, "jsr_w", "Jsr subroutine (wide index)", 4, -1, true, PushType.NONE, OperandType.MIXED),
    BREAKPOINT(202, "breakpoint", "RESERVED", 0, -1, true, PushType.NONE, OperandType.STACK),
    IMPDEP1(254, "impdep1", "RESERVED", 0, -1, true, PushType.NONE, OperandType.NONE),
    IMPDEP2(255, "impdep2", "RESERVED", 0, -1, true, PushType.NONE, OperandType.NONE);
    
    /**
     * 
     */
    private static Map<Integer,ByteCode> map = new HashMap<Integer,ByteCode>();
    
    /**
     * Put all byte code in to map
     */
    static{
        for(ByteCode code :ByteCode.values()){
            map.put(code.getByteCode(),code);
        }
    }
    
    private final int code;
    private final String mnemonic;
    private final String description;
    private final int paramByteNum;
    private final int constValue;
    private final boolean visible;
    private final PushType pushType;
    private final OperandType type;
    
    /**
     * 
     * @param code
     * @param mnemonic
     * @param description
     * @param paramNum
     */
    private ByteCode(int code,String mnemonic,String description, int paramByteNum, int constValue, boolean visible, PushType pushType, OperandType type){
        this.code = code;
        this.mnemonic = mnemonic;
        this.description = description;
        this.paramByteNum = paramByteNum;
        this.constValue = constValue;
        this.visible = visible;
        this.type = type;
        this.pushType = pushType;
    }
    
    /**
     * 
     * @param opCode
     * @return
     */
    public static ByteCode of(int opCode){
        return map.get(opCode);
    }

    /**
     * 
     * @param begIndex
     * @param endIndex
     * @return
     */
    public static Set<OpCode> of(int begIndex,int endIndex){
        if (begIndex > endIndex){
            throw new IllegalArgumentException("begIndex should not bigger than endIndex");
        }
        
        Set<OpCode> set = new HashSet<OpCode>();
        
        for(int i = begIndex; i < endIndex; i++){
            set.add(map.get(i));
        }
        
        return set;
    }
    
    /**
     * 
     * @param beginCode
     * @param endCode
     * @return
     */
    public boolean isInRange(ByteCode beginCode, ByteCode endCode){
        if (beginCode.getByteCode() > endCode.getByteCode()){
            throw new IllegalArgumentException("begIndex should not bigger than endIndex");
        }
        return ( code >= beginCode.getByteCode() && code <= endCode.getByteCode() );
    }

    /**
     * @return int
     */
    public int getByteCode(){
        return code;
    }
    
    /**
     * @return string
     */
    public String getDescription(){
        return description;
    }
    
    /**
     * @return string
     */
    public String getMnemonic(){
        return mnemonic;
    }
    
    /**
     * @return string
     */
    public int getParamByteNum(){
        return paramByteNum;
    }
    
    /**
     * 
     * @return string
     */
    public PushType getType() {
        return pushType;
    }

    /**
     * 
     * @return string
     */
    public int getConstValue() {
        return constValue;
    }
    
    /**
     * 
     * @return boolean
     */
    public boolean isVisible() {
        return visible;
    }

    @Override
    public String toString(){
        return String.format("[code=%d,mnemonic=%s,type=%s]" ,code,mnemonic,type);
    }
}
