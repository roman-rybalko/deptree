package com.emilio.jdc.core.util;

import java.io.IOException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.emilio.jdc.core.exception.ClassException;

/**
 * 
 * @author Emilio Liang
 * 
 * Proxy class for ClassInputStream implements InvocationHandler
 *
 */
public class ClassInputStreamProxy implements InvocationHandler {
    private String proxyName;
    private ClassInputStream cis;

    /**
     * Constructor with default package visibility
     * @param proxyName
     * @param cis
     */
    ClassInputStreamProxy(String proxyName, ClassInputStream cis) {
        this.proxyName = proxyName;
        this.cis = cis;
    }

    /**
     * Implementation of InvocationHandler
     * @param proxy
     * @param method
     * @param args
     * @return Object
     */
    public Object invoke(Object proxy, Method method, Object[] args)
            throws Throwable {
        Object obj = null;
        try {
            obj = method.invoke(cis, args);
        } catch (InvocationTargetException ex) {
            checkException(ex);
        }

        return obj;
    }

    /**
     * Check if exception have been thrown by invoke method
     * 
     * @param ex
     * @throws ClassException
     */
    private void checkException(Exception ex) throws ClassException {
        if (ex.getCause() instanceof IOException) {
            throw new ClassException("IO error at" + cis.getReadBytes(), ex);
        }
    }

    @Override
    public String toString() {
        return proxyName;
    }
}
