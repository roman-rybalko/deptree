package com.emilio.jdc.core.attribute;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class SourceFile extends AttributeInfoItem {
    private int sourceFileIndex;
    private String sourceFileName;

    /**
     * Constructor
     * 
     * @param item
     */
    public SourceFile(AttributeInfoItem item) {
        super(item);
    }
    
    public SourceFile() {
        super();
    }

    public String getSourceFileName() {
        return sourceFileName;
    }

    @Override
    public AttributeInfoItem resolve(Class clazz) throws IOException {
        ConstantPoolInfo pool = clazz.getPoolInfo();
        ClassInputStream cis = getStream();
        sourceFileIndex = cis.readU2();

        sourceFileName = pool.getContantPoolItem(sourceFileIndex).getValue();
        return this;
    }

    @Override
    public String toString() {
        return String.format("[%s:sourceFileIndex=%d,sourceFileName=%s]", this
                .getClass().getSimpleName(), sourceFileIndex, sourceFileName);
    }
}
