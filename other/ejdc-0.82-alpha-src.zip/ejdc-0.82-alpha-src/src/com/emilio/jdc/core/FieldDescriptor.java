package com.emilio.jdc.core;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.EnumSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.emilio.jdc.core.exception.BadFormatException;
import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.type.BaseType;
import com.emilio.jdc.core.type.FieldType;
import com.emilio.jdc.core.type.ObjectType;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent field descriptor in class file.
 *
 */
public final class FieldDescriptor implements Value, Expression{
    private static final String ARRAY_REGX = "[\\[]*";
    private static final Pattern ARRAY_PATTERN = Pattern.compile(ARRAY_REGX);
    private static final String OBJECT_REGX = "L([\\$a-zA-Z_0-9/]*);";
    private static final Pattern OBJECT_PATTERN = Pattern.compile(OBJECT_REGX);
    private static final String BASE_REGX = "([BCDFIJSZV])";
    private static final Pattern BASE_PATTERN = Pattern.compile(BASE_REGX);
    private static final char DOT = '.';
    private static final char SLASH = '/';

    private int arrayLayers = 0;
    private String objectType;
    private BaseType baseType;
    
    private EnumSet<FieldType> types = EnumSet.noneOf(FieldType.class);
        
    public static void main(String args[]){
        String tt =  "[[[D";
        tt = "V";
        
        FieldDescriptor f = new FieldDescriptor();
        
        f.parse(tt);
        
        System.out.println(f);
    }

    /**
     * 
     * @param fieldDesc
     * @return remaining descriptor
     */
    public String parse(String fieldDesc) {
        Matcher arrayMatcher = ARRAY_PATTERN.matcher(fieldDesc);
        if (arrayMatcher.find()) {
            arrayLayers = arrayMatcher.group().length();
            //TODO why add into set?
            types.add(FieldType.ARRAY);
            fieldDesc = fieldDesc.substring(arrayMatcher.end(), fieldDesc.length());
        }

        Matcher objMatcher = OBJECT_PATTERN.matcher(fieldDesc);
        if (objMatcher.find()) {
            objectType = objMatcher.group(1);
            objectType = objectType.replace(SLASH, DOT);
            types.add(FieldType.OBJECT);
            fieldDesc = fieldDesc.substring(objMatcher.end());
        } else {
            Matcher baseMatcher = BASE_PATTERN.matcher(fieldDesc);
            if (baseMatcher.find()) {
                String base = baseMatcher.group(1);
                for (BaseType bType : BaseType.values()) {
                    if (bType == BaseType.valueOf(base)) {
                        baseType = bType;
                        types.add(FieldType.BASE);
                        fieldDesc = fieldDesc.substring(baseMatcher.end());
                    }
                }
            } else {
                throw new BadFormatException("Not supported field FieldDescriptor:%s", fieldDesc);
            }
        }
        
        return fieldDesc;
    }
    
    public boolean isArray() {
        return types.contains(FieldType.ARRAY);
    }

    public boolean isObject() {
        return types.contains(FieldType.OBJECT);    
    }

    public boolean isBase() {
        return types.contains(FieldType.BASE);
    }

    public int getArrayLayers() {
        return arrayLayers;
    }

    public String getObjectType() {
        return objectType;
    }

    BaseType getBaseType() {
        return baseType;
    }

    Set<FieldType> getFieldTypes() {
        return types;
    }
    
    /**
     * 
     * @return
     */
    public ObjectType getType(){
        return ObjectType.STRING;
    }

    /**
     * 
     * @return
     */
    public Object getValue() {
        if (types.contains(FieldType.OBJECT)) {
            return objectType;
        } else {
            return baseType;
        }
    }
    
    /**
     *
     * @return
     */
    public Object getArrayValue() {
        // TODO define array type for array define
        StringBuilder content = new StringBuilder();
        if (types.contains(FieldType.ARRAY)) {
           
            if (types.contains(FieldType.OBJECT)) {
                content.append(objectType);
            } else {
                content.append(baseType);
            }
            
            content.append(" ");
            
            for (int i = 0 ;i < arrayLayers; i++){
                content.append("[]");                
            }   
        }
        
        return content.toString();
    }
    
    public void print(PrintWriter pw) {
        if (isArray()) {
            for (int i = 0; i < getArrayLayers(); i++) {
                pw.print("[]");
            }
        }

        if (isBase()) {
            pw.print(getBaseType());
            pw.print(" ");
        }

        if (isObject()) {
            pw.print(objectType);
            pw.print(" ");
        }   
    }
    
    public String toText(){
    	StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        print(pw);
        return sw.toString();
    }

    @Override
    public String toString() {
        return String.format("[%s:arrayLayers=%d,objectType=%s,baseType=%s]",
                this.getClass().getSimpleName(), arrayLayers, objectType,
                baseType);
    }

}
