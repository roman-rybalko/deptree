package com.emilio.jdc.core.operation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.exception.BadFormatException;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Switch extends Operation{
    private int operationLength;
    //TODO needs to change to set?
    private List<CaseBranch> caseBranches = new ArrayList<CaseBranch>();

    /**
     * @param args
     */
    public static void main(String[] args) {
    }
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public Switch(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public int loadParams(int next, int[] byteContent) {
        
        int paddingNum = 3 - (int) ((next - 1) % 4);
                
        next+=paddingNum;
        //operationLength = paddingNum + 1;
        
        int defaultOffset = mergeSignedBytes(subParams(byteContent, next, next+=4));
        
        System.out.println("defaultOffset----"+defaultOffset);
                
        caseBranches.add(new CaseBranch(0, byteIndex + defaultOffset, true));

        switch (getOP()) {
        case TABLESWITCH:
            next =  loadTableSwitch(byteIndex,next,byteContent);
            break;
        case LOOKUPSWITCH:
            next =  loadLookupSwitch(byteIndex,next,byteContent);
            break;
        }
        
        operationLength = next-byteIndex-1;
                        
        System.out.println("operationLength----"+operationLength);

        return operationLength;
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){       
    }

     
    /**
     * 
     * @param startPoint
     * @param next
     * @param byteContent
     * @return
     */
    private int loadTableSwitch(int startPoint,int next, int[] byteContent){
        int low = mergeSignedBytes(subParams(byteContent, next, next+=4));
        int high = mergeSignedBytes(subParams(byteContent, next, next+=4));
        
        //operationLength += 8;

        for (int i = low; i <= high; i++){
            int jumpOffset = mergeSignedBytes(subParams(byteContent, next, next+=4));

            caseBranches.add(new CaseBranch(i, startPoint + jumpOffset, false));
            
        }
                
        return next;
    }
    
    /**
     * 
     * @param startPoint
     * @param next
     * @param byteContent
     * @return
     */
    private int loadLookupSwitch(int startPoint,int next, int[] byteContent){
        int pairNum = mergeSignedBytes(subParams(byteContent, next, next+=4));

        //operationLength += 4;

        for (int i = 0; i < pairNum; i++){
            int key = mergeSignedBytes(subParams(byteContent, next, next+=4));

            int offset = mergeSignedBytes(subParams(byteContent, next, next+=4));
            caseBranches.add(new CaseBranch(key, startPoint + offset, false));
        }
        //operationLength += pairNum * 8;

        return next;
    }
    
    /**
     * 
     * @param begin
     * @param end
     * @param byteContent
     * @return
     */
    private static int[] subParams(int[] byteContent, int begin, int end){
        if(begin >= end ){
            throw new BadFormatException("Range issue, begin should not bigger than end");
        }
        int length = end - begin;
        
        int temp[] = new int[length];
        
        //System.out.printf("begin=%d,end=%d,length=%d,con_len=%d %n",begin,end,length,byteContent.length);
        
        System.arraycopy(byteContent, begin,  temp, 0, length);
        
        return temp;
    }

    /**
     * 
     * @return
     */
    public List<CaseBranch> getCaseBranches() {
        return Collections.unmodifiableList(caseBranches);
    }

    @Override
    public String toString(){
        return String.format(
                "[%s:operationLength=%d,size=%d]", this
                        .getClass().getSimpleName(),operationLength,caseBranches.size());
    }
    
    /**
     * Class hold one case branch.
     *
     */
    public static final class CaseBranch{
        private int value;
        private int offset;
        private boolean isDeafult = false;
        
        CaseBranch(int value,int offset,boolean isDefault){
            this.value = value;
            this.offset = offset;
            this.isDeafult = isDefault;
        }
        
        /**
         * 
         * @return
         */
        public int getValue() {
            return value;
        }

        /**
         * 
         * @return
         */
        public int getOffset() {
            return offset;
        }
        
        /**
         * 
         * @return
         */
        public boolean isDeafult() {
            return isDeafult;
        }

        @Override
        public String toString(){
            return String.format(
                    "[%s:value=%d,offset=%d,isDeafult=%s]", this
                            .getClass().getSimpleName(),value,offset,isDeafult);
        }

    }
}
