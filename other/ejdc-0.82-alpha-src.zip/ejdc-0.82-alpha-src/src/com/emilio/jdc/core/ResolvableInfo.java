package com.emilio.jdc.core;

import java.io.IOException;

/**
 * 
 * @author Emilio Liang
 * 
 * 
 *
 */
public interface ResolvableInfo {
    public void resolve(com.emilio.jdc.core.Class clazz) throws IOException;
}
