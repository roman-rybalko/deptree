package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.OperatorsType;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class NewExpr implements Expression{
    private Value value;
    private OperatorsType operatorSymbol;
    
    /**
     * 
     * @param value
     * @return
     */
    public static NewExpr of(Value value){
        return new NewExpr(value, OperatorsType.NEW);
    }
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     */
    private NewExpr(Value value, OperatorsType operatorSymbol){
        this.value = value;
        this.operatorSymbol = operatorSymbol;
    }
    
    public String toText() {
        StringBuilder text = new StringBuilder(50);
        text.append(operatorSymbol);
        text.append(BLANK_SPACE);
        text.append(value.getValue());
        
        return text.toString();
    }
}
