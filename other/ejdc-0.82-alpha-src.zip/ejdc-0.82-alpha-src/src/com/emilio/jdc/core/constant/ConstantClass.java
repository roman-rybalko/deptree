package com.emilio.jdc.core.constant;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.type.ConstantType;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent CONSTANT_Class table in constant_pool 
 * 
 */
public final class ConstantClass extends Constant {
    private int nameIndex;
    private String className;
    private String classDescName;

    /**
     * Constructor
     * 
     * @param index
     * @param type
     */
    public ConstantClass(int index, ConstantType type) {
        super(index, type);
    }

    @Override
    public void load(ClassInputStream jis) throws IOException {
        nameIndex = jis.readU2();
    }

    @Override
    public void resolve(final Class clazz) {
        ConstantPoolInfo pool = clazz.getPoolInfo();
        classDescName = pool.getContantPoolItem(nameIndex).getValue();
        //TODO copy?
        className = classDescName.replace('/', '.');
    }
    
    /**
     * 
     * @return
     */
    public String getName(){
        return className;
    }
    
    /**
     * 
     * @return
     */
    public String getDescriptorName(){
        return classDescName;
    }

    @Override
    public String getValue() {
        return className;
    }

    @Override
    public int getIndex() {
        return nameIndex;
    }
    
    @Override    
    public int hashCode(){
        //TODO needs to make constant unmutable?
        int result = 17;
        
        result = 31 * result +nameIndex;
        result = 31 * result +className.hashCode();
        
        return  result;
    }
    
    @Override    
    public boolean equals(Object obj){
        //TODO Needs more test.
        if (! (obj instanceof ConstantClass )){
            return false;
        }
        
        ConstantClass cc = (ConstantClass)obj;
        
        return cc.getName().equals(this.getName())&& cc.getIndex() == this.getIndex();
    }

    @Override
    public String toString() {
        return String.format("[%s:index=%d,type=%s,nameIndex=%d,className=%s]",
                this.getClass().getSimpleName(), index, type, nameIndex,
                className);
    }
    
    /**
     * 
     * @param args
     */
    public static void main(String args[]){
//        ConstantClass class1 = new ConstantClass(1, ConstantType.CONSTANT_Class);
//        class1.className = "java.lang.Object";
//        ConstantClass class2 = new ConstantClass(1, ConstantType.CONSTANT_Class);
//        class2.className = "java.lang.Object";
//        ConstantClass class3 = new ConstantClass(1, ConstantType.CONSTANT_Class);
//        class3.className = "java.lang.Test";
//        class3.nameIndex = 1;
//        ConstantClass class4 = new ConstantClass(1, ConstantType.CONSTANT_Class);
//        class4.className = "java.lang.String";
//        
//        System.out.println(class1.hashCode());
//        System.out.println(class2.hashCode());
//        System.out.println(class3.hashCode());
//        System.out.println(class4.hashCode());
//        
//        System.out.println(class1.equals(class2));
//        System.out.println(class3.equals(class3));
//        System.out.println(class1.equals(class3));
//        System.out.println(class2.equals(class4));
    }
}
