package com.emilio.jdc.core.constant;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.type.ConstantType;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent CONSTANT_Double table in constant_pool 
 * 
 */
public final class ConstantDouble extends Constant {
	/**
	 * double value
	 */
    private double doubleVal;

    /**
     * Constructor
     * 
     * @param num
     * @param type
     */
    public ConstantDouble(int num, ConstantType type) {
        super(num, type);
    }

    @Override
    public void load(ClassInputStream jis) throws IOException {
        doubleVal = jis.readDouble();
    }

    @Override
    public void resolve(Class clazz) {
    }

    @Override
    public String getValue() {
        return String.valueOf(doubleVal);
    }

    @Override
    public int getIndex() {
        return 0;
    }

    @Override
    public String toString() {
        return String.format("[%s:index=%d,type=%s,doubleValue=%f]", this
                .getClass().getSimpleName(), index, type, doubleVal);
    }

}
