package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.opcode.ByteCode;
import com.emilio.jdc.core.type.ObjectType;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
//TODO need to check Push name ,should change it to load?
public class ConstPush extends Operation{
    private OperandType type;
    private OperandValue value;
    
    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }

    /**
     * 
     * @param byteCode
     * @param index
     * @param code
     */
    public ConstPush(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
        type = OperandType.of(getOP());
        value = OperandValue.of(getOP());  
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        stack.push(this);
    }
    
    @Override
    public OperandValue getValue(){
        return value;
    }
    
    @Override
    public ObjectType getType(){
        return ObjectType.STRING;
    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:type=%s,value=%s]", this
                        .getClass().getSimpleName(),type,value);
    }
    
    /**
     * 
     * 
     *
     */
    public enum OperandType {
        NONE, NULL, INT, LONG, FLOAT, DOUBLE;

        public static OperandType of(ByteCode opCode) {
            OperandType type = null;

            switch (opCode) {
            case NOP:
                type = NONE;
                break;
            case ACONST_NULL:
                type = NULL;
                break;
            case ICONST_M1:
            case ICONST_0:
            case ICONST_1:
            case ICONST_2:
            case ICONST_3:
            case ICONST_4:
            case ICONST_5:
                type = INT;
                break;
            case LCONST_0:
            case LCONST_1:
                type = LONG;
                break;
            case FCONST_0:
            case FCONST_1:
            case FCONST_2:
                type = FLOAT;
                break;
            case DCONST_0:
            case DCONST_1:
                type = DOUBLE;
                break;
            default:
                throw new RuntimeException("BitArithmetic: unknown opcode");
            }
            return type;
        }
        
        //@Override
        //public String toString(){
        //}
    }
    
    public enum OperandValue {
        NONE(""),
        NULL("null"),
        NEG_ONE("-1"),
        ZERO("0"),
        ONE("1"),
        TWO("2"),
        THREE("3"),
        FOUR("4"),
        FIVE("5");
        
        private String value;
        
        OperandValue(String value){
            this.value = value;
        }
        
        public static OperandValue of(ByteCode opCode) {
            OperandValue value = null;

            switch (opCode) {
            case NOP:
                value = NONE;
                break;
            case ACONST_NULL:
                value = NULL;
                break;
            case ICONST_M1:
                value = NEG_ONE;
                break;
            case ICONST_0:
            case LCONST_0:
            case FCONST_0:
            case DCONST_0:
                value = ZERO;
                break;
            case ICONST_1:
            case LCONST_1:
            case FCONST_1:
            case DCONST_1:
                value = ONE;
                break;
            case ICONST_2:
            case FCONST_2:
                value = TWO;
                break;
            case ICONST_3:
                value = THREE;
                break;
            case ICONST_4:
                value = FOUR;
                break;
            case ICONST_5:
                value = FIVE;
                break;
            default:
                throw new RuntimeException("BitArithmetic: unknown opcode");
            }
            return value;
        }
        
        @Override
        public String toString(){
            return value;
        }
    }
}
