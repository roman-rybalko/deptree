package com.emilio.jdc.core.util;

import java.io.IOException;

/**
 * 
 * @author Emilio Liang
 * 
 * Input stream which define all the operations supported for class file.
 * 
 */
public interface ClassInputStream {
	/**
	 * Read unsigned bytes into int[]
	 * @param buf
	 * @throws IOException
	 */
    public void read(int[] buf) throws IOException;

    /**
     * Read bytes into byte array
     * @param buf
     * @throws IOException
     */
    public void read(byte[] buf) throws IOException;
    
    /**
     * Read 1 unsigned integer into int
     * @return
     * @throws IOException
     */
    public int readU1() throws IOException;

    /**
     * Read 2 unsigned integer into int
     * @return
     * @throws IOException
     */
    public int readU2() throws IOException;

    /**
     * Read 4 unsigned integer into long
     * @return
     * @throws IOException
     */
    public long readU4() throws IOException;

    /**
     * Read float
     * @return
     * @throws IOException
     */
    public float readFloat() throws IOException;

    /**
     * Read double
     * @return
     * @throws IOException
     */
    public double readDouble() throws IOException;

    /**
     * Read int
     * @return
     * @throws IOException
     */
    public int readInt() throws IOException;

    /**
     * Read long
     * @return
     * @throws IOException
     */
    public long readLong() throws IOException;

    /**
     * Read UTF String
     * @return String
     * @throws IOException
     */
    public String readUTF() throws IOException;

    /**
     * Close input stream
     */
    public void close();

    /**
     * Count read bytes
     * @return int
     */
    public int getReadBytes();
}
