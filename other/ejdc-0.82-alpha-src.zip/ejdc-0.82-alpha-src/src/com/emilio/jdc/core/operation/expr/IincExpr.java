package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.attribute.LocalVariableInfo;
import com.emilio.jdc.core.type.OperatorsType;

/**
 * 
 * @author Emilio Liang
 *
 */
public class IincExpr extends AbstractUniOpExpr {
    //TODO needs AbstractUniOpExpr ?
    private LocalVariableInfo localVar;
    private int increment;
    
    /**
     * 
     * @param localVar
     * @param increment
     * @return
     */
    public static IincExpr of(LocalVariableInfo localVar, int increment){
        return new IincExpr(localVar, increment);
    }
    
    /**
     * 
     * @param localVar
     * @param increment
     */
    private IincExpr(LocalVariableInfo localVar, int increment){
        this.localVar = localVar;
        this.increment = increment;
    }
    
    @Override
    public String toText() {
        StringBuilder text = new StringBuilder(50);
        text.append(localVar.getValue());
        
        if (increment == 1){
            text.append(OperatorsType.ADD_ADD);
        }else{
            text.append(BLANK_SPACE);
            text.append(OperatorsType.ADD_ASSIGN);
            text.append(BLANK_SPACE);
            text.append(increment);
        }

        return text.toString();
    }

}
