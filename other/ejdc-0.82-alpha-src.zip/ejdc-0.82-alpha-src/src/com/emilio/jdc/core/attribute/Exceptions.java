package com.emilio.jdc.core.attribute;

import java.io.IOException;
import java.util.Arrays;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class Exceptions extends AttributeInfoItem {
    private int numberOfExceptions;
    private int[] exceptionIndexTable = new int[0];
    private String[] exceptionNameTable = new String[0];

    /**
     * Constructor
     * 
     * @param item
     */
    public Exceptions(AttributeInfoItem item) {
        super(item);
    }
    
    /**
     * 
     */
    public Exceptions() {
        super();
    }

    @Override
    public AttributeInfoItem resolve(Class clazz) throws IOException {
        ConstantPoolInfo pool = clazz.getPoolInfo();
        ClassInputStream cis = getStream();
        numberOfExceptions = cis.readU2();

        if (numberOfExceptions > 0) {
            exceptionIndexTable = new int[numberOfExceptions];
            exceptionNameTable = new String[numberOfExceptions];
            for (int i = 0; i < numberOfExceptions; i++) {
                exceptionIndexTable[i] = cis.readU2();
                int nameIndex = pool.getContantPoolItem(exceptionIndexTable[i]).getIndex();
                exceptionNameTable[i] = pool.getContantPoolItem(nameIndex)
                        .getValue();
            }
        }

        return this;
    }

    @Override
    public String toString() {
        return String.format(
                "[%s:numberOfExceptions=%d,exceptionNameTable=%s]", this
                        .getClass().getSimpleName(), numberOfExceptions,
                        Arrays.toString(exceptionNameTable));
    }
}
