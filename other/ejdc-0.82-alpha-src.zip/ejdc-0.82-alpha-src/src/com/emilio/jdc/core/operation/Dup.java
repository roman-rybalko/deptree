package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Dup extends Operation{

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public Dup(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        Operation value1 = stack.pop();
        
        //TODO needs to handle double and long?
        switch (this.getOP()){
        case DUP: 
            stack.push(value1);
            stack.push(value1);
            break;
        case DUP_X1:
            Operation value2 = stack.pop();
            stack.push(value1);
            stack.push(value2);
            stack.push(value1);
            break;
        case DUP_X2: break;        
        case DUP2: break;        
        case DUP2_X1: break;        
        case DUP2_X2: break;        
        }
        
//        DUP(89, "dup", "Duplicate the top operand stack value", 0, -1, OperandType.STACK),                                                                                                                                                                                                                                                                                  
//        DUP_X1(90, "dup_x1", "Duplicate the top operand stack value and insert two values down", 0, -1, OperandType.STACK),
//        DUP_X2(91, "dup_x2", "Duplicate the top operand stack value and insert two or three values down", 0, -1, OperandType.STACK),
//        DUP2(92, "dup2", "Duplicate the top one or two operand stack values", 0, -1, OperandType.STACK),                                                                                                                                                                                                                                                          
//        DUP2_X1(93, "dup2_x1", "Duplicate the top one or two operand stack values and insert two or three values down", 0, -1, OperandType.STACK),                                                                                                                                                                                                                              
//        DUP2_X2(94, "dup2_x2", "Duplicate the top one or two operand stack values and insert two, three, or four values down", 0, -1, OperandType.STACK),                                                                                                                                                                                                                       
//
//
//        int shift = ((Dup) operation).getStackShift();
//        switch (shift)
//        {
//            case 0:
//            {
//                context.push(value1);
//                context.push(value1);
//                break;
//            }
//            case 1:
//            {
//                OperationView value2 = context.pop();
//                context.push(value1);
//                context.push(value2);
//                context.push(value1);
//                break;
//            }
//            case 2:
//            {
//                OperationView value2 = context.pop();
//                String v2pushType = value2.getPushType();
//                if ("double".equals(v2pushType) || "long".equals(v2pushType))   //Category 2
//                {
//                    context.push(value1);
//                    context.push(value2);
//                    context.push(value1);
//                }
//                else
//                {
//                    OperationView value3 = context.pop();
//                    context.push(value1);
//                    context.push(value3);
//                    context.push(value2);
//                    context.push(value1);
//                }
//                break;
//            }
//        }
        
        
        
//        int shift = ((Dup2) operation).getStackShift();
//        switch (shift)
//        {
//            case 0:
//            {
//                OperationView value1 = context.pop();
//                if (isCat2(value1))
//                {
//                    context.push(value1);
//                    context.push(value1);
//                }
//                else
//                {
//                    OperationView value2 = context.pop();
//                    context.push(value2);
//                    context.push(value1);
//                    context.push(value2);
//                    context.push(value1);
//                }
//                break;
//            }
//            case 1:
//            {
//                OperationView value1 = context.pop();
//                if (isCat2(value1))
//                {
//                    OperationView value2 = context.pop();
//                    context.push(value1);
//                    context.push(value2);
//                    context.push(value1);
//                }
//                else
//                {
//                    OperationView value2 = context.pop();
//                    OperationView value3 = context.pop();
//                    context.push(value2);
//                    context.push(value1);
//                    context.push(value3);
//                    context.push(value2);
//                    context.push(value1);
//                }
//                break;
//            }
//            case 2:
//            {
//                OperationView value1 = context.pop();
//                if (isCat2(value1))
//                {
//                    OperationView value2 = context.pop();
//                    if (isCat2(value2))
//                    {
//                        context.push(value1);
//                        context.push(value2);
//                        context.push(value1);
//                    }
//                    else
//                    {
//                        OperationView value3 = context.pop();
//                        context.push(value1);
//                        context.push(value3);
//                        context.push(value2);
//                        context.push(value1);
//                    }
//                }
//                else
//                {
//                    OperationView value2 = context.pop();
//                    OperationView value3 = context.pop();
//                    if (isCat2(value3))
//                    {
//                        context.push(value2);
//                        context.push(value1);
//                        context.push(value3);
//                        context.push(value2);
//                        context.push(value1);
//                    }
//                    else
//                    {
//                        OperationView value4 = context.pop();
//                        context.push(value2);
//                        context.push(value1);
//                        context.push(value4);
//                        context.push(value3);
//                        context.push(value2);
//                        context.push(value1);
//                    }
//                }
//                break;
//            }
//        }
    }


}
