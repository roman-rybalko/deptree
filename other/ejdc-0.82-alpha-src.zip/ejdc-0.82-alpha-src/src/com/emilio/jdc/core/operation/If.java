package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.exception.UnsupportedTypeException;
import com.emilio.jdc.core.opcode.ByteCode;
import com.emilio.jdc.core.operation.expr.IfConditionCmpExpr;
import com.emilio.jdc.core.operation.expr.IfConditionNullExpr;
import com.emilio.jdc.core.operation.expr.IfConditionZeroExpr;
import com.emilio.jdc.core.type.ConditionType;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class If extends Operation{
    private int targetIndex;
    private ConditionType condition;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public If(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void parseParams() {
        int offset = mergeSignedBytes(parameters[ZERO],this.parameters[ONE]);
        targetIndex = getByteIndex() + offset;
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){        
        ByteCode code = getOP();
        condition = ConditionType.fromByte(code);
        
        if (code.isInRange(ByteCode.IFEQ, ByteCode.IFLE) ){
            expr = IfConditionZeroExpr.of(stack.pop(), condition);
        }else if (code.isInRange(ByteCode.IF_ICMPEQ, ByteCode.IF_ACMPNE) ){
            expr = IfConditionCmpExpr.of(stack.pop(),stack.pop(), condition);            
        }else if (code.isInRange(ByteCode.IFNULL, ByteCode.IFNULL) ){
            expr = IfConditionNullExpr.of(stack.pop(), condition);
        }else{
            throw new UnsupportedTypeException(code.toString());
        }
        
    }
    
    /**
     * 
     * @return
     */
    public int getTargetIndex() {
        return targetIndex;
    }

    /**
     * 
     * @return
     */
    public boolean isForward(){
        return targetIndex > super.getByteIndex();
    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:offset=%d]", this.getClass().getSimpleName(),targetIndex);
    }
}
