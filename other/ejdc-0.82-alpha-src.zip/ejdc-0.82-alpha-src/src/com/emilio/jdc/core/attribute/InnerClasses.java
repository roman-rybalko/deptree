package com.emilio.jdc.core.attribute;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class InnerClasses extends AttributeInfoItem {
    private int numberOfClasses;
    private List<InnerClassInfo> innerClassInfos = new ArrayList<InnerClassInfo>();

    public InnerClasses(AttributeInfoItem item) {
        super(item);
    }
    
    @Override
    public AttributeInfoItem resolve(Class clazz) throws IOException {
        ClassInputStream cis = super.getStream();
        numberOfClasses = cis.readU2();
        innerClassInfos = loadInfoTables(numberOfClasses, InnerClassInfo.class,
                cis);
        resovleInfoTables(innerClassInfos,clazz);
        
        for(InnerClassInfo info:innerClassInfos){
            System.out.println("innerClass---"+info);
        }
        
        return this;
    }

    @Override
    public String toString() {
        return String.format("[%s:numberOfClasses=%s,constName=%s]", this
                .getClass().getSimpleName(), numberOfClasses, innerClassInfos);
    }

}
