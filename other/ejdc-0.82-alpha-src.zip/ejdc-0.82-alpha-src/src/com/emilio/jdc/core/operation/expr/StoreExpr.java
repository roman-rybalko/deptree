package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.attribute.LocalVariableInfo;
import com.emilio.jdc.core.type.OperatorsType;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class StoreExpr extends AbstractBinaryOpExpr{
    private LocalVariableInfo localVar;
    private Value value;
    
    /**
     * 
     * @param localVar
     * @param value
     * @return
     */
    public static StoreExpr of(LocalVariableInfo localVar, Value value){
        return new StoreExpr(localVar, value, OperatorsType.ASSIGN);
    }
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     */
    private StoreExpr(LocalVariableInfo localVar, Value value,OperatorsType operatorSymbol){
        this.localVar = localVar;
        this.value = value;
        this.operatorSymbol = operatorSymbol;
    }
    
    
    @Override
    public String toText() {
        StringBuilder text = new StringBuilder(50);
        //view = new Object[]{lvar.getView(), " = ", pushOp};

        //TODO better way to handle this ?
        if (localVar.getFieldDesc().isArray()){
            text.append(localVar.getFieldDesc().getArrayValue());
        }else{
            text.append(localVar.getFieldDesc().getValue());         
        }
        
        text.append(localVar.getLocalVarName());
        text.append(getOperatorSymbol());
        text.append(value.getValue());
                
        return text.toString();
    }
    
    
    //view = new Object[]{lvar.getView(), " = ", pushOp};

}
