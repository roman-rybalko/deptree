package com.emilio.jdc.core.operation.expr;

import java.util.List;

import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public interface InvokeExpr extends Expression{
    //public void setMethodRef(SootMethodRef smr);
    //public SootMethodRef getMethodRef();
    //public SootMethod getMethod();
    public List<? extends Value> getArgs();
    public Value getArg(int index);
    public int getArgCount();
    //public void setArg(int index, Value arg);
    //public ValueBox getArgBox(int index);
    //TODO need handle this.
    //public Type getType();
   
}
