package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class ArrayLengthExpr extends AbstractUniOpExpr{
    private static final String LENGTH = ".length";
    
    /**
     * 
     * @param value
     * @param operator
     * @return
     */
    public static ArrayLengthExpr of(Value value){
        return new ArrayLengthExpr(value);
    }
    
    /**
     * 
     * @param value
     * @param operator
     */
    private ArrayLengthExpr(Value value){
        this.value = value;
    }
    
    @Override
    public String toText(){
        StringBuilder text = new StringBuilder(50);
        text.append(value.getValue());
        text.append(LENGTH);
        
        return text.toString();
    }
}
