package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.operation.Goto;
import com.emilio.jdc.core.operation.Operation;

/**
 * 
 * @author Emilio Liang
 *
 */
public class LoopExpr implements Expression{
    private boolean isBreak;
    private boolean isContinue;
    private Operation value;
    
    public static LoopExpr of(Operation value,boolean isBreak,boolean isContinue){
        return new LoopExpr(value,isBreak,isContinue);
    }
    
    private LoopExpr(Operation value,boolean isBreak,boolean isConitnue){
        this.isBreak = isBreak;
        this.isContinue = isConitnue;
        this.value = value;
    }
    
    public String toText() {
        if (isBreak) {
            return "break";
        } else if (isContinue) {
            return "continue";
            //TODO
//        } else if (loop != null) {
//            // Print nothing
//            return null;
        } else {
            return "goto " + ((Goto)value).getTargetIndex();
        }
    }
}
