package com.emilio.jdc.core.constant;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.MethodDescriptor;
import com.emilio.jdc.core.type.ConstantType;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent CONSTANT_InterfaceMethodref table in constant_pool 
 * 
 */
public final class ConstantInterfaceMethodRef extends ConstantRefType {
    private MethodDescriptor methodDescriptor;
    
    /**
     * Constructor
     * 
     * @param index
     * @param type
     */
    public ConstantInterfaceMethodRef(int index, ConstantType type) {
        super(index, type);
    }
    
    @Override 
    public void resolve(Class clazz) {
        //TODO should duplicate code with ConstantMethodRef

        super.resolve(clazz);

        methodDescriptor = new MethodDescriptor();
        
        methodDescriptor.parse(refNameAndType.getDescriptor());
    }

    /**
     * 
     * @return
     */
    public MethodDescriptor getMethodDescriptor() {
        return methodDescriptor;
    }
}
