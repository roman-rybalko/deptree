package com.emilio.jdc.core.operation.expr;

/**
 * 
 * @author Emilio Liang
 *
 */
public class UniOperandArithmeticExpr {

}
