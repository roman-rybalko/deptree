package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public interface BinaryOpExpr extends Expression{
    public Value getOp1();
    public Value getOp2();
    public void setOp1(Value op1);
    public void setOp2(Value op2);
    public String getOperatorSymbol();
    public String toString();
}
