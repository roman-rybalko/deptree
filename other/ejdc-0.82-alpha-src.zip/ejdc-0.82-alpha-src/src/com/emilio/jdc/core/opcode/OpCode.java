package com.emilio.jdc.core.opcode;

/**
 * 
 * @author Emilio Liang
 *
 */
public interface OpCode {
    public int getByteCode();
    public String getDescription();
    public String getMnemonic();
    public int getParamByteNum();
}
