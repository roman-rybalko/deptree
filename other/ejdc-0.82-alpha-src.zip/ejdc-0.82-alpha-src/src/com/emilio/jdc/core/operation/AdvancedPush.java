package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.MethodInfoItem;
import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.constant.Constant;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class AdvancedPush extends Operation {
    private Object value;
    private int index;
    //private Constant constant;

    /**
     * 
     */
    public AdvancedPush(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    } 
    
    @Override
    public void parseParams() {
        switch(getOP()){
        case  BIPUSH: 
            value = toSignedByte(parameters[ZERO]);
            break;
        case  SIPUSH:
            value = mergeSignedBytes(parameters[ZERO],parameters[ONE]);
            break;
        case  LDC:
            index = parameters[ZERO];
            break;
        case  LDC_W:
            index = mergeUnsignedBytes(parameters[ZERO],parameters[ONE]);
            break;
        case  LDC2_W:
            index = mergeUnsignedBytes(parameters[ZERO],parameters[ONE]);
            break;        
        
        }
    }
    
    @Override
    public void resolve(MethodInfoItem method){
        ConstantPoolInfo  pool = method.getMethodClass().getPoolInfo();
        
        switch(getOP()){
        case  LDC:
        case  LDC_W:
        case  LDC2_W:
            Constant constant = pool.getContantPoolItem(index);
            value = constant.getValue();
        }
    }
    
    @Override 
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        stack.push(this);
    }

    @Override 
    public Object getValue(){
        return value;
    }
}
