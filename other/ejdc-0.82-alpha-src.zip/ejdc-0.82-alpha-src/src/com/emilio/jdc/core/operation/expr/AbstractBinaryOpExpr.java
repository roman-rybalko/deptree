package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.Symbol;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public abstract class AbstractBinaryOpExpr implements BinaryOpExpr {
    Value value1;
    Value value2;
    Symbol operatorSymbol;
    
    /**
     * Constructor
     */
    AbstractBinaryOpExpr(){
    }
    
    /**
     * Constructor
     * @param value1
     * @param value2
     * @param operatorSymbol
     */
    AbstractBinaryOpExpr(Value value1, Value value2, Symbol operatorSymbol){
        this.value1 = value1;
        this.value2 = value2;
        this.operatorSymbol = operatorSymbol;
    }

    AbstractBinaryOpExpr(Value value1, Value value2){
        this.value1 = value1;
        this.value2 = value2;
    }

    public abstract String toText();
    
    public Value getOp1() {
        return value1;
    }

    public Value getOp2() {
        return value2;
    }

    public void setOp1(Value value1) {
        this.value1 = value1;
    }

    public void setOp2(Value value2) {
        this.value2 = value2;
    }

    public String getOperatorSymbol() {
        return operatorSymbol.toSymbol();
    }
}
