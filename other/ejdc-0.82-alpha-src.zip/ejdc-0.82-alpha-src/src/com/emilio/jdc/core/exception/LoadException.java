package com.emilio.jdc.core.exception;

/**
 * 
 * @author Emilio Liang
 *
 */
public class LoadException extends RuntimeException {
    /**
     * serialVersionUID used to identify the version of the serializable object
     */
    private static final long serialVersionUID = -2378533339531501584L;
    private static final String DEFAULT_MESSAGE = "Class format validation error";

    public LoadException() {
        this(DEFAULT_MESSAGE);
    }

    public LoadException(String message) {
        super(message);
    }

    public LoadException(String message, Throwable cause) {
        super(message, cause);
    }

    public LoadException(Throwable cause) {
        super(cause);
    }

}
