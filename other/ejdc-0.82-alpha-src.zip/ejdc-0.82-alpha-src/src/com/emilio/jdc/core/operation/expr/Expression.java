package com.emilio.jdc.core.operation.expr;

/**
 * 
 * @author Emilio Liang
 *
 */
public interface Expression extends Marker{

    public String toText();
}
