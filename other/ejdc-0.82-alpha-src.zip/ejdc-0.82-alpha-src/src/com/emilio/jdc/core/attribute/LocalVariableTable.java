package com.emilio.jdc.core.attribute;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class LocalVariableTable extends AttributeInfoItem {
    private int localVariableTableLen;

    // private List<LocalVariableInfo> localVariableInfo = new
    // ArrayList<LocalVariableInfo>(0);.

    //private Map<Integer, LocalVariableInfo> table = new TreeMap<Integer, LocalVariableInfo>();
    private Map<Integer, List<LocalVariableInfo>> table = new TreeMap<Integer, List<LocalVariableInfo>>();

    /**
     * Constructor
     * 
     * @param item
     */
    public LocalVariableTable(AttributeInfoItem item) {
        super(item);
    }

    @Override
    public AttributeInfoItem resolve(Class clazz) throws IOException {
        ClassInputStream cis = getStream();
        localVariableTableLen = cis.readU2();
        // List<LocalVariableInfo> list = loadInfoTables(localVariableTableLen,
        // LocalVariableInfo.class, cis);
        // resovleInfoTables(list,clazz);

        loadInfoTables(localVariableTableLen, clazz, cis);

        return this;
    }

    /**
     * 
     * @param infoTableSize
     * @param clazz
     * @param cis
     */
    private void loadInfoTables(int infoTableSize, Class clazz,
            ClassInputStream cis) {

        if (infoTableSize > 0) {
            for (int i = 0; i < infoTableSize; i++) {
                try {
                    LocalVariableInfo local = new LocalVariableInfo();
                    local.index = i;
                    local.load(cis);
                    local.resolve(clazz);

                    // list.add(local);
                    // System.out.println(local);
                    //put(i, local);
                      put(local.getSlotNum(), local);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    //TODO new 
    private void put(int varNum, LocalVariableInfo localInfo) {
        List<LocalVariableInfo> list = table.get(varNum);
        
        if (list == null){
            list = new ArrayList<LocalVariableInfo>();
            list.add(localInfo);
            table.put(varNum, list);
        }else{
            list.add(localInfo);
        }
    }

    
    /**
     * 
     * @param slotNum
     * @param localInfo
     */
//    private void put(int varNum, LocalVariableInfo localInfo) {
//        // need check here?
//        LocalVariableInfo localVar = table.get(Integer.valueOf(varNum));
//
//        if (localVar != null) {
//            throw new BadFormatException(String.format(
//                    "Can't find local var by varNum=%d", varNum));
//        } else {
//            table.put(Integer.valueOf(varNum), localInfo);
//        }
//    }

    //TODO new 
    public LocalVariableInfo get(int varNum, int startPc) {
        List<LocalVariableInfo> list = table.get(varNum);

        if (list != null) {
            if (list.size() == 1) {
                return list.get(0);
            } else {
                for (LocalVariableInfo local : list) {
                    // TODO

                    if (startPc >= local.getStartPc()
                            && startPc <= local.getEndPc()) {
                        return local;
                    }
                }
                return null;
            }
        }else{
            return null;
        }
    }
    
    /**
     * 
     * @param slotNum
     * @param byteIndex
     * @return LocalVariableInfo
     */

//    public LocalVariableInfo get(int varNum, int byteIndex) {
//        LocalVariableInfo localVar = table.get(Integer.valueOf(varNum));
//
//        if (localVar == null) {
//            throw new BadFormatException(String.format(
//                    "Can't find local var by varNum=%d, byteIndex=%d", varNum,
//                    byteIndex));
//        } else {
//            // TODO need refactor ?
//            LocalVariableInfo resultLocal = localVar;
//
//            //if (byteIndex >= localVar.getStartPc()
//            //        && byteIndex <= localVar.getEndPc()) {
//            //    resultLocal = localVar;
//            //}
//
//            if (resultLocal != null) {
//                return resultLocal;
//            } else {
//                throw new BadFormatException(String.format(
//                        "Can't find local var by varNum=%d, byteIndex=%d",
//                        varNum, byteIndex));
//            }
//        }
//    }
    /**
     * 
     * @return
     */
    public int size() {
        return table.size();
    }

    @Override
    public String toString() {
        return String.format("[%s:localVariableTableLen=%d]", this.getClass()
                .getSimpleName(), localVariableTableLen);
    }
}
