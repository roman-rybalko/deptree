package com.emilio.jdc.core.type.access;

/**
 * 
 * @author Emilio Liang
 * 
 */
public enum FieldAccFlagType implements AccessFlag {
    PUBLIC    (0x0001),
    PRIVATE   (0x0002),
    PROTECTED (0x0004),
    STATIC    (0x0008),
    FINAL     (0x0010),
    VOLATILE  (0x0040),
    TRANSIENT (0x0080),
    SYNTHETIC (0x1000),
    ENUM      (0x4000);

    private int accessFlag;

    private FieldAccFlagType(int accessFlag) {
        this.accessFlag = accessFlag;
    }

    public int getAccessFlag() {
        return accessFlag;
    }
    
    @Override
    public String toString(){
        return super.toString().toLowerCase();
    }
}
