package com.emilio.jdc.core.operation.expr;

/**
 * 
 * @author Emilio Liang
 *
 */
public class InvokeVirtualExpr extends AbstractInvokeInstanceExpr{
    
    @Override
    public String toText() {
        return null;
    }
}
