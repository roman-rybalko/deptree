package com.emilio.jdc.core.type;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum BaseType implements Symbol{
    B,
    C,
    D,
    F,
    I,
    J,
    S,
    Z,
    V;

    @Override
    public String toString() {
        switch (this) {
        case B:
            return "byte";
        case C:
            return "char";
        case D:
            return "double";
        case F:
            return "float";
        case I:
            return "int";
        case J:
            return "long";
        case S:
            return "short";
        case Z:
            return "boolean";
        case V:
            return "void";
        default:
            return "undefined";
        }
    }
    
    public String toSymbol(){
        return this.toString();
    }
}
