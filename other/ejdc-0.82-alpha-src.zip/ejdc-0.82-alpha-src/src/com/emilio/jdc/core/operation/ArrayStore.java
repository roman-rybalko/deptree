package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.operation.expr.ArrayStoreExpr;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class ArrayStore extends Operation {
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public ArrayStore(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack,
            LocalVariableTable table) {
        // TODO Auto-generated method stub
        Operation arrayValue = stack.pop();
        Operation arrayIndex = stack.pop();
        Operation arrayRef = stack.pop();
        
        expr = ArrayStoreExpr.of(arrayRef, arrayIndex, arrayValue);
        
        // Support array initialization : new Object[]{...}
        //if (arrayRef.startsWith("new "))
        
        
        if (stack.size() > 0){
            Operation preOp = context.peek();
            if (preOp.getType().equals(OperationType.NEWARRAY)){        
                //((NewArrayView) prev).addInitVariable(arrayValue);
                //Block block ;
                //block.removeCurrentOperation();
            }
        }
    }
    
    @Override
    public Object getValue(){
        return expr.toText();
    }
}
