package com.emilio.jdc.core;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Collections;
import java.util.Set;

import com.emilio.jdc.core.attribute.AttributeInfo;
import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.type.access.AccessFlagTypeUtil;
import com.emilio.jdc.core.type.access.AccessType;
import com.emilio.jdc.core.type.access.FieldAccFlagType;
import com.emilio.jdc.core.util.ClassInputStream;

public final class FieldInfoItem implements LoadableInfo, AccessType, Expression{
    private int accessFlags;
    private int nameIndex;
    private int descIndex;
    private String fieldName;
    private String fieldDescStr;
    private AttributeInfo attrInfo;
    private FieldDescriptor fieldDesc;
    private Set<FieldAccFlagType> fieldAccFlagSet = Collections.emptySet();

    /**
     * Constructor
     */
    public FieldInfoItem() {
    }

    /**
     * 
     * @return
     */
    public String getFieldName() {
        return fieldName;
    }

    /**
     * 
     * @return
     */
    public String getFieldDescStr() {
        return fieldDescStr;
    }

    /**
     * 
     */
    public void load(ClassInputStream cis) throws IOException {
        accessFlags = cis.readU2();
        nameIndex = cis.readU2();
        descIndex = cis.readU2();

        attrInfo = new AttributeInfo();

        attrInfo.load(cis);
    }

    /**
     * 
     * @return
     */
    public Set<FieldAccFlagType> getAccFlagSet() {
        return fieldAccFlagSet;
    }

    /**
     * 
     * @param clazz
     * @throws IOException
     */
    public void resolve(Class clazz) throws IOException {
        ConstantPoolInfo pool = clazz.getPoolInfo();

        fieldAccFlagSet = AccessFlagTypeUtil.ofAccFlagSet(
                FieldAccFlagType.class, accessFlags);
        fieldName = pool.getContantPoolItem(nameIndex).getValue();
        fieldDescStr = pool.getContantPoolItem(descIndex).getValue();
        attrInfo.resolve(clazz);
        
        fieldDesc = new FieldDescriptor();
        fieldDesc.parse(fieldDescStr);
    }
    
    public String toText(){
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        print(pw);
        return sw.toString();
    }
    
    /**
     * 
     * @param pw
     */
    void print(PrintWriter pw) {
        for (FieldAccFlagType accFlag : fieldAccFlagSet) {
            pw.print(accFlag);
            pw.print(" ");
        }

        fieldDesc.print(pw);

        pw.print(fieldName);
        
        pw.println();
    }
    

    @Override
    public String toString() {
        return String.format("[%s:nameIndex=%d,descIndex=%d,accessFlags=%d,fieldName=%s,fieldDescStr=%s,attrInfo:%s]",
                        this.getClass().getSimpleName(),
                        nameIndex, 
                        descIndex,
                        accessFlags, 
                        fieldName,
                        fieldDesc,
                        attrInfo);
    }
}
