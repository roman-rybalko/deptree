package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public abstract class AbstractInvokeInstanceExpr extends AbstractInvokeExpr {
    protected Value refObj;
    
    public String toText(){
        StringBuilder buffer = new StringBuilder();
        
        buffer.append(LEFT_PARENTHESIS);
        
        //buffer.append(Jimple.STATICINVOKE + " " + methodRef.getSignature() + "(");
        buffer.append(refObj);
        buffer.append(DOT);        
        buffer.append(methodName);
        buffer.append(LEFT_PARENTHESIS);
        
        for(int i = 0; i < arguments.size(); i++){
            if(i != 0){
                buffer.append(", ");
            }

            buffer.append(arguments.get(i).getValue());
        }

        buffer.append(RIGHT_PARENTHESIS);
        buffer.append(RIGHT_PARENTHESIS);

        return buffer.toString();
    }
        
    public Value getRefObj(){
        return refObj;
    }

    //public ValueBox getBaseBox()
    //{
    //    return baseBox;
    //}

    public void setRefObj(Value refObj){
        this.refObj = refObj;
    }

}
