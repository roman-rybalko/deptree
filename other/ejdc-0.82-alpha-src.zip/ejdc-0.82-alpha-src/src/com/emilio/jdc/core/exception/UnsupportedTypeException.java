package com.emilio.jdc.core.exception;

/**
 * 
 * @author Emilio Liang
 *
 */
public class UnsupportedTypeException extends RuntimeException {

    /**
     * serialVersionUID used to identify the version of the serializable object
     */
    private static final long serialVersionUID = 1557722159321412894L;
    
    private static final String DEFAULT_MESSAGE = "Unsupported data type";

    public UnsupportedTypeException() {
        this(DEFAULT_MESSAGE);
    }

    public UnsupportedTypeException(String message) {
        super(message);
    }

    public UnsupportedTypeException(String message, Throwable cause) {
        super(message, cause);
    }

    public UnsupportedTypeException(Throwable cause) {
        super(cause);
    }
}
