package com.emilio.jdc.core.type.access;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * 
 * @author Emilio Liang
 * 
 * Access flag utility to extract all the supported flags in one access flag.
 * This class is build with generic types to support all enum based classes;
 *
 */
public class AccessFlagTypeUtil {

    public static void main(String args[]){
        System.out.println(toString(ClassAccFlagType.class, 0x011));;
    }

    /**
     * CreateAccFlagSet
     * 
     * @param <T>
     * @param e
     * @param accessFlags
     * @return Set<T>
     */
    public static <T extends Enum<T> & AccessFlag> Set<T> ofAccFlagSet(
            Class<T> type, int accessFlags) {

        List<T> accFlagList = new ArrayList<T>();
        try {
            Method method = type.getMethod("values");

            @SuppressWarnings(value = { "unchecked" })
            T[] enumVals = (T[]) method.invoke(new Object[0]);

            for (T accFlag : enumVals) {
                if ((accessFlags & accFlag.getAccessFlag()) != 0) {
                    accFlagList.add(accFlag);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        if (accFlagList.size() > 0) {
            return Collections.synchronizedSet(EnumSet.copyOf(accFlagList));
        } else {
            return Collections.synchronizedSet(EnumSet.noneOf(type));
        }
    }
    
    /**
     * 
     * @param <T>
     * @param type
     * @param accessFlags
     * @return String
     */
    public static <T extends Enum<T> & AccessFlag> String toString(Class<T> type, int accessFlags){
        Set<T> set = ofAccFlagSet(type,accessFlags);
        
        StringBuilder content = new StringBuilder();
        for(T accFlag : set){
            content.append(accFlag.name().toLowerCase());
            content.append(" ");
        }
        
        return content.toString();
    }
}
