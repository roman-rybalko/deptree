package com.emilio.jdc.core.util;

/**
 * Container designed to hold two different generic types
 * 
 * @param <A>
 * @param <B>
 * 
 */
public final class Pair<A, B> {
    public final A first;
    public final B second;

    /**
     * Private Constructor
     * 
     * @param first
     * @param second
     */
    private Pair(A first, B second) {
        this.first = first;
        this.second = second;
    }

    /**
     * Factory method
     * 
     * @param <A>
     * @param <B>
     * @param first
     *            the first element in the pair
     * @param second
     *            the second element in the pair
     * @return
     */
    public static <A, B> Pair<A, B> of(A first, B second) {
        return new Pair<A, B>(first, second);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (!getClass().equals(obj.getClass())) {
            return false;
        }
        @SuppressWarnings(value = { "unchecked" })
        final Pair<A,B> other = (Pair<A,B>) obj;
        if (this.first != other.first
                && (this.first == null || !this.first.equals(other.first))) {
            return false;
        }
        if (this.second != other.second
                && (this.second == null || !this.second.equals(other.second))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 17;
        hash = 31 * hash + (this.first != null ? this.first.hashCode() : 0);
        hash = 31 * hash + (this.second != null ? this.second.hashCode() : 0);
        return hash;
    }

    @Override
    public String toString() {
        return String.format("Pair[first=%s,second=%s]", first, second);
    }
}
