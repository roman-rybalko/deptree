package com.emilio.jdc.core.type;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum ReturnType implements Symbol{
    BASE(FieldType.BASE),
    OBJECT(FieldType.OBJECT),
    ARRAY(FieldType.ARRAY),
    VOID(null);
    
    private static final Map<FieldType,ReturnType> MAP = new HashMap<FieldType,ReturnType>();
    
    static{
        for(ReturnType type: ReturnType.values()){
            //TODO ugly here;
            MAP.put(type.type, type);
        }
    }
    
    private final FieldType type;
    
    private ReturnType(FieldType type){
        this.type = type;
    }
    
    public static ReturnType fromFieldType(FieldType type){
        return MAP.get(type);
    }
        
    public String toSymbol(){
        return super.toString().toLowerCase();
    }
    
    public static void main(String args[]){
        System.out.println(fromFieldType(FieldType.ARRAY));
        System.out.println(ReturnType.OBJECT.toSymbol());

    }
}
