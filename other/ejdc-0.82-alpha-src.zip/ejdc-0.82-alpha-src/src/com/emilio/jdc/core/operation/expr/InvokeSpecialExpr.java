package com.emilio.jdc.core.operation.expr;

import java.util.List;

import com.emilio.jdc.core.operation.Invoke;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class InvokeSpecialExpr extends AbstractInvokeInstanceExpr{
    
    public static InvokeSpecialExpr of(Value refObj, String methodName, List<? extends Value> arguments, Invoke.SpecialInvokeType type){
        return new InvokeSpecialExpr(refObj, methodName, arguments, type);
    }
    
    private InvokeSpecialExpr(Value refObj, String methodName, List<? extends Value> arguments, Invoke.SpecialInvokeType type){
        this.refObj = refObj;
        this.methodName = methodName;
        this.arguments = arguments;
    }

}
