package com.emilio.jdc.core.attribute;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class ConstantValue extends AttributeInfoItem {
    private int constIndex;
    private String constName;

    /**
     * Constructor
     * 
     * @param item
     */
    public ConstantValue(AttributeInfoItem item) {
        super(item);
    }

    /**
     * Constructor
     */
    public ConstantValue() {
        super();
    }
    
    @Override
    public AttributeInfoItem resolve(Class clazz) throws IOException {
        ConstantPoolInfo  pool = clazz.getPoolInfo();
        ClassInputStream cis = getStream();
        constIndex = cis.readU2();
        
        //System.out.println("constIndex="+constIndex);
        
        // TODO const index where to get
        constName = pool.getContantPoolItem(constIndex).getValue();

        return this;
    }

    public String getConstName() {
        return constName;
    }

    @Override
    public String toString() {
        return String.format("[%s:constIndex=%d,constName=%s]", this.getClass()
                .getSimpleName(), constIndex, constName);
    }
}
