package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.operation.expr.ArrayLengthExpr;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class ArrayLength extends Operation{
    
    public ArrayLength(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override 
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        expr = ArrayLengthExpr.of(stack.pop());
        stack.push(this);
    }
    
    @Override
    public Object getValue(){
        return expr.toText();
    }
}
