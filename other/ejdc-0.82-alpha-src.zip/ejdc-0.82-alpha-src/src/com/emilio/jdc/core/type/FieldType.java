package com.emilio.jdc.core.type;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum FieldType {
    BASE,
    OBJECT,
    ARRAY;
    
    @Override
    public String toString(){
        return super.toString().toLowerCase();
    }
}
