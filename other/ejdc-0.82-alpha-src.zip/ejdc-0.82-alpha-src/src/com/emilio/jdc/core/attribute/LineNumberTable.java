package com.emilio.jdc.core.attribute;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class LineNumberTable extends AttributeInfoItem {
//    LineNumberTable_attribute {
//        u2 attribute_name_index;
//        u4 attribute_length;
//        u2 line_number_table_length;
//        { u2 start_pc;
//        u2 line_number;
//        } line_number_table[line_number_table_length];
//        }
    
    private int lineNumberTableLen;
    private List<LineNumberInfo> lineNumberInfo = new ArrayList<LineNumberInfo>();
    private Map<Integer,Integer> table = new TreeMap<Integer,Integer>();

    public LineNumberTable(AttributeInfoItem item) {
        super(item);
    }
    
    public int getLineNumber(int startPc){
        System.out.println("table-----"+table);
        System.out.println("startPc----"+startPc);
        return table.get(startPc);
    }

    @Override
    public AttributeInfoItem resolve(Class clazz) throws IOException {
        ClassInputStream cis = getStream();
        lineNumberTableLen = cis.readU2();
        lineNumberInfo = loadInfoTables(lineNumberTableLen,
                LineNumberInfo.class, cis);
        
        for(LineNumberInfo info : lineNumberInfo){
            table.put(info.getLineNumber(),info.getStartPc());
        }
        
        return this;
    }

    @Override
    public String toString() {
        return String.format("[%s:lineNumberTableLen=%d,lineNumberInfo=%s]",
                this.getClass().getSimpleName(), lineNumberTableLen,
                lineNumberInfo);
    }
}
