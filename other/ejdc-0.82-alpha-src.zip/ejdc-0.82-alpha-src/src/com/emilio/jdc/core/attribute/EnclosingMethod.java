package com.emilio.jdc.core.attribute;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class EnclosingMethod extends AttributeInfoItem {
    // EnclosingMethod_attribute {
    // u2 attribute_name_index;
    // u4 attribute_length;
    // u2 class_index
    // u2 method_index;
    // }

    private int classIndex;
    private int methodIndex;
    
    /**
     * Constructor
     * 
     * @param item
     */
    public EnclosingMethod(AttributeInfoItem item) {
        super(item);
    }

    @Override
    public AttributeInfoItem resolve(Class clazz) throws IOException {
       ConstantPoolInfo pool = clazz.getPoolInfo();
       ClassInputStream cis = super.getStream();
       classIndex = cis.readU2();
       methodIndex = cis.readU2();
       
       //TODO
       pool.getContantPoolItem(classIndex);
       pool.getContantPoolItem(methodIndex);
       
        return this;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }

}
