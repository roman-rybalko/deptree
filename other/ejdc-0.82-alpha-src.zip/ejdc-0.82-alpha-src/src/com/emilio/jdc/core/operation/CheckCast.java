package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.constant.Constant;
import com.emilio.jdc.core.operation.expr.CheckCastExpr;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class CheckCast extends Operation {
    private int index;
    private Constant constant;

    public CheckCast(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }

    @Override
    public void parseParams() {
        index = mergeUnsignedBytes(parameters[ZERO],parameters[ONE]);
        constant = context.getConstantPoolInfo().getContantPoolItem(index);
    }
    
    @Override    
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        expr = CheckCastExpr.of(constant, stack.pop());
        stack.push(this);
        
//        if (prev instanceof CheckCastView)
//        {
//            CheckCastView cc = (CheckCastView) prev;
//            if (((CheckCast) operation).getCastClass().equals(cc.getPushType()))
//            {
//                view = prev.view;
//                context.push(this);
//                return;
//            }
//        }
//
//        view = new Object[]{"((" + alias(((CheckCast) operation).getCastClass()) + ") ", prev, ")"};
//        context.push(this);
        
    }
    
    @Override
    public Object getValue(){
        return expr.toText();
    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:byteCode=%d,index=%d,constantClass=%s]", this
                        .getClass().getSimpleName(),byteCode,index,constant);
    }
    
}
