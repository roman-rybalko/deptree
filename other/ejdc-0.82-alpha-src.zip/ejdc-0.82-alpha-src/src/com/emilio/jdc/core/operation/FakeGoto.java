package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class FakeGoto extends Goto{

    private int fakeByteIndex;
    private int fakeTargetIndex;
    
    /**
     * 
     * @param byteIndex
     * @param targetIndex
     */
    public FakeGoto(int byteIndex, int targetIndex){
        super(-1,byteIndex,null);
        
        this.fakeByteIndex = byteIndex;
        this.fakeTargetIndex = targetIndex;
    }
    
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        
    }

    public int getByteIndex(){
        return fakeByteIndex;
    }

    public int getTargetIndex(){
        return fakeTargetIndex;
    }

}
