package com.emilio.jdc.core.operation;

import com.emilio.jdc.core.attribute.LocalVariableInfo;
import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.opcode.ByteCode;
import com.emilio.jdc.core.operation.expr.StoreExpr;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Store extends Operation implements LocalVarOperation {
    private int varNum;
    private LocalVariableInfo localVar;
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public Store(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void parseParams() {
        ByteCode code = super.getOP();
        
        //TODO not finished here
        if (code.isInRange(ByteCode.ISTORE,ByteCode.ASTORE)){
            varNum = super.mergeUnsignedBytes(parameters[ZERO]);
        }else if (code.isInRange(ByteCode.ISTORE_0,ByteCode.ASTORE_3)){
            varNum = super.getOP().getConstValue();
        }
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack,
            LocalVariableTable table) {
        
        if(table != null){
           localVar = table.get(varNum,getStartPc());
        }
        if (localVar == null){
        //System.out.println("getStartPc----"+getStartPc());
        //System.out.println(this+"--V--"+varNum);
        }
        // TODO shifts for debug variables
        /*
        lvar.ensure((int) getStartByte() + (getOpcode() <= 58 ? 2 : 1));

        if ("boolean".equals(lvar.getType()) && pushOp instanceof PushConstView)
        {
            ((PushConstView) pushOp).forceBoolean();
        }
        
        */

        expr = StoreExpr.of(localVar, stack.pop());

        stack.push(this);
    }
    
    /**
     * 
     */
    public int getVarNum(){
        return varNum;
    }
    
    /**
     * 
     */
    public LocalVariableInfo getLocalVariable(){
        return localVar;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }
    
}
