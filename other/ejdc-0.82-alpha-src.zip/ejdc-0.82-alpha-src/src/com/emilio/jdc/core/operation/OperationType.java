package com.emilio.jdc.core.operation;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;

import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.exception.BadFormatException;

/**
 * 
 * @author Emilio Liang
 * Factory class for all operations
 *
 */
public enum OperationType{
    NOP,
    CONST_PUSH,
    ADVANCED_PUSH,
    LOAD,
    ARRAYLOAD,
    STORE,
    ARRAYSTORE,
    POP,
    LDC,
    DUP,
    SWAP,
    ARITHMETIC,
    BIT_OPERATION,
    IINC,
    CONVERSION,
    CMP,
    IF,
    RET,
    RETURN,
    JSR,
    GOTO,
    NEW,
    NEWARRAY,
    NEWOBJECTARRAY,
    MULTINEWARRAY,
    ARRAYLENGTH,
    INVOKE,
    GET_FIELD,
    PUT_FIELD,
    THROW,
    CHECKCAST,
    SWITCH,
    INSTANCEOF,
    BREAKPOINT,
    SYNC,
    WIDE,
    RESERVE,
    UNKNOWN;
    
    //private static EnumMap<OperationType, Class<? extends Operation>> classMapping = new EnumMap<OperationType, Class<? extends Operation>>(OperationType.class);

    private static Map<Class<? extends Operation>,OperationType> classMapping = new HashMap<Class<? extends Operation>,OperationType>();
    
    static{
        try {
            classMapping.put(Nop.class,NOP);
            classMapping.put(ConstPush.class,CONST_PUSH);
            classMapping.put(AdvancedPush.class,ADVANCED_PUSH);
            classMapping.put(Ldc.class,LDC);
            classMapping.put(Load.class,LOAD);
            classMapping.put(ArrayLoad.class,ARRAYLOAD);
            classMapping.put(Store.class,STORE);
            classMapping.put(ArrayStore.class,ARRAYSTORE);
            classMapping.put(Pop.class,POP);
            classMapping.put(Dup.class,DUP);
            classMapping.put(Swap.class,SWAP);
            classMapping.put(Arithmetic.class,ARITHMETIC);
            classMapping.put(BitOperation.class,BIT_OPERATION);
            classMapping.put(Iinc.class,IINC);
            classMapping.put(Conversion.class,CONVERSION);
            classMapping.put(Cmp.class,CMP);
            classMapping.put(If.class,IF);
            classMapping.put(Ret.class,RET);
            classMapping.put(Switch.class,SWITCH);
            classMapping.put(Return.class,RETURN);
            classMapping.put(GetField.class,GET_FIELD);
            classMapping.put(PutField.class,PUT_FIELD);
            classMapping.put(Invoke.class,INVOKE);
            classMapping.put(New.class,NEW);
            classMapping.put(NewArray.class,NEWARRAY);
            classMapping.put(NewObjectArray.class,NEWOBJECTARRAY);
            classMapping.put(ArrayLength.class,ARRAYLENGTH);
            classMapping.put(Throw.class,THROW);
            classMapping.put(CheckCast.class,CHECKCAST);
            classMapping.put(InstanceOf.class,INSTANCEOF);
            classMapping.put(Sync.class,SYNC);
            classMapping.put(Wide.class,WIDE);
            classMapping.put(Jsr.class,JSR);
            classMapping.put(Goto.class,GOTO);
            classMapping.put(MultiNewArray.class,MULTINEWARRAY);
            classMapping.put(BreakPoint.class,BREAKPOINT);
            classMapping.put(Reserve.class,RESERVE);
            
 
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    /**
     * 
     * @param byteCode
     * @param code
     * @return
     */
    public static Operation of(int byteCode, int byteIndex, MethodContext context) {
        Class<? extends Operation> clazz = mapByteCodeToClass(byteCode);
         
        Operation op = null;
        try {
            Constructor<? extends Operation> con = clazz.getConstructor(int.class, int.class , MethodContext.class);
            op = con.newInstance(byteCode, byteIndex, context);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return op;
    }

    /**
     * 
     * @param byteCode
     * @return
     */
    private static Class<? extends Operation>  mapByteCodeToClass(int byteCode) {
        if ( byteCode == 0 ){
            return Nop.class;
        }else if  (byteCode > 0 && byteCode <= 15) {
            return ConstPush.class;
        } else if (byteCode > 15 && byteCode <= 17) {
            return AdvancedPush.class;
        } else if (byteCode > 17 && byteCode <= 20) {
            return Ldc.class;
        } else if (byteCode > 20 && byteCode <= 45) {
            return Load.class;
        } else if (byteCode > 45 && byteCode <= 53) {
            return ArrayLoad.class;
        } else if (byteCode > 53 && byteCode <= 78) {
            return Store.class;
        } else if (byteCode > 78 && byteCode <= 86) {
            return ArrayStore.class;
        } else if (byteCode > 86 && byteCode <= 88) {
            return Pop.class;
        } else if (byteCode > 88 && byteCode <= 94) {
            return Dup.class;
        } else if (byteCode == 95) {
            return Swap.class;
        } else if (byteCode > 95 && byteCode <= 119) {
            return Arithmetic.class;
        } else if (byteCode > 119 && byteCode <= 131 ) {
            return BitOperation.class;
        } else if (byteCode == 132) {
            return Iinc.class;
        } else if (byteCode > 132 && byteCode <= 147) {
            return Conversion.class;
        } else if (byteCode > 147 && byteCode <= 152) {
            return Cmp.class;
        } else if ((byteCode > 152 && byteCode <= 166) || byteCode == 198 || byteCode == 199) {
            return If.class;
        } else if (byteCode == 167 || byteCode == 200 ){
            return Goto.class;
        } else if (byteCode == 168 || byteCode == 201 ){
            return Jsr.class;
        } else if (byteCode == 169) {
            return Ret.class;
        } else if (byteCode > 169 && byteCode <= 171) {
            return Switch.class;
        } else if (byteCode > 171 && byteCode <= 177) {
            return Return.class;
        } else if (byteCode == 178 || byteCode == 180) {
            return GetField.class;
        } else if (byteCode == 179 || byteCode == 181) {
            return PutField.class;
        } else if (byteCode > 181 && byteCode <= 186) {
            return Invoke.class;
        } else if (byteCode == 187) {
            return New.class;
        } else if (byteCode > 187 && byteCode <= 188) {
            return NewArray.class;
        } else if (byteCode == 189) {
            return NewObjectArray.class;
        } else if (byteCode == 190) {
            return ArrayLength.class;
        } else if (byteCode == 191) {
            return Throw.class;
        } else if (byteCode == 192) {
            return CheckCast.class;
        } else if (byteCode == 193) {
            return InstanceOf.class;
        } else if (byteCode > 193 && byteCode <= 195) {
            return Sync.class;
        } else if (byteCode == 196) {
            return Wide.class;
        } else if (byteCode == 197) {
            return MultiNewArray.class;            
        } else if (byteCode == 202) {
            return BreakPoint.class;
        } else if (byteCode == 254 || byteCode == 255) {
            return Reserve.class;
        } else{
            throw new BadFormatException("Not valid byte code type="+byteCode);
        }        
    }
    
    /**
     * 
     * @param clazz
     * @return
     */
    public static OperationType getType(Class<? extends Operation> clazz){
        return classMapping.get(clazz);
    }
}
