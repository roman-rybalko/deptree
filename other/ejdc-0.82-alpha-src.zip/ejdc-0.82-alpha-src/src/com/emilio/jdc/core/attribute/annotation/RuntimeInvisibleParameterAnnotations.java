package com.emilio.jdc.core.attribute.annotation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.attribute.AttributeInfoItem;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public class RuntimeInvisibleParameterAnnotations extends AttributeInfoItem {
    private int numParameters;
    private List<ParameterAnnotation> parameterAnnotations = new ArrayList<ParameterAnnotation>();

//    RuntimeInvisibleParameterAnnotations_attribute {
//        u2 attribute_name_index;
//        u4 attribute_length;
//        u1 num_parameters;
//        {
//        u2 num_annotations;
//        annotation annotations[num_annotations];
//        } parameter_annotations[num_parameters];
//        }    /**

    /**
     * Constructor
     * 
     * @param item
     */
    public RuntimeInvisibleParameterAnnotations(AttributeInfoItem item) {
        super(item);
    }
    
    @Override
    public AttributeInfoItem resolve(Class clazz) throws IOException {
        ClassInputStream cis = getStream();
        numParameters = cis.readU2();
        
        parameterAnnotations = loadInfoTables(numParameters,ParameterAnnotation.class, cis);

        return this;
    }
    
    @Override
    public String toString() {
        return String.format(
                "[%s:numAnnotations=%d,annotations=%s]", this
                        .getClass().getSimpleName(), numParameters,parameterAnnotations);
    }
    
}
