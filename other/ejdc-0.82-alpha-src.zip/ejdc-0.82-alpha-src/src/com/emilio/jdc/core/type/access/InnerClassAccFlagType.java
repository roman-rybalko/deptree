package com.emilio.jdc.core.type.access;

/**
 * 
 * @author Emilio Liang
 * 
 */
public enum InnerClassAccFlagType implements AccessFlag {
    PUBLIC    (0x0001),
    PRIVATE   (0x0002),
    PROTECTED (0x0004),
    STATIC    (0x0008),
    FINAL     (0x0010),
    INTERFACE (0x0200),
    ABSTRACT  (0x0400);

    private int accessFlag;

    private InnerClassAccFlagType(int accessFlag) {
        this.accessFlag = accessFlag;
    }

    public int getAccessFlag() {
        return accessFlag;
    }

    @Override
    public String toString(){
        return super.toString().toLowerCase();
    }  
}
