package com.emilio.jdc.core;

public interface LazyLoadableInfo extends LoadableInfo {

}
