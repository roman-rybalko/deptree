package com.emilio.jdc.core.operation.expr;

import java.util.List;

import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class InvokeStaticExpr extends AbstractInvokeStaticExpr{
    public static InvokeStaticExpr of(String className, String methodName, List<? extends Value> arguments){
        return new InvokeStaticExpr(className, methodName, arguments);
    }
    
    private InvokeStaticExpr(String className, String methodName, List<? extends Value> arguments){
        this.fullClassName = className; 
        this.methodName = methodName;
        this.arguments = arguments;
    }
    
}
