package com.emilio.jdc.core.attribute;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.FieldDescriptor;
import com.emilio.jdc.core.LazyLoadableInfo;
import com.emilio.jdc.core.ResolvableInfo;
import com.emilio.jdc.core.type.ObjectType;
import com.emilio.jdc.core.type.Value;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class LocalVariableInfo implements LazyLoadableInfo, ResolvableInfo, Value {
    private int startPc;
    private int endPc;
    private int length;
    private int nameIndex;
    private int descIndex;
    private int slotNum;
    private String localVarName;
    private FieldDescriptor fieldDesc;
    int index;
    
    /**
     * @param cis
     */
    public void load(ClassInputStream cis) throws IOException {
        startPc = cis.readU2();
        length = cis.readU2();
        nameIndex = cis.readU2();
        descIndex = cis.readU2();
        slotNum = cis.readU2();
                
        //TODO need verify before ?
        endPc = startPc + length;
    }

    /**
     * 
     */
    public void resolve(Class clazz){
        ConstantPoolInfo pool = clazz.getPoolInfo();
        localVarName = pool.getContantPoolItem(nameIndex).getValue();
        String descStr = pool.getContantPoolItem(descIndex).getValue();
        fieldDesc = new FieldDescriptor();
        fieldDesc.parse(descStr);
    }
    
    /**
     * 
     * @return int
     */
    public int getStartPc() {
        return startPc;
    }
    
    /**
     * 
     * @return int
     */
    public int getEndPc() {
        return endPc;
    }

    /**
     * 
     * @return int
     */
    public int getLength() {
        return length;
    }

    /**
     * 
     * @return
     */
    public int getSlotNum() {
        return slotNum;
    }

    /**
     * 
     * @return String
     */
    public String getLocalVarName() {
        return localVarName;
    }

    /**
     * 
     * @return FieldDescriptor
     */
    public FieldDescriptor getFieldDesc() {
        return fieldDesc;
    }
    
    /**
     * 
     * @return
     */
    public ObjectType getType(){
        return ObjectType.STRING;
    }

    /**
     * 
     * @return
     */
    public Object getValue(){
        return localVarName;
    }

    @Override
    public String toString() {
        return String.format(
                "[%s:startPc=%d,length=%d,nameIndex=%d,descIndex=%d,slotNum=%d,localVarName=%s]",
                this.getClass().getSimpleName(), startPc, length, nameIndex,
                descIndex, slotNum,localVarName);
    }
}
