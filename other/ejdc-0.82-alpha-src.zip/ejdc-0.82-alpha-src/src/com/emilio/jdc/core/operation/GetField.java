package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.constant.ConstantFieldRef;
import com.emilio.jdc.core.opcode.ByteCode;
import com.emilio.jdc.core.operation.expr.GetFieldExpr;
import com.emilio.jdc.core.operation.expr.GetStaticExpr;
import com.emilio.jdc.core.type.Value;
import com.emilio.jdc.core.util.OperandStack;
import com.emilio.jdc.core.util.StringValue;

/**
 * 
 * @author Emilio Liang
 *
 */
public class GetField extends Operation{
    private int index;
    private ConstantFieldRef fieldRef;
    //private String refClassName;
    private Object value;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public GetField(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    
    /**
     * 
     */
    public void parseParams() {
        

//        CONSTANT_Fieldref f_info = (CONSTANT_Fieldref) code.getClazz().getConstant_pool()[(params[0] << 8) | params[1]];
//        name = f_info.getName();
//        fieldType = f_info.getFieldDescriptor().getFQN();
//        if (opcode == 178)   // getstatic
//        {
//            staticRef = f_info.getRefClazz().getFullyQualifiedName();
//        }
//    }
        index = mergeUnsignedBytes(parameters);
        
        fieldRef = (ConstantFieldRef)context.getConstantPoolInfo().getContantPoolItem(index);
        
        if (getOP().equals(ByteCode.GETSTATIC)){
            value = fieldRef.getRefClass().getName();
        }else{
            value = fieldRef.getValue();
        }
   
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){       
        switch(getOP()){
        case PUTSTATIC:
            mergeStatic(stack,table);
            break;
        case PUTFIELD:
            mergeField(stack,table);
            break;       
        }
        
        stack.push(this);
    }
    
    public void mergeStatic(OperandStack<Operation> stack, LocalVariableTable table){
        
        expr = GetStaticExpr.of(this, StringValue.valueOf(fieldRef.getName()));
    }
    
    public void mergeField(OperandStack<Operation> stack, LocalVariableTable table){
        Value objRef = stack.pop();
        
        expr = GetFieldExpr.of(objRef,this);
        
    }
    
    @Override
    public Object getValue(){
        return value;
    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:byteCode=%d,index=%d,fieldRef=%s]", this
                        .getClass().getSimpleName(),byteCode,index,fieldRef);
    }

}
