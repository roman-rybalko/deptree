package com.emilio.jdc.core.attribute;

/**
 * 
 * @author Emilio Liang
 *
 */
public class GenericAttribute extends AttributeInfoItem {
}
