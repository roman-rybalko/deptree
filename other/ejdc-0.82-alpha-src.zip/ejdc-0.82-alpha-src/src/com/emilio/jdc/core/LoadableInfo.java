package com.emilio.jdc.core;

import java.io.IOException;

import com.emilio.jdc.core.util.ClassInputStream;

public interface LoadableInfo {
    public void load(ClassInputStream cis) throws IOException;
}
