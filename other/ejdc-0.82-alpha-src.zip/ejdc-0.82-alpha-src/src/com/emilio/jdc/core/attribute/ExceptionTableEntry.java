package com.emilio.jdc.core.attribute;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.LazyLoadableInfo;
import com.emilio.jdc.core.ResolvableInfo;
import com.emilio.jdc.core.constant.Constant;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class ExceptionTableEntry implements LazyLoadableInfo, ResolvableInfo {
    private int startPc;
    private int endPc;
    private int handlerPc;
    private int catchTypeIndex;
    private Constant catchType;

    /**
     * Constructor
     */
    public ExceptionTableEntry() {
    }

    /**
     * @param cis
     */
    public void load(ClassInputStream cis) throws IOException {
        startPc = cis.readU2();
        endPc = cis.readU2();
        handlerPc = cis.readU2();
        catchTypeIndex = cis.readU2();
    }
    
    public void resolve(Class clazz) throws IOException{
        //TODO needs convert here ?
        catchType = clazz.getPoolInfo().getContantPoolItem(catchTypeIndex);
    }


    public int getStartPc() {
        return startPc;
    }

    public int getEndPc() {
        return endPc;
    }

    public void setEndPc(int endPc) {
        this.endPc = endPc;
    }

    public int getHandlerPc() {
        return handlerPc;
    }

    public Constant getCatchType() {
        return catchType;
    }

    @Override
    public String toString() {
        return String.format(
                "[%s:startPc=%d,endPc=%d,handlerPc=%d,catchType=%s]", this
                        .getClass().getSimpleName(), startPc, endPc, handlerPc,
                catchType);
    }
}
