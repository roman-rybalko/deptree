package com.emilio.jdc.core.operation.expr;

import java.util.List;

/**
 * 
 * @author Emilio Liang
 *
 */
public interface ListExpression {
    //TODO needs this interface?
    public List<Expression> listExpressions();
}
