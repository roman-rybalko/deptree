package com.emilio.jdc.core.operation.expr;

import java.util.List;

import com.emilio.jdc.core.type.Value;
import com.emilio.jdc.decompile.structure.CaseBlock;

/**
 * 
 * @author Emilio Liang
 *
 */
public class SwitchExpr implements Expression{
    private Value value;
    private List<CaseBlock> caseBlocks;
    
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     * @return
     */
    public static SwitchExpr of(Value value,List<CaseBlock> caseBlocks){
        return new SwitchExpr(value,caseBlocks);
    }
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     */
    private SwitchExpr(Value value,List<CaseBlock> caseBlocks){
        this.value = value;
        this.caseBlocks = caseBlocks;
    }

    /**
     * toText
     * @return String
     * 
     */
    public String toText() {
        StringBuilder text = new StringBuilder(100);
        
        text.append("switch ");
        text.append(LEFT_PARENTHESIS);
        text.append(value);
        text.append(RIGHT_PARENTHESIS);
        text.append(LINE_SEPARATOR);
        text.append(LEFT_BRACKET);
        text.append(LINE_SEPARATOR);
        
        for(CaseBlock block :caseBlocks){
            text.append(block.getSource());
        }
        
//        for (Iterator it = caseBlocks.iterator(); it.hasNext();){
//            CaseBlock cb = (CaseBlock) it.next();
//            cb.setIndent(indent + "    ");
//            sb.append(cb.getSource());
//        }
        
//        text.append(indent);
        text.append("}");
        text.append(LINE_SEPARATOR);
        
        return text.toString();
    }
}
