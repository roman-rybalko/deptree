package com.emilio.jdc.core;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import com.emilio.jdc.core.constant.ConstantClass;
import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.type.access.AccessFlagTypeUtil;
import com.emilio.jdc.core.type.access.AccessType;
import com.emilio.jdc.core.type.access.ClassAccFlagType;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 * Represent class information in class file, including super class and this class info
 * 
 */
public class ClassInfo implements LoadableInfo, ResolvableInfo, Expression, AccessType {
    private int thisClassIndex;
    private int superClassIndex;
    private int accessFlags;
    private Set<ClassAccFlagType> classAccFlagSet;
    private ConstantClass thisClass;
    private ConstantClass superClass;
    private Class clazz;

    /**
     * Constructor
     */
    public ClassInfo() {
    }

    /**
     * @param cis
     */
    public void load(ClassInputStream cis) throws IOException {
        accessFlags = cis.readU2();
        thisClassIndex = cis.readU2();
        superClassIndex = cis.readU2();
    }

    /**
     * @param clazz
     */
    public void resolve(Class clazz) {
    	this.clazz = clazz;
        ConstantPoolInfo constantPool = clazz.getPoolInfo();
        classAccFlagSet = AccessFlagTypeUtil.ofAccFlagSet(
                ClassAccFlagType.class, accessFlags);

        thisClass = (ConstantClass) constantPool
                .getContantPoolItem(thisClassIndex);
        superClass = (ConstantClass) constantPool
                .getContantPoolItem(superClassIndex);
        

    }

    /**
     * 
     * @return ConstantClass
     */
    public ConstantClass getThisClass() {
        return thisClass;
    }

    /**
     * 
     * @return ConstantClass
     */
    public ConstantClass getSuperClass() {
        return superClass;
    }

    /**
     * @return Set<ClassAccFlagType>
     */
    public Set<ClassAccFlagType> getAccFlagSet() {
        return classAccFlagSet;
    }
    
    /**
     * 
     * @return
     */
    public List<String> getInterfaceNames(){
        return clazz.getInterfaceInfo().getUTFNames();
    }
  
    /**
     * 
     */
    public String toText(){
        return thisClass.toString();
    }

    @Override
    public String toString() {
        return String.format(
                "[%s:thisClassIndex=%d,superClassIndex=%d,accessFlags=%d]",
                this.getClass().getSimpleName(),
                thisClassIndex,
                superClassIndex,
                accessFlags);
    }

}
