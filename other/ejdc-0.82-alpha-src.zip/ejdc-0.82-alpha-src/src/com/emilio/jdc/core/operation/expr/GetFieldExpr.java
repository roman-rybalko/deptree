package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class GetFieldExpr extends AbstractBinaryOpExpr{
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     * @return
     */
    public static GetFieldExpr of(Value value1, Value value2){
        return new GetFieldExpr(value1, value2);
    }
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     */
    private GetFieldExpr(Value value1,Value value2){
        //TODO what about triple
        this.value1 = value1;
        this.value2 = value2;
        
    }

    //view = new Object[]{prev, "." + ((GetField) operation).getFieldName()};

    public String toText() {
        StringBuilder text = new StringBuilder(50);
        text.append(LEFT_PARENTHESIS);
        text.append(value1.getValue());
        text.append(DOT);
        text.append(value2.getValue());
        text.append(RIGHT_PARENTHESIS);
        
        return text.toString();
    }
}
