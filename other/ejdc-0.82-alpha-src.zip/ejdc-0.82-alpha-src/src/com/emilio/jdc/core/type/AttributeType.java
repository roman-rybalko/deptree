package com.emilio.jdc.core.type;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum AttributeType {
    ANNOTATION_DEFAULT,
    CODE,
    CONSTANT_VALUE,
    DEPRECATED,
    ENCLOSING_METHOD,
    EXCEPTIONS,
    INNER_CLASSES,
    LINE_NUMBER_TABLE,
    LOCAL_VARIABLE_TABLE,
    LOCAL_VARIABLE_TYPE_TABLE,
    SIGNATURE,
    STACK_MAP_TABLE,
    SYNTHETIC,
    SOURCE_DEBUG_EXTENSION,
    SOURCE_FILE,
    RUNTIME_INVISIBLE_ANNOTATIONS,
    RUNTIME_INVISIBLE_PARAMETER_ANNOTATIONS,
    RUNTIME_VISIBLE_ANNOTATIONS,
    RUNTIME_VISIBLE_PARAMETER_ANNOTATIONS,
    UNDEFINED;

    private static final String PATTERN_REGEX = "([A-Z]{1}[a-z]*)";
    private static final Pattern PATTERN = Pattern.compile(PATTERN_REGEX);

    /**
     * getAttributeType
     * 
     * @param attribute
     * @return
     */
    public static AttributeType getAttributeType(String attribute) {
        Matcher matcher = PATTERN.matcher(attribute);

        StringBuilder sb = new StringBuilder();

        while (matcher.find()) {
            sb.append(matcher.group(1));
            if (!matcher.hitEnd()) {
                sb.append("_");
            }
        }
        AttributeType type = null;
        try {
            type = valueOf(sb.toString().toUpperCase());
        } catch (Exception ex) {
            //TODO debug to stop print, should open
            //ex.printStackTrace();
            type = UNDEFINED;
        }
        
        return type;
    }

    public static void main(String args[]) {
        System.out.println(getAttributeType("RuntimeVisibleAnnotations"));
    }
}
