package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.MethodInfoItem;
import com.emilio.jdc.core.attribute.LocalVariableInfo;
import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.type.ObjectType;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Load extends Operation {
    private int varSlotNum;
    private LocalVariableInfo localVar;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public Load(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void parseParams() {
        if (parameters != null && parameters.length > 0){
            varSlotNum = parameters[ZERO];
        }
        else{
            //TODO not a good practice
            //Fixed, but needs test
            varSlotNum = this.getOP().getConstValue();            
        }
    }
    
    /**
     * 
     */
    public void resolve(MethodInfoItem method){
        method.getCode();
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        //TODO may complicated here.
        
        
        //System.out.println("byteIndex---"+byteIndex); 
        //System.out.println("varSlotNum---"+varSlotNum);

        //System.out.println("table.size()---"+table.size());

        if(table != null){
            localVar = table.get(varSlotNum, getStartPc());
        }
        
        //System.out.println("localVar---"+localVar);
        
        stack.push(this);
        
        //TODO
        
        //lvar.ensure((int) getStartByte());
        //view = new Object[]{lvar.getView()};
        //context.push(this);
    }
    
    /**
     * 
     * @return
     */
    public ObjectType getType(){
        return ObjectType.OPERATION;
    }

    @Override
    public Object getValue(){
        //TODO 
        return localVar.getLocalVarName();
    }
    
    /**
     * 
     * @return
     */
    public int getVarSlotNum(){
        return varSlotNum;
    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:varSlotNum=%d]", this
                        .getClass().getSimpleName(),varSlotNum);
    }
}
