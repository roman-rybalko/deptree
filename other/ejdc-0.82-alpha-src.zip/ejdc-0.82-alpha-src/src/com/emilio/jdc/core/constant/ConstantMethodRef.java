package com.emilio.jdc.core.constant;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.MethodDescriptor;
import com.emilio.jdc.core.type.ConstantType;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent CONSTANT_Methodref table in constant_pool 
 * 
 */
public final class ConstantMethodRef extends ConstantRefType {
    private MethodDescriptor methodDescriptor;

    /**
     * Constructor
     * 
     * @param index
     * @param type
     */
    public ConstantMethodRef(int index, ConstantType type) {
        super(index, type);
    }
    
    @Override
    public void resolve(Class clazz) {
        
        super.resolve(clazz);

        methodDescriptor = new MethodDescriptor();
                
        methodDescriptor.parse(refNameAndType.getDescriptor());
    }

    /**
     * 
     * @return
     */
    public MethodDescriptor getMethodDescriptor() {
        return methodDescriptor;
    }
}