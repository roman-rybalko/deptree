package com.emilio.jdc.core.operation.expr;

public interface Marker {
    static final String LEFT_PARENTHESIS  = "(";
    static final String RIGHT_PARENTHESIS = ")";
    static final String LEFT_BRACKET  = "[";
    static final String RIGHT_BRACKET = "]";
    static final String BLANK_SPACE=" ";
    static final String LINE_SEPARATOR = System.getProperty("line.separator");
    static final String DOT=".";

}
