package com.emilio.jdc.core.constant;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.FieldDescriptor;
import com.emilio.jdc.core.type.ConstantType;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent CONSTANT_Fieldref  table in constant_pool 
 * 
 */
public final class ConstantFieldRef extends ConstantRefType {
	/**
	 * field descriptor
	 */
    private FieldDescriptor fieldDescriptor;

    /**
     * Constructor
     * 
     * @param index
     * @param type
     */
    public ConstantFieldRef(int index, ConstantType type) {
        super(index, type);
    }
    
    @Override
    public void resolve(Class clazz) {
        super.resolve(clazz);

        fieldDescriptor = new FieldDescriptor();
        
        fieldDescriptor.parse(refNameAndType.getDescriptor());
    }
    
    @Override
    public String getValue() {
        return getName();
    }

    /**
     * 
     * @return
     */
    public FieldDescriptor getFieldDescriptor() {
        return fieldDescriptor;
    }
}
