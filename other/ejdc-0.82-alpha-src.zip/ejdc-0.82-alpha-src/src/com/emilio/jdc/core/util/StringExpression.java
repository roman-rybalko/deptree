package com.emilio.jdc.core.util;

import com.emilio.jdc.core.operation.expr.Expression;

/**
 * 
 * @author Emilio Liang
 * 
 * Wrapper class for string, wrapped string will be treated as a Expression class 
 *
 */
public class StringExpression implements Expression{
    private String expr;
    
    public static Expression valueOf(String value){
        return new StringExpression(value);
    }
    
    private StringExpression(String expr){
        this.expr = expr;
    }
    
    public String toText(){
        return expr;
    }
}
