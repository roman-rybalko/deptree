package com.emilio.jdc.core.type;

import com.emilio.jdc.core.exception.BadFormatException;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum ElementType {
    CONST_VALUE,
    ENUM_CONST_VALUE,
    CLASS_INFO_VALUE,
    ANNOTATION_VALUE,
    ARRAY_VALUE;

    public static ElementType fromChar(char tag) {
        switch (tag) {
        case 'B': // byte
        case 'C': // char
        case 'D': // double
        case 'F': // float
        case 'I': // int
        case 'J': // long
        case 'S': // short
        case 'Z': // boolean
        case 's': // String
            return CONST_VALUE;
        case 'e': // enum constant
            return ENUM_CONST_VALUE;
        case 'c': // Class
            return CLASS_INFO_VALUE;
        case '@': // annotation type
            return ANNOTATION_VALUE;
        case '[': // array
            return ARRAY_VALUE;
        default:
            throw new BadFormatException("Illegal ElementValuePair tag");
        }
    }
}
