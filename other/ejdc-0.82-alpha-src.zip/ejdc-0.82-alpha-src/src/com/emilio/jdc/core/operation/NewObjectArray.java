package com.emilio.jdc.core.operation;

import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.constant.Constant;
import com.emilio.jdc.core.operation.expr.NewArrayExpr;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class NewObjectArray extends Operation {
    private Constant arrayType;
    private int index;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }

    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public NewObjectArray(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void parseParams() {
        index = mergeUnsignedBytes(parameters[ZERO],parameters[ONE]);
        arrayType = context.getConstantPoolInfo().getContantPoolItem(index);        
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        //TODO share same expr, OK?
        expr = NewArrayExpr.of(stack.pop(), arrayType);
        stack.push(this);
    }
    
    @Override
    public Object getValue(){
        return expr.toText();
    }
    
    @Override
    public String toString(){
        return String.format("%s[index=%d,constClass=%s]", this
                        .getClass().getSimpleName(),index,arrayType);
    }
}
