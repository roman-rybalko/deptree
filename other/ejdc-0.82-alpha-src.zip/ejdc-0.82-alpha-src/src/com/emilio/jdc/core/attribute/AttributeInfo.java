package com.emilio.jdc.core.attribute;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.LoadableInfo;
import com.emilio.jdc.core.ResolvableInfo;
import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.operation.expr.ListExpression;
import com.emilio.jdc.core.type.AttributeType;
import com.emilio.jdc.core.util.ClassInputStream;
import com.emilio.jdc.core.util.StringFormatUtil;

public final class AttributeInfo implements LoadableInfo, ResolvableInfo, ListExpression {
    protected int attributeCount;
    private AttributeInfoItem[] attributeInfoArray = new AttributeInfoItem[0];

    /**
     * Constructor
     */
    public AttributeInfo() {
    }

    /**
     * 
     */
    public void load(ClassInputStream cis) throws IOException {
        attributeCount = cis.readU2();

        if (attributeCount > 0) {
            attributeInfoArray = new AttributeInfoItem[attributeCount];
            for (int i = 0; i < attributeCount; i++) {
                attributeInfoArray[i] = new GenericAttribute();
                attributeInfoArray[i].load(cis);
            }
        }
    }
    
    /**
     * Return the first found attribute
     * @param <T>
     * @param clazz
     * @return
     */
    public <T> T queryAttribute(java.lang.Class<T> clazz){
        for(AttributeInfoItem item :attributeInfoArray){
            if (clazz.isInstance(item)){
               @SuppressWarnings("unchecked")
               T t = (T)item;
               return t;
            }
        }
        
        return null;
    }
    
    /**
     * 
     * @param <T>
     * @param clazz
     * @return
     */
    public <T> List<T> queryAttributeList(java.lang.Class<T> clazz){
        List<T> list = new ArrayList<T>();
        for(AttributeInfoItem item :attributeInfoArray){
            if (clazz.isInstance(item)){
                @SuppressWarnings("unchecked")
                T t = (T)item;
               list.add(t);
            }
        }
        return list;
    }

    /**
     * 
     */
    public void resolve(Class clazz) throws IOException {
        if (attributeCount > 0) {

            for (int i = 0; i < attributeCount; i++) {
                attributeInfoArray[i] = attributeInfoArray[i].resolve(clazz);
            }

        }
    }
    
    /**
     * 
     * @return
     */
    public List<AttributeInfoItem> getAttributeInfoItemList(){
        return Arrays.asList(attributeInfoArray);
    }
    
    public List<Expression> listExpressions(){
        //TODO
        List<Expression> list = new ArrayList<Expression>();
        for(AttributeInfoItem item:attributeInfoArray){
            list.add(item);
        }
        
        return list;
    }
    
    /**
     * 
     * @param pw
     */
    public void print(PrintWriter pw) {
        if (attributeCount > 0) {
            for(AttributeInfoItem item : attributeInfoArray){
                if (item.getAttributeType() == AttributeType.CODE){
                    pw.println();
                    item.print(pw);
                }
            }
        }
    }


    
    @Override
    public String toString() {
        return String.format("[%s:attributeCount=%d,attributeInfoArray:%s]",
                this.getClass().getSimpleName(), attributeCount, StringFormatUtil.toString(attributeInfoArray,2));
    }

}
