package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.operation.expr.ArrayLoadExpr;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class ArrayLoad extends Operation {
    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }
    
    public ArrayLoad(int byteCode, int byteIndex, MethodContext context){
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        Operation indexOp = stack.pop();
        Operation arrayOp = stack.pop();

        expr = ArrayLoadExpr.of(indexOp, arrayOp);

        stack.push(this);

        //arrayType = arrayOp.getPushType();
        // Removing 1 array dimension
        //if (arrayType.endsWith("[]")) arrayType = arrayType.substring(0, arrayType.length() - 2);
        
        //view = new Object[]{arrayOp, "[", indexOp, "]"};        
    }
    
    @Override
    public Object getValue(){
        return expr.toText();
    }
}
