package com.emilio.jdc.core.type.access;

import java.util.Set;

/**
 * 
 * @author Emilio Liang
 * 
 * Interface for all classes needs to handle access flag set.
 * 
 */
public interface AccessType {
    public Set<? extends AccessFlag> getAccFlagSet();
}
