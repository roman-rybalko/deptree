package com.emilio.jdc.core.attribute;

import java.io.IOException;

import com.emilio.jdc.core.Class;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class StackMapTable extends AttributeInfoItem {
    /**
     * Constructor
     * 
     * @param item
     */
    public StackMapTable(AttributeInfoItem item) {
        super(item);
    }
    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }
    
    public  AttributeInfoItem resolve(Class clazz) throws IOException {
        //TODO if do not return this will cause recursive error
        return this;
    }
}
