package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.Symbol;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class BitOperationExpr extends AbstractBinaryOpExpr{
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     * @return
     */
    public static BitOperationExpr of(Value value1,Value value2,Symbol operatorSymbol){
        return new BitOperationExpr(value1,value2,operatorSymbol);
    }
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     */
    private BitOperationExpr(Value value1,Value value2,Symbol operatorSymbol){
        this.value1 = value1;
        this.value2 = value2;
        this.operatorSymbol = operatorSymbol;
    }
    
    public String toText(){
        StringBuilder text = new StringBuilder(50);
        text.append(LEFT_PARENTHESIS);
        text.append(value1.getValue());
        text.append(BLANK_SPACE);
        text.append(getOperatorSymbol());
        text.append(BLANK_SPACE);
        text.append(value2.getValue());
        text.append(RIGHT_PARENTHESIS);
        
        return text.toString();
    }

}
