package com.emilio.jdc.core.type;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum StackEntryType {
    INT,OBJECT_REF,NULL,
}
