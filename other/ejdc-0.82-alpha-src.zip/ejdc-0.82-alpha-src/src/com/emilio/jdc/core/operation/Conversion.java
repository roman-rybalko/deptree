package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.operation.expr.ConversionExpr;
import com.emilio.jdc.core.type.BaseType;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Conversion extends Operation{
    private BaseType targetType;
    private BaseType sourceType;

    /**
     * @param args
     */
    public static void main(String[] args)throws Exception{
    }

    /**
     * 
     * @param byteCode
     * @param index
     * @param code
     */
    public Conversion(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){       
        expr = ConversionExpr.of(this, stack.pop());
        
        stack.push(this);
        
        //OperationView prev = context.pop();
        //view = new Object[]{"(" + ((TypeConversion) operation).getCastType() + ") ", prev};
        //context.push(this);
    }
    
    @Override
    public void parseParams() {
        switch (getOP()) {
        case I2L:
            sourceType = BaseType.I;
            targetType = BaseType.J;
            break;
        case I2F:
            sourceType = BaseType.I;
            targetType = BaseType.F;
            break;
        case I2D:
            sourceType = BaseType.I;
            targetType = BaseType.D;
            break;
        case L2I:
            sourceType = BaseType.J;
            targetType = BaseType.I;
            break;
        case L2F:
            sourceType = BaseType.J;
            targetType = BaseType.F;
            break;
        case L2D:
            sourceType = BaseType.J;
            targetType = BaseType.D;
            break;
        case F2I:
            sourceType = BaseType.F;
            targetType = BaseType.I;
            break;
        case F2L:
            sourceType = BaseType.F;
            targetType = BaseType.J;
            break;
        case F2D:
            sourceType = BaseType.F;
            targetType = BaseType.D;
            break;
        case D2I:
            sourceType = BaseType.D;
            targetType = BaseType.I;
            break;
        case D2L:
            sourceType = BaseType.D;
            targetType = BaseType.J;
            break;
        case D2F:
            sourceType = BaseType.D;
            targetType = BaseType.F;
            break;
        case I2B:
            sourceType = BaseType.I;
            targetType = BaseType.B;
            break;
        case I2C:
            sourceType = BaseType.I;
            targetType = BaseType.C;
            break;
        case I2S:
            sourceType = BaseType.I;
            targetType = BaseType.S;
            break;
        }
    }

    /**
     * 
     * @return
     */
    public BaseType getTargetType() {
        return targetType;
    }

    /**
     * 
     * @return
     */
    public BaseType getSourceType() {
        return sourceType;
    }
    
    @Override
    public Object getValue(){
        return expr.toText();
    }
}
