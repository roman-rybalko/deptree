package com.emilio.jdc.core.type;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum OperatorsType implements Symbol{
    ADD("+"),
    SUB("-"),
    MUL("*"),
    DIV("/"),
    MOD("%"),
    NEG("-"),
    SHL("<<"),
    SHR(">>"),
    USHR(">>>"),
    OR("|"),
    AND("&"),
    XOR("^"),
    EQUAL("=="),
    ASSIGN("="),
    INSTANCE_OF("instanceof"),
    THROW("throw"),
    NEW("new"),
    ADD_ADD("++"),
    ADD_ASSIGN("+=");
    
    /**
     * 
     */
    private final String operatorSymbol ;
    
    /**
     * Constructor
     * @param operatorSymbol
     */
    private OperatorsType(String operatorSymbol){
        this.operatorSymbol = operatorSymbol;
    }
    
    @Override
    public String toString(){
        return " "+operatorSymbol+" ";
    }
    
    public String toSymbol(){
        return this.toString();
    }
    
    //"", " + ", " - ", " * ", " / ", " % ", 
    //" << ", " >> ", " >>> ", " & ", " | ", " ^ ",
    //" = ", " += ", " -= ", " *= ", " /= ", " %= ", 
    //" <<= ", " >>= ", " >>>= ", " &= ", " |= ", " ^= ",
    //"/++", "--",
    //" == "," != "," < "," >= "," > ", " <= ", " && ", " || ",
    //"!", "~", "-"
}
