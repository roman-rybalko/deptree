package com.emilio.jdc.core.operation.expr;

/**
 * 
 * @author Emilio Liang
 *
 */
public class ConditionsExpr implements Expression{
    //private List<List<IfCondition>> andConditions = new ArrayList<List<IfCondition>>();
    
    public String toText(){
//        public List getSourceConditionsView()
//        {
//            List src = new ArrayList();
//            if (isNegConditions) src.add("(!");
//            if (andConditions.size() > 1) src.add("(");
//            for (Iterator i = andConditions.iterator(); i.hasNext();)
//            {
//                List orConditions = (List) i.next();
//                if (orConditions.size() > 1) src.add("(");
//                for (Iterator j = orConditions.iterator(); j.hasNext();)
//                {
//                    Condition cond = (Condition) j.next();
//                    if (j.hasNext() && orConditions.size() > 1) cond.setNeedReverseOperation(false);
//                    src.add("(");
//                    src.addAll(cond.getView());
//                    src.add(")");
//                    if (j.hasNext()) src.add(" || ");
//                }
//                if (orConditions.size() > 1) src.add(")");
//                if (i.hasNext()) src.add(" && ");
//            }
//            if (andConditions.size() > 1) src.add(")");
//            if (isNegConditions) src.add(")");
//            return src;
//        }
        return null;
    }
    

}
