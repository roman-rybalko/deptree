package com.emilio.jdc.core.attribute.annotation;

import com.emilio.jdc.core.attribute.AttributeInfoItem;

/**
 * 
 * @author Emilio Liang
 *
 */
public class AnnotationDefault extends AttributeInfoItem {

}
