package com.emilio.jdc.core.attribute;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class SourceDebugExtension extends AttributeInfoItem {
//    SourceDebugExtension_attribute {
//        u2 attribute_name_index;
//        u4 attribute_length;
//        u1 debug_extension[attribute_length];
//        }
    private int[] debugExtension = new int[0];
    /**
     * Constructor
     * 
     * @param item
     */
    public SourceDebugExtension(AttributeInfoItem item) {
        super(item);
    }

    @Override
    public AttributeInfoItem resolve(Class clazz) throws IOException {
        ClassInputStream cis = getStream();
        
        debugExtension = new int[(int)attrLength];
        
        for(int i = 0;i < attrLength; i++){
            debugExtension[i] = cis.readU1();
        }

        return this;
    }

}
