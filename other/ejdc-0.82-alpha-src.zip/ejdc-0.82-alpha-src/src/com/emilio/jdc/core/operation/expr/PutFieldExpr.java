package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.OperatorsType;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class PutFieldExpr implements Expression{
    private Value value1;
    private Value value2;
    private Value value3;
    
    private OperatorsType operatorSymbol;
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     * @return
     */
    public static PutFieldExpr of(Value value1, Value value2, Value value3){
        return new PutFieldExpr(value1, value2, value3 ,OperatorsType.ASSIGN);
    }
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     */
    private PutFieldExpr(Value value1,Value value2,Value value3, OperatorsType operatorSymbol){
        //TODO what about triple
        this.value1 = value1;
        this.value2 = value2;
        this.value3 = value3;
        
        this.operatorSymbol = operatorSymbol;
    }

    //view = new Object[]{refOp, ".", ((PutField) operation).getFieldName() + " = ", val};
    public String toText() {
        StringBuilder text = new StringBuilder(50);
        text.append(LEFT_PARENTHESIS);
        text.append(value1.getValue());
        text.append(DOT);
        text.append(value2.getValue());
        text.append(operatorSymbol);
        text.append(value3.getValue());
        text.append(RIGHT_PARENTHESIS);
        
        return text.toString();
    }
    
}
