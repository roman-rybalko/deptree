package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.OperatorsType;
import com.emilio.jdc.core.type.Symbol;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class CmpExpr extends AbstractBinaryOpExpr{
    //view = new Object[]{"signum(", var1, " - ", var2, ")"};
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     * @return
     */
    public static CmpExpr of(Value value1,Value value2){
        return new CmpExpr(value1,value2,OperatorsType.SUB);
    }
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     */
    private CmpExpr(Value value1,Value value2,Symbol operatorSymbol){
        this.value1 = value1;
        this.value2 = value2;
        this.operatorSymbol = operatorSymbol;
    }
    
    @Override
    public String toText() {
        StringBuilder text = new StringBuilder(50);
        text.append(LEFT_PARENTHESIS);
        text.append(value1.getValue());
        text.append(BLANK_SPACE);
        text.append(getOperatorSymbol());
        text.append(BLANK_SPACE);
        text.append(value2.getValue());
        text.append(RIGHT_PARENTHESIS);
        
        return text.toString();
    }
}
