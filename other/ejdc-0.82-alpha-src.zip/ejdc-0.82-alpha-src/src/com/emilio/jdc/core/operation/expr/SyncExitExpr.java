package com.emilio.jdc.core.operation.expr;

/**
 * 
 * @author Emilio Liang
 *
 */
public class SyncExitExpr {

    public String toText(){
        return null;
    }
    
}
