package com.emilio.jdc.core.attribute;

import java.util.Stack;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.MethodInfoItem;
import com.emilio.jdc.core.operation.Operation;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class MethodContext extends Stack<Operation> {

    private static final long serialVersionUID = -866073607403192598L;
    //private MethodDescriptor methodDesc;
    private MethodInfoItem methodInfo;
    private OperandStack<Operation> operandStack = new OperandStack<Operation>();
    private ConstantPoolInfo poolInfo;
    private Class clazz;
    //private Code code;
    private ExceptionTable exTable;
    private LocalVariableTable varTable;
    private LineNumberTable lineTable;
        
    public MethodContext(Code code){
        //this.code = code;
        
        this.methodInfo = code.getMethodInfo();
        
        //TODO
//        if(methodInfo != null){
//            this.methodDesc = methodInfo.getMethodDesc();
//        }
        
        this.poolInfo = code.getConstantPoolInfo();
        this.clazz = code.getClazz();
        this.varTable = code.getLocalVarTable();
        this.exTable = code.getExceptionTable();
        this.lineTable = code.getLineNumTable();
        this.operandStack = new OperandStack<Operation>();
    }
    
    /**
     * 
     * @return
     */
    public OperandStack<Operation> getOperandStack() {
        return operandStack;
    }
    
    public ConstantPoolInfo getConstantPoolInfo(){
        return poolInfo;
    }
    
    public Class getClazz(){
        return clazz;
    }
    
    public MethodInfoItem getMethodInfo(){
        return methodInfo;
    }
    
    public ExceptionTable getExceptionTable(){
        return exTable;
    }
    
    public LocalVariableTable getLocalVariableTable(){
        return varTable;
    }
    
    public LineNumberTable getLineNumberTable(){
        return this.lineTable;
    }
    
    public boolean empty(){
        return operandStack.empty();
    }
    
    public Operation peek() {
        return operandStack.peek();
    }

    public Operation pop() {
        return operandStack.pop();
    }

    public Operation push(Operation item){
        return operandStack.push(item);
    } 

    public int search(Object o){
        return operandStack.search(o);
    }


    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }
}
