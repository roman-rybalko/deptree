package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.OperatorsType;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class ThrowExpr extends AbstractUniOpExpr {
    private static final String NEW = "new";
    
    /**
     * 
     * @param value
     * @param operator
     * @return
     */
    public static ThrowExpr of(Value value){
        return new ThrowExpr(value,OperatorsType.THROW);
    }
    
    /**
     * 
     * @param value
     * @param operator
     */
    private ThrowExpr(Value value, OperatorsType operatorSymbol){
        this.value = value;
        this.operatorSymbol = operatorSymbol;
    }
    
    @Override
    public String toText(){
        StringBuilder text = new StringBuilder(50);
        text.append(operatorSymbol);
        text.append(BLANK_SPACE);
        text.append(NEW);
        text.append(BLANK_SPACE);
        text.append(value.getValue());

        return text.toString();
    }
    
}
