package com.emilio.jdc.core.attribute;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *      
 *   Signature_attribute {
 *   u2 attribute_name_index;
 *   u4 attribute_length;
 *   u2 signature_index;
 *   }
 *
 */
public final class Signature extends AttributeInfoItem {
    private int signatureIndex;
    private String signatureStr;

    /**
     * Constructor
     * 
     * @param item
     */
    public Signature(AttributeInfoItem item) {
        super(item);
    }

    @Override
    public AttributeInfoItem resolve(Class clazz) throws IOException {
        ConstantPoolInfo pool = clazz.getPoolInfo();
        ClassInputStream cis = getStream();
        signatureIndex = cis.readU2();
        signatureStr = pool.getContantPoolItem(signatureIndex).getValue();
        return this;
    }

    @Override
    public String toString() {
        return String.format("[%s:signatureIndex=%d,signatureStr=%s]", this.getClass()
                .getSimpleName(), signatureIndex,signatureStr);
    }

}
