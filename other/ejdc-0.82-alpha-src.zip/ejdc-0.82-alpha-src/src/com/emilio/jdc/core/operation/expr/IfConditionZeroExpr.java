package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.Symbol;
import com.emilio.jdc.core.type.Value;
import com.emilio.jdc.core.util.StringValue;

/**
 * 
 * @author Emilio Liang
 *
 */
public class IfConditionZeroExpr extends AbstractBinaryOpExpr{
    /**
     * 
     * @param value
     * @param operatorSymbol
     * @return
     */
    public static IfConditionZeroExpr of(Value value,Symbol operatorSymbol){
        return new IfConditionZeroExpr(value,StringValue.valueOf("0"),operatorSymbol);
    }
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     */
    private IfConditionZeroExpr(Value value1,Value value2,Symbol operatorSymbol){
        this.value1 = value1;
        this.value2 = value2;
        this.operatorSymbol = operatorSymbol;
    }
    
    @Override
    public String toText() {
        //TODO remove duplicate method;
        StringBuilder text = new StringBuilder(50);
        text.append(LEFT_PARENTHESIS);
        text.append(value1.getValue());
        text.append(BLANK_SPACE);
        text.append(getOperatorSymbol());
        text.append(BLANK_SPACE);
        text.append(value2.getValue());
        text.append(RIGHT_PARENTHESIS);
        
        return text.toString();
    }
}
