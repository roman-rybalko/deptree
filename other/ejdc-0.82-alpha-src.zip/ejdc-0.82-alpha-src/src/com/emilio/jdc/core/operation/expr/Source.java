package com.emilio.jdc.core.operation.expr;

public interface Source extends Marker{
	public String toSource();
}
