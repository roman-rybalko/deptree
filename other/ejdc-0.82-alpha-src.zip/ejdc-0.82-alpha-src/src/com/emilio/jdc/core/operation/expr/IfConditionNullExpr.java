package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.Symbol;
import com.emilio.jdc.core.type.Value;
import com.emilio.jdc.core.util.StringValue;

/**
 * 
 * @author Emilio Liang
 *
 */
public class IfConditionNullExpr extends AbstractBinaryOpExpr{
    /**
     * 
     * @param value
     * @param operatorSymbol
     * @return
     */
    public static IfConditionNullExpr of(Value value, Symbol operatorSymbol){
        return new IfConditionNullExpr(value,StringValue.valueOf("null"),operatorSymbol);
    }
    
    /**
     * 
     * @param value1
     * @param value2
     * @param operatorSymbol
     */
    private IfConditionNullExpr(Value value1,Value value2,Symbol operatorSymbol){
        this.value1 = value1;
        this.value2 = value2;
        this.operatorSymbol = operatorSymbol;
    }
    
    @Override
    public String toText() {
        StringBuilder text = new StringBuilder(50);
        text.append(LEFT_PARENTHESIS);
        text.append(value1.getValue());
        text.append(BLANK_SPACE);
        text.append(getOperatorSymbol());
        text.append(BLANK_SPACE);
        text.append(value2.getValue());
        text.append(RIGHT_PARENTHESIS);
        
        return text.toString();
    }
}
