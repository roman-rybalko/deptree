package com.emilio.jdc.core.exception;

/**
 * 
 * @author Emilio Liang
 *
 */
public class UnsupportedOperationException extends RuntimeException {
    /**
     * serialVersionUID used to identify the version of the serializable object
     */
    private static final long serialVersionUID = 8342059640800097235L;
    /**
     * 
     */
    private static final String DEFAULT_MESSAGE = "Unsupported data type";

    public UnsupportedOperationException() {
        this(DEFAULT_MESSAGE);
    }

    public UnsupportedOperationException(String message) {
        super(message);
    }

    public UnsupportedOperationException(String message, Throwable cause) {
        super(message, cause);
    }

    public UnsupportedOperationException(Throwable cause) {
        super(cause);
    }
}
