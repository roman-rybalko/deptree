package com.emilio.jdc.core.attribute.annotation;

import java.io.IOException;
import java.util.Arrays;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.FieldDescriptor;
import com.emilio.jdc.core.LazyLoadableInfo;
import com.emilio.jdc.core.LoadableInfo;
import com.emilio.jdc.core.ResolvableInfo;
import com.emilio.jdc.core.constant.Constant;
import com.emilio.jdc.core.constant.ConstantUtf8;
import com.emilio.jdc.core.type.ElementType;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Annotation implements LoadableInfo,ResolvableInfo {
    // annotation {
    // u2 type_index;
    // u2 num_element_value_pairs;
    // { u2 element_name_index;
    // element_value value;
    // } element_value_pairs[num_element_value_pairs]
    // }

    private int typeIndex;
    private int numElemValPairs;
    private ElementValuePair[] numElementValuePairs = new ElementValuePair[0];

    /**
     * @param cis
     */
    public void load(ClassInputStream cis) throws IOException {
        typeIndex = cis.readU2();
        numElemValPairs = cis.readU2();
        numElementValuePairs = new ElementValuePair[numElemValPairs];
        for(int i = 0; i < numElementValuePairs.length; i++){
            numElementValuePairs[i] = new ElementValuePair();
            numElementValuePairs[i].load(cis);
        }
    }
    
    /**
     * 
     * @param pool
     * @throws IOException
     */
    public void resolve(Class pool) throws IOException{
        for (ElementValuePair value :numElementValuePairs){
            value.resolve(pool);
        }
    }
    
    @Override
    public String toString() {
        return String.format(
                "[%s:typeIndex=%d,numElemValPairs=%d,numElementValuePairs=%s]",
                this.getClass().getSimpleName(),typeIndex,numElemValPairs,Arrays.toString(numElementValuePairs));
    }

    /**
     * Element value with index id
     */
    private static class ElementValuePair implements LoadableInfo,ResolvableInfo {
        private ElementValue value;
        private int elementNameIndex;
        
        /**
         * 
         */
        public void load(ClassInputStream cis) throws IOException {
            elementNameIndex = cis.readU2();
            value = new ElementValue();
            value.load(cis);
        }
        
        
        /**
         * 
         * @param pool
         * @throws IOException
         */
        public void resolve(Class pool) throws IOException{
            if(value != null){
                value.resolve(pool);
            }
            
        }
        
        @Override
        public String toString() {
            return String.format(
                    "[%s:elementNameIndex=%d,value=%s]",
                    this.getClass().getSimpleName(),elementNameIndex,value);
        }
    }

    /**
     * Element value in Annotation
     */
    private static class ElementValue implements LazyLoadableInfo,ResolvableInfo  {
        private int constValueIndex;
        private int enumConstTypeNameIndex;
        private int enumConstNameIndex;
        private int classInfoIndex;
        private int numValues;

        private Constant constValue;
        private ConstantUtf8 enumConstTypeName;
        private ConstantUtf8 enumConstName;
        private ConstantUtf8 returnClassCPInfo;
        private FieldDescriptor returnClassInfo;
        private Annotation annotationValue;
        private ElementValue[] arrayValue;
        private ElementType type;
        private char tag;

        /**
         * 
         * @param cis
         * @throws IOException
         */
        public void load(ClassInputStream cis) throws IOException {
            tag = (char) cis.readU1();

            type = ElementType.fromChar(tag);

            switch (type) {
            case CONST_VALUE:
                constValueIndex = cis.readU2();
                break;
            case ENUM_CONST_VALUE:
                enumConstTypeNameIndex = cis.readU2();
                enumConstNameIndex = cis.readU2();
                break;
            case CLASS_INFO_VALUE:
                classInfoIndex = cis.readU2();
                break;
            case ANNOTATION_VALUE:
                annotationValue = new Annotation();
                annotationValue.load(cis);
                break;
            case ARRAY_VALUE:
                numValues = cis.readU2();
                arrayValue = new ElementValue[numValues];
                
                for (int i = 0; i < arrayValue.length ;i++) {
                    arrayValue[i] = new ElementValue();
                    arrayValue[i].load(cis);
                }
                break;
            }
        }
        
        /**
         * 
         * @param pool
         * @throws IOException
         */
        public void resolve(Class clazz) throws IOException{
            ConstantPoolInfo pool = clazz.getPoolInfo();
            if(type != null){
                switch (type) {
                case CONST_VALUE:
                    constValue = pool.getContantPoolItem(constValueIndex);
                    break;
                case ENUM_CONST_VALUE:
                    enumConstTypeName = (ConstantUtf8)pool.getContantPoolItem(enumConstTypeNameIndex);
                    enumConstName = (ConstantUtf8)pool.getContantPoolItem(enumConstNameIndex);           
                    break;
                case CLASS_INFO_VALUE:
                    returnClassCPInfo = (ConstantUtf8)pool.getContantPoolItem(classInfoIndex);
                    returnClassInfo = new FieldDescriptor();
                    returnClassInfo.parse(returnClassCPInfo.getValue());
                    break;
                }
            }
        }
            @Override
            public String toString() {                
                switch (type) {
                case CONST_VALUE:
                    return String.format(
                            "[%s:tag=%c,type=%s,constValueIndex=%d,constValue=%s]",
                            this.getClass().getSimpleName(),tag,type,constValueIndex,constValue);
                case ENUM_CONST_VALUE:
                    return String.format(
                            "[%s:tag=%c,type=%s,enumConstTypeNameIndex=%d,enumConstTypeName=%s,enumConstNameIndex=%d,enumConstName=%s]",
                            this.getClass().getSimpleName(),tag,type,enumConstTypeNameIndex,enumConstTypeName,enumConstNameIndex,enumConstName);
                case CLASS_INFO_VALUE:
                    return String.format(
                            "[%s:tag=%c,type=%s,classInfoIndex=%d,returnClassCPInfo=%s]",
                            this.getClass().getSimpleName(),tag,type,classInfoIndex,returnClassCPInfo);
                case ANNOTATION_VALUE:
                    return String.format(
                            "[%s:tag=%c,type=%s,annotationValue=%s]",
                            this.getClass().getSimpleName(),tag,type,annotationValue);
                case ARRAY_VALUE:
                    return String.format(
                            "[%s:tag=%c,type=%s,numValues=%d,arrayValue=%s]",
                            this.getClass().getSimpleName(),tag,type,numValues,Arrays.toString(arrayValue));
                default :
                    return  String.format(
                            "[%s:tag=%c,type=%s]",
                            this.getClass().getSimpleName(),tag,type);

            }
            }
            /*
            if (isConstValue) {
                int const_value_index = cis.readU2();
                const_value = clazz.getConstant_pool()[const_value_index];
            } else if (isEnumConstValue) {
                int ec_type_name_index = cis.readU2();
                enum_const_type_name = (CONSTANT_Utf8) clazz.getConstant_pool()[ec_type_name_index];

                int ec_name_index = cis.readU2();
                enum_const_name = (CONSTANT_Utf8) clazz.getConstant_pool()[ec_name_index];
            } else if (isClassInfo) {
                int class_info_index = cis.readU2();
                returnClassCPInfo = (CONSTANT_Utf8) clazz.getConstant_pool()[class_info_index];
                returnClassInfo = new FieldDescriptor(returnClassCPInfo.getString());
            } else if (isAnnotationValue) {
                annotationValue = Annotation.load(cis, clazz);
            } else if (isArrayValue) {
                int num_values = cis.readU2();
                arrayValue = new ElementValuePair[num_values];
                for (int k = 0; k < num_values; k++) {
                    arrayValue[k] = new ElementValuePair(null, (char) cis.readU1());
                    arrayValue[k].loadValue(cis, clazz);
                }
            }
            */

    }
}
