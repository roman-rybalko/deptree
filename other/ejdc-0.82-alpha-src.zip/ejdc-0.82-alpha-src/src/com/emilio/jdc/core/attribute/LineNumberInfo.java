package com.emilio.jdc.core.attribute;

import java.io.IOException;

import com.emilio.jdc.core.LazyLoadableInfo;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class LineNumberInfo implements LazyLoadableInfo {
    private int startPc;
    private int lineNumber;

    /**
     * @param cis
     */
    public void load(ClassInputStream cis) throws IOException {
        startPc = cis.readU2();
        lineNumber = cis.readU2();
    }
    
    public int getStartPc() {
        return startPc;
    }



    public int getLineNumber() {
        return lineNumber;
    }



    @Override
    public String toString() {
        return String.format("[%s:startPc=%d,lineNumber=%d]", this.getClass()
                .getSimpleName(), startPc, lineNumber);
    }
}
