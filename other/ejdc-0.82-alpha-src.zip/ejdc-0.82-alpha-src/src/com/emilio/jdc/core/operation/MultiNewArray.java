package com.emilio.jdc.core.operation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.emilio.jdc.core.FieldDescriptor;
import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.constant.ConstantClass;
import com.emilio.jdc.core.operation.expr.NewMultiArrayExpr;
import com.emilio.jdc.core.type.Value;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class MultiNewArray extends Operation{
    private int index;
    private ConstantClass type;
    private int dimensionCount;
    private FieldDescriptor field;

    /**
     * @param arg
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public MultiNewArray(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void parseParams(){
        
        index = mergeUnsignedBytes(parameters[ZERO],parameters[ONE]);
        
        type = (ConstantClass)context.getConstantPoolInfo().getContantPoolItem(index);
        
        dimensionCount = parameters[TWO];
        
        field = new FieldDescriptor();
        field.parse(type.getDescriptorName()); 
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        List<Value> dimensions = new ArrayList<Value>();
        
        for (int i = 0 ;i < dimensionCount ;i++){
            dimensions.add(stack.pop());
        }
        
        Collections.reverse(dimensions);
        
        expr = NewMultiArrayExpr.of(dimensions, field);
        
        stack.push(this);
        
//        OperationView[] dims2 = new OperationView[((MultiNewArray) operation).getDimensions()];
//        for (int i = 0; i < ((MultiNewArray) operation).getDimensions(); i++)
//        {
//            OperationView push = context.pop();
//            dims2[((MultiNewArray) operation).getDimensions() - i - 1] = push;
//        }
//
//        Object[] items = new Object[3 * dims2.length + 1];
//        items[0] = "new " + alias(((MultiNewArray) operation).getArrayType().substring(0, ((MultiNewArray) operation).getArrayType().indexOf("[]")));
//        for (int i = 0; i < ((MultiNewArray) operation).getDimensions(); i++)
//        {
//            items[i * 3 + 1] = "[";
//            items[i * 3 + 2] = dims2[i];
//            items[i * 3 + 3] = "]";
//        }
//        view = items;
//        context.push(this);
    }
    
    /**
     * 
     * @return
     */
    public Object getValue(){
        return expr.toText();
    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:byteCode=%d,index=%d,constClass=%s,dimensions=%d]", this
                        .getClass().getSimpleName(),byteCode,index,type,dimensionCount);
    }


}
