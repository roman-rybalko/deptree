package com.emilio.jdc.core.attribute;

import java.io.IOException;

import com.emilio.jdc.core.Class;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class Synthetic extends AttributeInfoItem {

    /**
     * Constructor
     * 
     * @param item
     */
    public Synthetic(AttributeInfoItem item) {
        super(item);
    }

    public Synthetic() {
        super();
    }

    @Override
    public AttributeInfoItem resolve(Class clazz) throws IOException {
        return this;
    }

}
