package com.emilio.jdc.core.operation;

import static com.emilio.jdc.core.type.BaseType.I;
import static com.emilio.jdc.core.type.BaseType.J;
import static com.emilio.jdc.core.type.OperatorsType.AND;
import static com.emilio.jdc.core.type.OperatorsType.OR;
import static com.emilio.jdc.core.type.OperatorsType.SHL;
import static com.emilio.jdc.core.type.OperatorsType.SHR;
import static com.emilio.jdc.core.type.OperatorsType.USHR;
import static com.emilio.jdc.core.type.OperatorsType.XOR;

import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.exception.BadFormatException;
import com.emilio.jdc.core.operation.expr.BitOperationExpr;
import com.emilio.jdc.core.type.BaseType;
import com.emilio.jdc.core.type.OperatorsType;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class BitOperation extends Operation {
    private OperatorsType operatorType;
    private BaseType operandType;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }

    public void parseParams() {
        setOperandType();
        setOperatorType();
    }

    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public BitOperation(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);

    }

    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table) {
        Operation value1 = stack.pop();
        Operation value2 = stack.pop();
        
        expr = BitOperationExpr.of(value1, value2, operatorType);

        // view = new Object[]{"(", prev2, " " + ((BitArithmetic)
        // operation).getOperation() + " ", prev1, ")"};
        stack.push(this);

    }
    
    /**
     * 
     * @return
     */
    public Object getValue(){
        return expr.toText();
    }
    

    /**
     * 
     */
    private void setOperandType() {
        switch (getOP()) {
        case ISHL:
        case ISHR:
        case IUSHR:
        case IAND:
        case IOR:
        case IXOR:
            operandType = I;
            break;
        case LSHL:
        case LSHR:
        case LUSHR:
        case LAND:
        case LOR:
        case LXOR:
            operandType = J;
            break;
        default:
            throw new BadFormatException("BitArithmetic: unknown opcode��" + getOP());
        }
    }

    /**
     * 
     */
    private void setOperatorType() {

        switch (getOP()) {
        case ISHL:
        case LSHL:
            operatorType = SHL;
            break;
        case ISHR:
        case LSHR:
            operatorType = SHR;
            break;
        case IUSHR:
        case LUSHR:
            operatorType = USHR;
            break;
        case IAND:
        case LAND:
            operatorType = AND;
            break;
        case IOR:
        case LOR:
            operatorType = OR;
            break;
        case IXOR:
        case LXOR:
            operatorType = XOR;
            break;
        default:
            throw new BadFormatException("BitArithmetic: unknown opcode��" + getOP());
        }
    }

    @Override
    public String toString() {
        return String.format("[%s:operatorType=%s,operandType=%s]", this
                .getClass().getSimpleName(), operatorType, operandType);
    }
}
