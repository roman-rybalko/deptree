package com.emilio.jdc.core.attribute;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.LoadableInfo;
import com.emilio.jdc.core.ResolvableAttribute;
import com.emilio.jdc.core.ResolvableInfo;
import com.emilio.jdc.core.attribute.annotation.AnnotationDefault;
import com.emilio.jdc.core.attribute.annotation.RuntimeInvisibleAnnotations;
import com.emilio.jdc.core.attribute.annotation.RuntimeInvisibleParameterAnnotations;
import com.emilio.jdc.core.attribute.annotation.RuntimeVisibleAnnotations;
import com.emilio.jdc.core.attribute.annotation.RuntimeVisibleParameterAnnotations;
import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.type.AttributeType;
import com.emilio.jdc.core.util.ClassInputStream;
import com.emilio.jdc.core.util.ClassStreamFactory;

/**
 * 
 * @author Emilio Liang
 * 
 * Parent class for all attributes, 
 *
 */

public abstract class AttributeInfoItem implements LoadableInfo, ResolvableAttribute, Expression {

    protected AttributeType attributeType;
    protected int attrNameIndex;
    protected String attributeName;
    

    protected long attrLength;
    protected byte[] attrContent = new byte[0];
    protected Class clazz;
    

    /**
     * Constructor
     */
    public AttributeInfoItem() {
    }

    /**
     * 
     * @param item
     */
    //TODO change to package default ?
    public AttributeInfoItem(AttributeInfoItem item) {
        this.attrNameIndex = item.attrNameIndex;
        this.attributeName = item.attributeName;
        this.attrLength = item.attrLength;
        this.attrContent = item.attrContent;
        this.clazz = item.clazz;
    }
    /**
     *@param cis
     */
    public void load(ClassInputStream cis) throws IOException {
        attrNameIndex = cis.readU2();
        attrLength = cis.readU4();
        
        assert attrLength != 0;
       
        if(attrLength != 0){
            attrContent = new byte[(int) attrLength];
            cis.read(attrContent);
        }
    }

    /**
     *@param pool
     */
    public  AttributeInfoItem resolve(Class clazz) throws IOException {
        this.clazz = clazz;
        ConstantPoolInfo pool = clazz.getPoolInfo();

        if (attrNameIndex > 0) {
            attributeName = pool.getContantPoolItem(attrNameIndex).getValue();
            return loadAttribute(clazz, attributeName);
        } else {
            return this;
        }
    }

    /**
     * 
     * @return
     * @thows IOException
     */
    protected ClassInputStream getStream() throws IOException {
        return ClassStreamFactory.getInputStream(attrContent);
    }

    /**
     * loadInfoTables
     * 
     * @param <E>
     * @param infoTableSize
     * @param type
     * @param cis
     * @return
     */
  
    protected <E extends LoadableInfo> List<E> loadInfoTables(
            int infoTableSize, java.lang.Class<E> type, ClassInputStream cis) {
        List<E> list = new ArrayList<E>(infoTableSize);
        if (infoTableSize > 0) {

            for (int i = 0; i < infoTableSize; i++) {
                // TODO Exception handling
                try {
                    list.add(type.newInstance());
                    list.get(i).load(cis);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        return list;
    }
    
    /**
     * 
     * @param <E>
     * @param list
     * @param clazz
     */
    protected  <E extends ResolvableInfo> void resovleInfoTables(List<E> list, Class clazz) {

            for (E e :list) {
                // TODO Exception handling
                try {
                    e.resolve(clazz);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }


    /**
     * loadAttribute
     * 
     * @param pool
     * @param attributeName
     * @return
     * @throws IOException
     */
    private AttributeInfoItem loadAttribute(Class clazz,
            String attributeName) throws IOException {
        AttributeInfoItem attribute = null;
        
        AttributeType type = AttributeType.getAttributeType(attributeName);
        
        switch (type) {
        case ANNOTATION_DEFAULT:
            attribute = new AnnotationDefault();
            break;
        case CODE:
            attribute = new Code(this);
            break;
        case CONSTANT_VALUE:
            attribute = new ConstantValue(this);
            break;
        case DEPRECATED:
            attribute = new Deprecated(this);
            break;
        case ENCLOSING_METHOD:
            attribute = new EnclosingMethod(this);
            break;
        case EXCEPTIONS:
            attribute = new Exceptions(this);
            break;
        case INNER_CLASSES:
            attribute = new InnerClasses(this);
            break;
        case LINE_NUMBER_TABLE:
            attribute = new LineNumberTable(this);
            break;
        case LOCAL_VARIABLE_TABLE:
            attribute = new LocalVariableTable(this);
            break;
        case LOCAL_VARIABLE_TYPE_TABLE:
            attribute = new LocalVariableTypeTable(this);
            break;
        case SIGNATURE:
            attribute = new Signature(this);
            break;
        case STACK_MAP_TABLE:
            attribute = new StackMapTable(this);
            break;
        case SYNTHETIC:
            attribute = new Synthetic(this);
            break;
        case SOURCE_DEBUG_EXTENSION:
            attribute = new SourceDebugExtension(this);
            break;
        case SOURCE_FILE:
            attribute = new SourceFile(this);
            break;
        case RUNTIME_INVISIBLE_ANNOTATIONS:
            attribute = new RuntimeInvisibleAnnotations(this);
            break;
        case RUNTIME_INVISIBLE_PARAMETER_ANNOTATIONS:
            attribute = new RuntimeInvisibleParameterAnnotations(this);
            break;
        case RUNTIME_VISIBLE_ANNOTATIONS:
            attribute = new RuntimeVisibleAnnotations(this);
            break;
        case RUNTIME_VISIBLE_PARAMETER_ANNOTATIONS:
            attribute = new RuntimeVisibleParameterAnnotations(this);
            break;
        case UNDEFINED:
            attribute = new GenericAttribute();
            break;
        }
        
        attribute.setAttributeType(type);
        
        return attribute.resolve(clazz);
    }
    
    /**
     * 
     * @return
     */
    public Class getClazz(){
        //TODO need to remove if child class also save this field;
        return clazz;
    }

    /**
     * 
     * @return
     */
    public AttributeType getAttributeType() {
        return attributeType;
    }
    
    private void setAttributeType(AttributeType attributeType) {
        this.attributeType = attributeType;
    }
    
    public String toText(){
        return attributeName;
    }

    public void print(PrintWriter pw) {
    }

    @Override
    public String toString() {
        return String.format(
                "[%s:attrNameIndex=%d,attributeName=%s,attrLength=%d]", this
                        .getClass().getSimpleName(), attrNameIndex,
                attributeName, attrLength);
    }

}
