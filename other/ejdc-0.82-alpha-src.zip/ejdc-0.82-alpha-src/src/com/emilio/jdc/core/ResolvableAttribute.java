package com.emilio.jdc.core;

import java.io.IOException;

import com.emilio.jdc.core.attribute.AttributeInfoItem;

/**
 * 
 * @author Emilio Liang
 * 
 * Define process to resolve all attribute info.
 *
 */
public interface ResolvableAttribute {
    public AttributeInfoItem resolve(com.emilio.jdc.core.Class clazz) throws IOException;
}
