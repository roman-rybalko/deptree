package com.emilio.jdc.core.attribute;

import java.io.IOException;
import java.util.Set;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.ConstantPoolInfo;
import com.emilio.jdc.core.LazyLoadableInfo;
import com.emilio.jdc.core.ResolvableInfo;
import com.emilio.jdc.core.constant.ConstantClass;
import com.emilio.jdc.core.constant.ConstantUtf8;
import com.emilio.jdc.core.type.access.AccessFlagTypeUtil;
import com.emilio.jdc.core.type.access.AccessType;
import com.emilio.jdc.core.type.access.InnerClassAccFlagType;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class InnerClassInfo implements LazyLoadableInfo, ResolvableInfo, AccessType {
    private int innerClassInfoIndex;
    private int outerClassInfoIndex;
    private int innerNameIndex;
    private int accessFlags;
    private ConstantClass innerClassInfo;
    private ConstantClass outerClassInfo;
    private ConstantUtf8 innerName;
    private boolean anonymous;
    private Set<InnerClassAccFlagType> innerClassAccFlagSet;

    /**
     * @param cis
     */
    public void load(ClassInputStream cis) throws IOException {
        innerClassInfoIndex = cis.readU2();
        outerClassInfoIndex = cis.readU2();
        innerNameIndex = cis.readU2();
        accessFlags = cis.readU2();
        innerClassAccFlagSet = AccessFlagTypeUtil.ofAccFlagSet(InnerClassAccFlagType.class, accessFlags);
    }

    /**
     * 
     */
    public void resolve(Class clazz) throws IOException {
        ConstantPoolInfo pool = clazz.getPoolInfo();
        innerClassInfo = (ConstantClass) pool.getContantPoolItem(innerClassInfoIndex);
        outerClassInfo = (ConstantClass) pool.getContantPoolItem(outerClassInfoIndex);
        if (innerNameIndex != 0) {
            innerName = (ConstantUtf8) pool.getContantPoolItem(innerNameIndex);
        } else {
            anonymous = true;
        }
    }

    public ConstantClass getInnerClassInfo() {
        return innerClassInfo;
    }

    public ConstantClass getOuterClassInfo() {
        return outerClassInfo;
    }

    public ConstantUtf8 getInnerName() {
        return innerName;
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public Set<InnerClassAccFlagType> getAccFlagSet() {
        return innerClassAccFlagSet;
    }

    @Override
    public String toString() {
        return String
                .format(
                        "[%s:innerClassInfoIndex=%d,outerClassInfoIndex=%d,innerNameIndex=%d,accessFlags=%d]",
                        this.getClass().getSimpleName(), innerClassInfoIndex,
                        outerClassInfoIndex, innerNameIndex, accessFlags);
    }
}
