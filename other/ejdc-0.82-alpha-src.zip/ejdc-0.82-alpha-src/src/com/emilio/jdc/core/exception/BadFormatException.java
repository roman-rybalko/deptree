package com.emilio.jdc.core.exception;

/**
 * 
 * @author Emilio Liang
 *
 */
public class BadFormatException extends RuntimeException {
    /**
     * serialVersionUID used to identify the version of the serializable object
     */
    private static final long serialVersionUID = -2845627047083008466L;
    private static final String DEFAULT_MESSAGE = "Class format validation error";

    public BadFormatException() {
        this(DEFAULT_MESSAGE);
    }

    public BadFormatException(String message, Object... args) {
        super(String.format(message, args));
    }

    public BadFormatException(Throwable cause, String message, Object... args) {
        super(String.format(message, args), cause);
    }

    public BadFormatException(Throwable cause) {
        super(cause);
    }

}
