package com.emilio.jdc.core.type;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum PushType{
    BYTE(BaseType.B),
    CHAR(BaseType.C),
    DOUBLE(BaseType.D),
    FLOAT(BaseType.F),
    INTEGER(BaseType.I),
    LONG(BaseType.J),
    SHORT(BaseType.S),
    BOOLEAN(BaseType.V),
    //VOID(ReturnType.VOID),
    //CONSTANT(ReturnType.OBJECT),
    OBJECT(ReturnType.OBJECT),    
    ARRAY(ReturnType.ARRAY),
    NONE(null),
    NULL(SymbolWrapper.fromString("null"));
    
    private final Symbol symbol;
    
    private PushType(Symbol symbol){
        this.symbol = symbol;
    }
    
    public Symbol getSymbol(){
        return this.symbol;
    }
}
