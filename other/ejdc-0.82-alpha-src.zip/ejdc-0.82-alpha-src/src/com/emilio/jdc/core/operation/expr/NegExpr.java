package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.OperatorsType;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class NegExpr extends AbstractUniOpExpr{
    /**
     * 
     * @param value
     * @param operator
     * @return
     */
    public static NegExpr of(Value value, OperatorsType operator){
        return new NegExpr(value,operator);
    }
    
    /**
     * 
     * @param value
     * @param operator
     */
    private NegExpr(Value value, OperatorsType operatorSymbol){
        this.value = value;
        this.operatorSymbol = operatorSymbol;
    }
    
    @Override
    public String toText(){
        StringBuilder text = new StringBuilder(50);
        
        text.append(operatorSymbol);
        text.append(value.getValue());
        
        return text.toString();
    }
}
