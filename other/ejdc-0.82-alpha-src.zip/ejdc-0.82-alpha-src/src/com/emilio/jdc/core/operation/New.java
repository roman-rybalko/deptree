package com.emilio.jdc.core.operation;


import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.constant.ConstantClass;
import com.emilio.jdc.core.operation.expr.NewExpr;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class New extends Operation {
    private ConstantClass constClass = null;
    private int index;
    
    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public New(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void parseParams(){
        
        index = mergeUnsignedBytes(parameters);
        
        constClass = (ConstantClass)context.getConstantPoolInfo().getContantPoolItem(index);
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        //TODO need to handle inner class
        //TODO what about full constructor?
        expr = NewExpr.of(this);
        
        stack.push(this);
//        Inner Class support
//        clazzName = ((New) operation).getNewType();
//        if (clazzName.indexOf('$') != -1)
//        {
//            InnerClass ic = methodView.getClazzView().getInnerClass(clazzName);
//            if (ic != null)
//            {
//                if (ic.getInnerName() == null)
//                {
//                    isACConstructor = true;
//                    anonymousClass = ic;
//                }
//                clazzName = clazzName.substring(clazzName.indexOf('$') + 1);
//                isICConstructor = true;
//            }
//        }
//
//        view = new Object[]{alias(clazzName)};
//        context.push(this);
    }
    
    @Override
    public Object getValue(){
        return constClass.getValue();
    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:byteCode=%d,index=%d,constClass=%s]", this
                        .getClass().getSimpleName(),byteCode,index,constClass);
    }
}
