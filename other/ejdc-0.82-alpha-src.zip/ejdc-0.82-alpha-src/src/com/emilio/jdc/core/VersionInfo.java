package com.emilio.jdc.core;

import java.io.IOException;

import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 * 
 * Wrapper class for class version, include minor version and major version
 *
 */
public final class VersionInfo implements LoadableInfo, Expression {
    private int majorVersion;
    private int minorVersion;

    public VersionInfo() {
    }

    public void load(ClassInputStream cis) throws IOException {
        minorVersion = cis.readU2();
        majorVersion = cis.readU2();
    }

    public int getMajorVersion() {
        return majorVersion;
    }

    public int getMinorVersion() {
        return minorVersion;
    }
    
    public String toText(){
        return majorVersion+"."+minorVersion;
    }

    @Override
    public String toString() {
        return String.format("[%s:majorVersion=%d,minorVersion=%d]", this
                .getClass().getSimpleName(),
                majorVersion,
                minorVersion);
    }

}
