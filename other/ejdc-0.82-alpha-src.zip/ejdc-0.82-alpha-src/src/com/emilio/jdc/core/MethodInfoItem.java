package com.emilio.jdc.core;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Set;

import com.emilio.jdc.core.attribute.AttributeInfo;
import com.emilio.jdc.core.attribute.Code;
import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.type.access.AccessFlagTypeUtil;
import com.emilio.jdc.core.type.access.AccessType;
import com.emilio.jdc.core.type.access.MethodAccFlagType;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent one method in one class.
 *
 */
public final class MethodInfoItem implements LoadableInfo, ResolvableInfo, AccessType , Expression{
    private int accessFlags;
    private int nameIndex;
    private int descIndex;
    private String methodName;
    private String methodDescStr;
    private MethodDescriptor methodDesc;
    private AttributeInfo attrInfo;
    private Set<MethodAccFlagType> methodAccFlagSet;
    private Class clazz;
    private Code code;
    private boolean isStatic;

    /**
     * Class
     * @return
     */
    public Class getMethodClass() {
        return clazz;
    }

    /**
     * Constructor
     */
    public MethodInfoItem() {
    }

    /**
     * 
     */
    public void load(ClassInputStream cis) throws IOException {
        accessFlags = cis.readU2();
        nameIndex = cis.readU2();
        descIndex = cis.readU2();
        attrInfo = new AttributeInfo();
        attrInfo.load(cis);
    }

    /**
     * 
     */
    public void resolve(Class clazz) throws IOException {
        //set current method, so Code attribute can get it.
        clazz.setCurrentMethod(this);
        
        ConstantPoolInfo pool = clazz.getPoolInfo();
        
        this.clazz = clazz;
        
        methodAccFlagSet = AccessFlagTypeUtil.ofAccFlagSet(
                MethodAccFlagType.class, accessFlags);
        
        if (methodAccFlagSet.contains(MethodAccFlagType.STATIC)){
            isStatic = true;
        }
        
        methodName = pool.getContantPoolItem(nameIndex).getValue();
        methodDescStr = pool.getContantPoolItem(descIndex).getValue();
        attrInfo.resolve(clazz);
                
        methodDesc = new MethodDescriptor();
        methodDesc.parse(methodDescStr);
    }
    
    /**
     * 
     * @param pw
     */
    public void print(PrintWriter pw) {
        for (MethodAccFlagType accFlag : methodAccFlagSet) {
            pw.print(accFlag);
            pw.print(" ");
        }
        
        ReturnDescriptor retType = methodDesc.getReturnType();
        
        retType.print(pw);
        
        pw.print(" ");
        
        pw.print(methodName);

        pw.print("(");
        
        for(int i = 0; i < methodDesc.getParameters().size() ;i++){
            FieldDescriptor fd = methodDesc.getParameters().get(i);
            fd.print(pw);
            if (i != methodDesc.getParameters().size() -1){
                pw.print(" ,");
            }
        }
       
        pw.print(") {");
        
        attrInfo.print(pw);
        
        pw.println("}");
        
    }
    
    public String toText(){
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        print(pw);
        return sw.toString();
    }

    public String getMethodName() {
        return methodName;
    }

    public Set<MethodAccFlagType> getAccFlagSet() {
        return methodAccFlagSet;
    }
    
    /**
     * 
     * @return MethodDescriptor
     */
    public MethodDescriptor getMethodDesc() {
        return methodDesc;
    }
    
    /**
     * 
     * @param code
     */
    public void setCode(Code code){
        this.code = code;
    }

    /**
     * 
     * @return
     */
    public Code getCode(){
        return this.code;
    }
    
    /**
     * 
     * @return
     */
    public boolean isStatic() {
        return isStatic;
    }
    
    
    @Override
    public String toString() {
        return String
                .format("[%s:nameIndex=%d,descIndex=%d,methodName=%s,methodDesc=%s,attrInfo:%s]",
                        this.getClass().getSimpleName(), 
                        nameIndex, 
                        descIndex,
                        methodName, 
                        methodDesc, 
                        attrInfo);
    }

}
