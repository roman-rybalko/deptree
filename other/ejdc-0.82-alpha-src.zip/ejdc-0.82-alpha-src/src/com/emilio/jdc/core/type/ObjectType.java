package com.emilio.jdc.core.type;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum ObjectType {
    STRING,
    BASE_TYPE,
    OBJECT_REF,
    OPERATION;
}
