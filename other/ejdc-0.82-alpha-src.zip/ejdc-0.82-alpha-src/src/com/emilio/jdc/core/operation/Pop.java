package com.emilio.jdc.core.operation;

import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Pop extends Operation {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public Pop(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }
    
    @Override
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        switch(this.getOP()){
        case POP:
            stack.pop();
            break;
        case POP2:
            stack.pop();
            stack.pop();
            break;
        }
        
//        if (getOpcode() == 87)  // pop
//        {
//            if (pushOp instanceof InvokeView)
//            {
//                view = new Object[]{pushOp};
//            }
//        }
//        if (getOpcode() == 88)  // pop2
//        {
//            if (pushOp instanceof InvokeView)
//            {
//                view = new Object[]{pushOp};
//            }
//
//            String pusht = pushOp.getPushType();
//            if (!"double".equals(pusht) && !"long".equals(pusht))    // pop2 form1 support
//            {
//                context.pop();   // removing previous second push
//            }
//        }
    }

}
