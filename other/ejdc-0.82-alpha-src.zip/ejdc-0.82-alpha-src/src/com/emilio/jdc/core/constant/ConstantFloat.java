package com.emilio.jdc.core.constant;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.type.ConstantType;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent CONSTANT_Float table in constant_pool 
 * 
 */
public final class ConstantFloat extends Constant {
	/**
	 * float value
	 */
    private float floatVal;

    /**
     * Constructor
     * 
     * @param num
     * @param type
     */
    public ConstantFloat(int num, ConstantType type) {
        super(num, type);
    }

    @Override
    public void load(ClassInputStream cis) throws IOException {
        //TODO find all jis
        this.floatVal = cis.readFloat();
    }

    @Override
    public void resolve(Class clazz) {
    }

    @Override
    public String getValue() {
        return String.valueOf(floatVal);
    }

    @Override
    public int getIndex() {
        return 0;
    }

    @Override
    public String toString() {
        return String.format("[%s:index=%d,type=%s,floatValue=%f]", this
                .getClass().getSimpleName(), index, type, floatVal);
    }

}
