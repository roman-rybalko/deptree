package com.emilio.jdc.core.attribute.annotation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.attribute.AttributeInfoItem;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 *
 */
public class RuntimeVisibleAnnotations extends AttributeInfoItem {
    private int numAnnotations;
    private List<Annotation> annotations = new ArrayList<Annotation>();
//    RuntimeVisibleAnnotations_attribute {
//        u2 attribute_name_index;
//        u4 attribute_length;
//        u2 num_annotations;
//        annotation annotations[num_annotations];
//        }
    
//    annotation {
//        u2 type_index;
//        u2 num_element_value_pairs;
//        { u2 element_name_index;
//        element_value value;
//        } element_value_pairs[num_element_value_pairs]
//        }    
    
    /**
     * Constructor
     * 
     * @param item
     */
    public RuntimeVisibleAnnotations(AttributeInfoItem item) {
        super(item);
    }
    
    @Override
    public AttributeInfoItem resolve(Class clazz) throws IOException {
        ClassInputStream cis = getStream();
        numAnnotations = cis.readU2();
        
        annotations = loadInfoTables(numAnnotations,Annotation.class, cis);
        
        resovleInfoTables(annotations,clazz);

        return this;
    }
    
    @Override
    public String toString() {
        return String.format(
                "[%s:attrNameIndex=%d,attributeName=%s,attrLength=%d,numAnnotations=%s,annotations=%s]", this
                        .getClass().getSimpleName(), attrNameIndex,
                attributeName, attrLength,numAnnotations,annotations);
    }

}
