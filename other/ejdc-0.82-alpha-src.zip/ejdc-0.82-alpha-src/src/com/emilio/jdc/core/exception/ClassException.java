package com.emilio.jdc.core.exception;

/**
 * 
 * @author Emilio Liang
 *
 */
public class ClassException extends RuntimeException {
    /**
     * serialVersionUID used to identify the version of the serializable object
     */
    private static final long serialVersionUID = 4004591300488127232L;
    private static final String DEFAULT_MESSAGE = "Class format validation error";

    public ClassException() {
        this(DEFAULT_MESSAGE);
    }

    public ClassException(String message) {
        super(message);
    }

    public ClassException(String message, Throwable cause) {
        super(message, cause);
    }

    public ClassException(Throwable cause) {
        super(cause);
    }

}
