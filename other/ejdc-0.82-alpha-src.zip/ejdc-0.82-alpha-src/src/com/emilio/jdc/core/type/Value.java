package com.emilio.jdc.core.type;

/**
 * 
 * @author Emilio Liang
 *
 */
public interface Value{
    /**
     * 
     * @return
     */
    public ObjectType getType();

    /**
     * 
     * @return
     */
    public Object getValue();
}
