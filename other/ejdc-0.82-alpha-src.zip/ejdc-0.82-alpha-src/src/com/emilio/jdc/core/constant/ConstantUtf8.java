package com.emilio.jdc.core.constant;

import java.io.IOException;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.type.ConstantType;
import com.emilio.jdc.core.util.ClassInputStream;

/**
 * 
 * @author Emilio Liang
 * 
 * Represent CONSTANT_Utf8 table in constant_pool 
 * 
 */
public final class ConstantUtf8 extends Constant {
	/**
	 * utf-8 value
	 */
    private String utf8Val;

    /**
     * Constructor
     * 
     * @param num
     * @param tag
     */
    public ConstantUtf8(int num, ConstantType type) {
        super(num, type);
    }

    @Override
    public void load(ClassInputStream jis) throws IOException {
        utf8Val = jis.readUTF();
    }

    @Override
    public String getValue() {
        return utf8Val;
    }

    @Override
    public int getIndex() {
        return index;
    }

    @Override
    public void resolve(Class clazz) {
    }

    @Override
    public String toString() {
        return String.format("[%s:index=%d,type=%s,utf8Value=%s]", this
                .getClass().getSimpleName(), index, type, utf8Val);
    }
}
