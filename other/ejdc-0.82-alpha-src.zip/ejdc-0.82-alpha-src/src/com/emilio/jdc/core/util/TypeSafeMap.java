package com.emilio.jdc.core.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.emilio.jdc.core.constant.ConstantInterfaceMethodRef;
import com.emilio.jdc.core.constant.ConstantMethodRef;
import com.emilio.jdc.core.constant.ConstantNameAndType;
import com.emilio.jdc.core.type.ConstantType;

/**
 * 
 * @author Emilio Liang
 *
 */
public class TypeSafeMap implements Map<Class<?>, Object> {
    protected Map<Class<?>, Object> map = new HashMap<Class<?>, Object>();

//    public <T> Object put(Class<T> type, T instance) {
//        if (type == null)
//            throw new NullPointerException("Type is null");
//        return map.put(type, instance);   
//    }
    
    public  Object put(Class<?> type, Object value) {
        if (type == null){
            throw new NullPointerException("Type is null");
        }
        return map.put(type, value);   
    }

    public <T> T get(Class<T> type) {
        return type.cast(map.get(type));
    }
    
    public void clear(){
    }
    
    public boolean containsKey(Object key){
        return map.containsKey(key);
    }
    
    public boolean containsValue(Object value){
        return map.containsValue(value);
    } 
    
    public Set<Map.Entry<Class<?>, Object>> entrySet(){
        return map.entrySet();
    } 
    
    public boolean equals(Object o){
        return map.equals(o);
    }

    public int hashCode(){
        return map.hashCode();
    } 
    
    public boolean isEmpty(){
        return map.isEmpty();
    }
    
    public Set<Class<?>> keySet(){
        return map.keySet();
    } 
     

    public void putAll(Map<? extends Class<?>,? extends Object> t){
    } 
    
    public Object remove(Object key){
        return map.remove(key);
    } 

    public int size(){
        return map.size();
    } 

    public Collection<Object> values(){
        return map.values();
    }

    public Object get(Object key) {
        // TODO Auto-generated method stub
        return null;
    }

    public static void main(String args[]){
        ConstantInterfaceMethodRef interfaceMethodRef = new ConstantInterfaceMethodRef(1,ConstantType.CONSTANT_InterfaceMethodref);
        ConstantMethodRef methodRef = new ConstantMethodRef(2,ConstantType.CONSTANT_Methodref);
        ConstantNameAndType nameAndType = new ConstantNameAndType(3,ConstantType.CONSTANT_NameAndType);
        
        TypeSafeMap map = new TypeSafeMap();
        
        map.put(ConstantInterfaceMethodRef.class, interfaceMethodRef);
        map.put(ConstantMethodRef.class, methodRef);
        map.put(ConstantNameAndType.class, nameAndType);
        
        nameAndType = map.get(ConstantNameAndType.class);
        
        System.out.println(map.get(ConstantNameAndType.class));
        System.out.println(map.get(ConstantMethodRef.class));
        System.out.println(map.get(ConstantInterfaceMethodRef.class));
        
    }
    
}
