package com.emilio.jdc.core.operation;

import java.math.BigInteger;

import com.emilio.jdc.core.MethodInfoItem;
import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.exception.BadFormatException;
import com.emilio.jdc.core.exception.UnsupportedTypeException;
import com.emilio.jdc.core.opcode.ByteCode;
import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.type.ObjectType;
import com.emilio.jdc.core.type.PushType;
import com.emilio.jdc.core.type.Value;
import com.emilio.jdc.core.util.OperandStack;
import com.emilio.jdc.decompile.structure.Block;
import com.emilio.jdc.decompile.structure.CodeStruct;

/**
 * 
 * @author Emilio Liang
 *
 * Parent class for all operation classes, every operation represents single byte code instruction or one group similar byte code instruction
 */
public abstract class Operation implements CodeStruct,Value{
    static final int ZERO =  0;
    static final int ONE =   1;
    static final int TWO =   2;
    static final int THREE = 3;
    static final int FOUR =  4;
    static final int FIVE =  5;
    
    int paramNum;
    final int byteCode;
    final int byteIndex;
    int[] parameters;
    //final Code code;
    final MethodContext context;
    private final ByteCode op;
    Expression expr;
    OperationType operationType;
    
    //TODO
    //protected List<Pair<ObjectType,? extends Object>> exprObjs = new ArrayList<Pair<ObjectType,? extends Object>>();

    /**
     * Constructor 
     * @param byteCode
     * @param code
     * @param index
     */
    public Operation(int byteCode, int byteIndex, MethodContext context){
        //System.out.println("Operation.byteIndex----"+byteIndex);
        this.byteIndex = byteIndex;
        this.byteCode = byteCode;
        this.context = context;
        op = ByteCode.of(byteCode);
        
        operationType = OperationType.getType(this.getClass());
                
        if (op == null){
           throw new BadFormatException("Unkown op="+byteCode);
        }
    }
    
    void setOperationType(OperationType operationType){
        this.operationType = operationType;
    }
    
    /**
     * Load operation parameter from byte array, and return loaded byte number
     * @param next
     * @param byteContent
     * @return
     */
    public int loadParams(int next, int[] byteContent) {        
        return loadParams(next, op.getParamByteNum(), byteContent); 
    }
    
    /**
     * 
     */
    public void parseParams() {
        
    }
    
    /**
     * 
     */
    public void resolve(MethodInfoItem method){
        
    }
    
    /**
     * 
     * @param stack
     * @param table
     */
    abstract void mergeStack(OperandStack<Operation> stack, LocalVariableTable table);

    
    /**
     * 
     * @param next
     * @param paramByteNum
     * @param byteContent
     * @return
     */
    protected int loadParams(int next ,int paramByteNum ,  int[] byteContent) {
        if(paramByteNum < 0){
            throw new UnsupportedTypeException("ParamByteNum should not be negative");
        }
                
        if(paramByteNum == 0){
            return 0;
        }
                
        parameters = new int[paramByteNum];

        for (int j = 0; j < parameters.length; next++, j++) {
            parameters[j] = byteContent[next];
        }
        
        //TODO Recursive why?
        //return op.getParamByteNum();
        
        return paramByteNum;
    }

    /**
     * 
     */
//    public OperandType getOperandType() {
//        return op.getType();
//    }
    
    /**
     * Shift parameter by 8 bit unit to merge them together as an Integer 
     * @param parameters array
     * @return
     */
    protected static int mergeUnsignedBytes(int...parameters) {
        if(parameters == null || parameters.length > 4){
            throw new UnsupportedTypeException("Exceed shift limit for integer");
        }
        
        int result = 0;

        for (int i = 0, j = parameters.length - 1; i < parameters.length; i++, j--) {
            result = (parameters[i] << (j * 8)) | result;
        }

        return result;
    }

    /**
     * 
     * @param parameters
     * @return
     */
    protected static int mergeSignedBytes(int ...parameters) {
        if(parameters == null || parameters.length > 4){
            throw new UnsupportedTypeException("Exceed shift limit for integer");
        }
        
        byte[] paramBytes = new byte[parameters.length];
        
        for(int i = 0 ;i < parameters.length; i++){
            paramBytes[i] = toSignedByte(parameters[i]);
        }
        
        BigInteger big = new BigInteger(paramBytes) ;
        
        return big.intValue();
    }
    
    
    /**
     * Convert unsigned byte to signed byte
     * @param input
     * @return
     *
     */
    protected static byte toSignedByte(int input){
        if(input <= 127 && input >= -128 ){
            return (byte)input;
        }else{
            return (byte)(~(input ^ 0xff));
        }
    }
    
    /**
     * 
     * @return
     */
    public Expression getExpression(){
        return expr;
    }
    
    /**
     * 
     * @return
     */
    public ObjectType getType(){
        return ObjectType.OPERATION;
    }

    /**
     * 
     * @return
     */
    public Object getValue(){
        return this;
    }
    
    /**
     * 
     * @return
     */
    public ByteCode getOP(){
        return op;
    }
    
    /**
     * 
     * @return
     */
    public int getByteCode(){
        return byteCode;
    }
    
    /**
     * 
     * @return
     */
    public int getByteIndex(){
        return byteIndex;
    }
    
    public OperationType getOperationType() {
        return operationType;
    }
    
    /**
     *
     * @return
     */
    public boolean isPushType(){
        if (op.getType() == PushType.NONE){
            return false;
        }else{
            return true;
        }
    }
    
    public String getPushType(){
        return null;
    }

    /**
     * 
     * @return
     */
    public int getStartPc(){
        if(op.getParamByteNum() >= 0){
            return this.getByteIndex()+ op.getParamByteNum() + 1;
        }else{
            throw new UnsupportedTypeException("paramByteNum not supported");
        }
    }
    
    //TODO what about remove this method.
    public void reset(){
        
    }
    
    //TODO work around here 
    public void analyze(Block block){
        mergeStack(context.getOperandStack() ,block.getLocalVariableTable());
    }
    
    public String toText(){
        if(expr != null){
            return expr.toText();
        }else{
            //return null or empty?
            return null;
        }
    }
    
    //TODO
    public boolean isVisibleText(){
        return op.isVisible();
    }

    
    @Override
    public String toString() {
        return String
                .format(
                        "[%s:byteCode=%d,byteIndex=%d]",
                        this.getClass().getSimpleName(),
                        byteCode,byteIndex);
    }
}
