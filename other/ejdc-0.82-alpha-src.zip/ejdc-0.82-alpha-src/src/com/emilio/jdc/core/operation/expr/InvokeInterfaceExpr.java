package com.emilio.jdc.core.operation.expr;

import java.util.List;

import com.emilio.jdc.core.type.Value;


public class InvokeInterfaceExpr extends AbstractInvokeInstanceExpr{
    
    public static InvokeInterfaceExpr of(Value refObj, String methodName, List<? extends Value> arguments){
        return new InvokeInterfaceExpr(refObj, methodName, arguments);
    }

    private InvokeInterfaceExpr(Value refObj, String methodName, List<? extends Value> arguments){
        this.methodName = methodName;
        this.arguments = arguments;
        this.refObj = refObj;
    }
    
}
