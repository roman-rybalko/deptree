package com.emilio.jdc.core.type;

import java.util.EnumMap;

import com.emilio.jdc.core.opcode.ByteCode;

/**
 * 
 * @author Emilio Liang
 *
 */
public enum ConditionType implements Symbol{

//    IFEQ("=="),
//    IFNE("!="),
//    IFLE("<="),
//    IFLT("<"),
//    IFGE(">="),
//    IFGT(">"),
//    IF_ICMP_EQ("=="),
//    IF_ICMP_NE("!="),
//    IF_ICMP_LE("<="),
//    IF_ICMP_LT("<"),
//    IF_ICMP_GE(">="),
//    IF_ICMP_GT(">"),
//    IF_ACMP_EQ("=="),
//    IF_ACMP_NE("!="),
//    IFNULL("=="),
//    IFNONNULL("!=");
    
    EQ("=="),
    NE("!="),
    LE("<="),
    LT("<"),
    GE(">="),
    GT(">");
    
    private static EnumMap<ByteCode, ConditionType> typeMapping = new EnumMap<ByteCode, ConditionType>(ByteCode.class);
    private static EnumMap<ConditionType, ConditionType> reverseMapping = new EnumMap<ConditionType, ConditionType>(ConditionType.class);
    private static EnumMap<ConditionType, ConditionType> negMapping = new EnumMap<ConditionType, ConditionType>(ConditionType.class);

    
    static {
        //map if byte code to condition
        typeMapping.put(ByteCode.IFEQ, EQ);
        typeMapping.put(ByteCode.IF_ICMPEQ, EQ);
        typeMapping.put(ByteCode.IF_ACMPEQ, EQ);
        typeMapping.put(ByteCode.IFNULL, EQ);
        typeMapping.put(ByteCode.IFNE, NE);
        typeMapping.put(ByteCode.IF_ICMPNE, NE);
        typeMapping.put(ByteCode.IF_ACMPNE, NE);
        typeMapping.put(ByteCode.IFNONNULL, NE);
        typeMapping.put(ByteCode.IFLE, LE);
        typeMapping.put(ByteCode.IF_ICMPLE, LE);
        typeMapping.put(ByteCode.IFLT, LT);
        typeMapping.put(ByteCode.IF_ICMPLT, LT);
        typeMapping.put(ByteCode.IFGE, GE);
        typeMapping.put(ByteCode.IF_ICMPGE, GE);
        typeMapping.put(ByteCode.IFGE, GT);
        typeMapping.put(ByteCode.IF_ICMPGE, GT);

        //map condition to reverse condition
        reverseMapping.put(NE, EQ);
        reverseMapping.put(EQ, NE);
        reverseMapping.put(GE, LT);
        reverseMapping.put(LT, GE);
        reverseMapping.put(LE, GT);
        reverseMapping.put(GT, LE);

        //map condition to neg condition
        negMapping.put(NE, NE);
        negMapping.put(EQ, EQ);
        negMapping.put(GE, LE);
        negMapping.put(GT, LT);
        negMapping.put(LE, GE);
        negMapping.put(GT, LT);
    }

    /**
     * 
     */
    private final String operationMark;
//    private final ConditionType reverseType;
//    private final ConditionType negType;

    /**
     * 
     * @param operationMark
     */
    private ConditionType(String operationMark){
        this.operationMark = operationMark;
    }
    
    /**
     * 
     * @param byteCode
     * @return
     */
    public static ConditionType fromByte(ByteCode byteCode){
        return typeMapping.get(byteCode);
    }
    
    /**
     * 
     * @param type
     * @return
     */
    public static ConditionType getReverseType(ConditionType type){
        return reverseMapping.get(type);
    }
    
    /**
     * 
     * @param type
     * @return
     */
    public static ConditionType getNegType(ConditionType type){
        return negMapping.get(type);
    }
    
    public String toSymbol(){
        return operationMark;
    }
}
