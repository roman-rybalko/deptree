package com.emilio.jdc.core.operation.expr;

import com.emilio.jdc.core.type.OperatorsType;
import com.emilio.jdc.core.type.Value;

/**
 * 
 * @author Emilio Liang
 *
 */
public class NumBinaryOpExpr implements BinaryOpExpr {
    private Value val1;
    private Value val2;
    private OperatorsType type;
    
    private NumBinaryOpExpr(Value val1, Value val2,OperatorsType type){
        this.val1 = val1;
        this.val2 = val2;
    } 
    
    /**
     * 
     * @param val1
     * @param val2
     * @return
     */
    public static BinaryOpExpr getInstance(Value val1, Value val2,OperatorsType type){
        return new NumBinaryOpExpr(val1,val2,type);
    }

    public Value getOp1() {
        return val1;
    }

    public Value getOp2() {
        return val2;
    }

    public String getOperatorSymbol() {
        return type.toString();
    }

    public void setOp1(Value op1) {
        this.val1 = op1;
    }

    public void setOp2(Value op2) {
        this.val2 = op2;
    }

    public String toText() {
        return null;
    }

}
