package com.emilio.jdc.core.util;

import java.util.Arrays;
import java.util.List;

/**
 * 
 * @author Emilio Liang
 * 
 * 
 *
 */
public class StringFormatUtil {
    private static final String TAB = "    ";
    
    public static <E> String toString(E[] list,int level){
        return toString(Arrays.asList(list),level);
    }
    
    public static <E> String toString(E[] list){
        return toString(list,0);
    }

    /**
     * toString
     * @param <E>
     * @param list
     * @param level
     * @return
     */
    public static <E> String toString(List<E> list, int level){
        StringBuilder content = new StringBuilder();
        if(list == null){
            return content.append("null").toString();
        }
        for(int i = 0 ;i <list.size() ;i++){
            //if(i != list.size() -1){
                content.append(String.format("%n"));
            //}
            for(int j = 0;j < level; j++){
                content.append(TAB);
            }
            content.append(list.get(i));
        }
        return content.toString();
    }
    
    /**
     * toString
     * @param code
     * @return
     */
    public static String toString(byte[] code){
        StringBuilder content = new StringBuilder();
        
        for(byte b : code){
            content.append(Integer.toHexString(b));
            content.append(String.format("%n"));
        }
        return content.toString();
    }
    
    public static String toString(int[] code){
        StringBuilder content = new StringBuilder();
        
        for(int b : code){
            content.append(Integer.toHexString(b));
            content.append(String.format("%n"));
        }
        return content.toString();
    }


}
