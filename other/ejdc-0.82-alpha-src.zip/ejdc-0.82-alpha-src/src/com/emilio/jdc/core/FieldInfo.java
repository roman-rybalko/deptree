package com.emilio.jdc.core;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.operation.expr.ListExpression;
import com.emilio.jdc.core.util.ClassInputStream;
import com.emilio.jdc.core.util.StringFormatUtil;

/**
 * 
 * @author Emilio Liang
 *
 */
public final class FieldInfo implements LoadableInfo, ResolvableInfo, ListExpression {
    private int fieldCount;
    private List<FieldInfoItem> fieldInfoList = new ArrayList<FieldInfoItem>();

    /**
     * Constructor
     */
    public FieldInfo() {

    }

    public void load(ClassInputStream cis) throws IOException {
        fieldCount = cis.readU2();

        if (fieldCount > 0) {
            for (int i = 0; i < fieldCount; i++) {
                FieldInfoItem field = new FieldInfoItem();
                field.load(cis);
                fieldInfoList.add(field);
            }
        }
    }

    public void resolve(Class clazz) throws IOException {
        if (fieldCount > 0) {
            for (FieldInfoItem fieldItem : fieldInfoList) {
                fieldItem.resolve(clazz);
            }
        }
    }
    
    /**
     * 
     */
    public List<Expression> listExpressions(){
        //TODO
        List<Expression> list = new ArrayList<Expression>();
        for(FieldInfoItem item:fieldInfoList){
            list.add(item);
        }
        
        return list;
    }
    
    public void print(PrintWriter  pw){
        if (fieldCount > 0) {
            for(FieldInfoItem item : fieldInfoList){
                item.print(pw);
                pw.println();
            }
        }
    }
    
    public String toText(){
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        print(pw);
        return sw.toString();
    }

	public List<FieldInfoItem> getList(){
		return Collections.unmodifiableList(fieldInfoList);
	}
	
    @Override
    public String toString() {
        return String.format("[%s:fieldCount=%d,fieldInfoItem:%s]",
                this.getClass().getSimpleName(),
                fieldCount,
                StringFormatUtil.toString(fieldInfoList,1));
    }

}
