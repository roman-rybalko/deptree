package com.emilio.jdc.core.operation;

import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.constant.Constant;
import com.emilio.jdc.core.util.OperandStack;

/**
 * 
 * @author Emilio Liang
 *
 */
public class Ldc extends Operation {
    private int index;
    private Constant constant;

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }
    
    /**
     * 
     * @param byteCode
     * @param byteIndex
     * @param code
     */
    public Ldc(int byteCode, int byteIndex, MethodContext context) {
        super(byteCode, byteIndex, context);
    }

    @Override
    public void parseParams() {
        switch (getOP()) {
        case LDC:
            index = parameters[ZERO];
            constant = context.getConstantPoolInfo().getContantPoolItem(index);
            break;
        case LDC_W:
        case LDC2_W:
            index = mergeUnsignedBytes(parameters[ZERO],parameters[ONE]);
            constant = context.getConstantPoolInfo().getContantPoolItem(index);
        }
    }
    
    /**
     * @param
     */
    public void mergeStack(OperandStack<Operation> stack, LocalVariableTable table){
        stack.push(this); 
    }
    
    @Override
    public Object getValue(){
        return constant.getValue();
    }
    
    @Override
    public String toString(){
        return String.format(
                "[%s:byteCode=%d,index=%d,constClass=%s]", this
                        .getClass().getSimpleName(),byteCode,index,constant);
    }
}
