package com.emilio.jdc.decompile.finder;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import com.emilio.jdc.core.operation.OperationType;
import com.emilio.jdc.core.operation.Switch;
import com.emilio.jdc.core.operation.Switch.CaseBranch;
import com.emilio.jdc.decompile.structure.Block;
import com.emilio.jdc.decompile.structure.CaseBlock;
import com.emilio.jdc.decompile.structure.CodeStruct;
import com.emilio.jdc.decompile.structure.SwitchBlock;

/**
 * 
 * @author Emilio Liang
 *
 */
public class SwitchFinder implements BlockFinder{
    public void analyze(Block block){
        //TODO why return
        if (block instanceof SwitchBlock){
            return;
        }
        //TODO
        //block.reset();
        
        List<CodeStruct> list = block.getOperations();
        
        for (int i = 0 ;i < list.size() ;i++){
            CodeStruct op = list.get(i);
            
            if (op.getOperationType().equals(OperationType.SWITCH)){
                SwitchBlock switchBlock = new SwitchBlock(block);
                detectCaseBlocks((Switch)op, switchBlock, block);
                //TODO
                
                //TODO needs test replace
                list.remove(i);
                list.add(i, switchBlock);
                //block.replaceCurrentOperation(switchBlock);
            }
        }
    }

    /**
     * 
     * @param swit
     * @param switchBlock
     * @param block
     */
    private void detectCaseBlocks(Switch swit, SwitchBlock switchBlock, Block block){
        
        List<CaseBranch> cases = swit.getCaseBranches();
        
        sortList(cases);

        //Get first offset
//        long prev_offset = cases.get(0).getOffset();
//        for (int i = 1; i < cases.size(); i++){
//            Switch.CaseBranch nextCase = cases.get(i);
//            //Block caseBlock = new Block(block, block.createSubBlock(prev_offset, nextCase.getOffset(), null));
//            //switchBlock.addCaseBlock((Switch.Case) cases.get(i - 1), caseBlock);
//            prev_offset = nextCase.getOffset();
//        }

        for (int i = 0,j = 1; i < cases.size() - 1; i++,j++){
            Switch.CaseBranch beginCase = cases.get(i);
            Switch.CaseBranch endCase = cases.get(j);
            System.out.println(beginCase.getOffset()+"-----"+endCase.getOffset());
            
            //TODO two line
//            Block caseBlock = new CodeBlock(block.createSubBlock(beginCase.getOffset(), endCase.getOffset(), null),block);
//            switchBlock.addCaseBlock(cases.get(i - 1), caseBlock);
        }
        
        
        // Trying to find at least one case block with last GoTo operation
        long exitGoto = 0;
        Iterator<CaseBlock> it = switchBlock.getCaseBlocks().iterator();
        
        while (it.hasNext()){
            exitGoto = ((CaseBlock) it.next()).getLastGotoOffset();
            if (exitGoto != 0) break;
        }
        // If found creating block for last case block
        if (exitGoto != 0){
            //TODO two line
            //Block caseBlock = new Block(block, block.createSubBlock(prev_offset, exitGoto, null));
            //switchBlock.addCaseBlock(cases.get(cases.size() - 1), caseBlock);
        }
        else    // Last (usually default) block is print outside switch, so no need to create subblock
        {
            // do nothing
        }
    }
    
    /**
     * 
     * @param list
     */
    private void sortList(List<CaseBranch> list){
        Collections.sort(list, new Comparator<CaseBranch>()
                {
                    public int compare(CaseBranch o1, CaseBranch o2)
                    {
                        return (int) ((o1).getOffset() - (o2).getOffset());
                    }
                });
    }
}
