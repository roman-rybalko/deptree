package com.emilio.jdc.decompile.structure;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.emilio.jdc.core.operation.FakeGoto;
import com.emilio.jdc.core.operation.Operation;
import com.emilio.jdc.core.operation.OperationType;

public class IfBlock extends CodeBlock {

    // TODO Why duplicated with andConditions in loop
    private List<List<IfCondition>> andConditions = new ArrayList<List<IfCondition>>();

    private Else elseBlock;

    private boolean isNegConditions = false;

    public IfBlock(Block parent) {
        super(parent);
    }

    public void setElseBlock(Else elseBlock) {
        this.elseBlock = elseBlock;
        // Remove last goto
        if (getLastOperation().getOperationType() == OperationType.GOTO) {
            removeLastOperation();
        }
    }

    public Else getElseBlock() {
        return elseBlock;
    }

    private boolean isElseIf = false; // For printing only

    public void setElseIf(boolean elseIf) {
        isElseIf = elseIf;
    }

    public int getByteIndex() {
        if (andConditions != null && andConditions.size() > 0
                && ((List<IfCondition>) andConditions.get(0)).size() > 0) {
            IfCondition cond = ((List<IfCondition>) andConditions.get(0))
                    .get(0);
            return cond.getByteIndex();
        }
        return super.getByteIndex();
    }

    @Override
    public String toText() {
        StringBuilder text = new StringBuilder();

        // sb.append(indent);
        text.append(isElseIf ? "else " : "").append("if ");
        text.append(getSourceConditions());
        text.append(LINE_SEPARATOR);
        text.append(super.toText());
        return text.toString();
    }

    /**
     * @deprecated
     */
    public String getSourceConditions() {
        /*
         * StringBuffer sb = new StringBuffer(); if (isNegConditions)
         * sb.append("(!"); if (andConditions.size() > 1) sb.append("("); for
         * (Iterator i = andConditions.iterator(); i.hasNext();) { List
         * orConditions = (List) i.next(); if (orConditions.size() > 1)
         * sb.append("("); for (Iterator j = orConditions.iterator();
         * j.hasNext();) { Condition cond = (Condition) j.next(); if
         * (j.hasNext() && orConditions.size() > 1)
         * cond.setNeedReverseOperation(false); sb.append("(" + cond.str() +
         * ")"); if (j.hasNext()) sb.append(" || "); } if (orConditions.size() >
         * 1) sb.append(")"); if (i.hasNext()) sb.append(" && "); } if
         * (andConditions.size() > 1) sb.append(")"); if (isNegConditions)
         * sb.append(")"); return sb.toString();
         */
        StringBuffer sb = new StringBuffer();
        Iterator<String> i = getSourceConditionsView().iterator();
        while (i.hasNext()) {
            Object obj = i.next();
            if (obj instanceof String) {
                sb.append((String) obj);
            } else {
                // TODO
                sb.append(((Operation) obj).toText());
            }
        }
        return sb.toString();
    }

    // public List<String> getSourceConditionsView()
    // {
    // List<String> src = new ArrayList<String>();
    // if (isNegConditions){
    // src.add("(!");
    // }
    //
    // if (andConditions.size() > 1) {
    // src.add("(");
    // }
    //
    // for (List<IfCondition> orConditions : andConditions){
    // //List orConditions = (List) i.next();
    // if (orConditions.size() > 1) src.add("(");
    // for (IfCondition condition : orConditions){
    // //IfCondition cond = (IfCondition) j.next();
    // if (condition.hasNext() && orConditions.size() > 1) {
    // condition.setNeedReverse(false);
    // }
    //
    // src.add("(");
    // //TODO test
    // //src.addAll(cond.getView());
    // src.add(condition.toText());
    // src.add(")");
    // if (condition.hasNext()) {
    // src.add(" || ");
    // }
    // }
    // if (orConditions.size() > 1) {
    // src.add(")");
    // }
    //
    // if (andConditions.hasNext()) {
    // src.add(" && ");
    // }
    // }
    // if (andConditions.size() > 1){
    // src.add(")");
    // }
    //
    // if (isNegConditions) {
    // src.add(")");
    // }
    //
    // return src;
    // }

    public List<String> getSourceConditionsView() {
        List<String> src = new ArrayList<String>();
        if (isNegConditions) {
            src.add("(!");
        }

        if (andConditions.size() > 1) {
            src.add("(");
        }

        for (Iterator<List<IfCondition>> i = andConditions.iterator(); i
                .hasNext();) {
            List<IfCondition> orConditions = i.next();
            if (orConditions.size() > 1)
                src.add("(");
            for (Iterator<IfCondition> j = orConditions.iterator(); j.hasNext();) {
                IfCondition cond = j.next();
                if (j.hasNext() && orConditions.size() > 1)
                    cond.setNeedReverse(false);
                src.add("(");
                // TODO
                src.add(cond.toText());
                src.add(")");
                if (j.hasNext())
                    src.add(" || ");
            }
            if (orConditions.size() > 1)
                src.add(")");
            if (i.hasNext())
                src.add(" && ");
        }
        if (andConditions.size() > 1)
            src.add(")");
        if (isNegConditions)
            src.add(")");

        return src;
    }

    public void addAndConditions(List<CodeStruct> ops) {
        List<IfCondition> orConditions = new ArrayList<IfCondition>();
        List<CodeStruct> newOps = new ArrayList<CodeStruct>();

        for (CodeStruct struct : ops) {
            newOps.add(struct);
            if (struct.getOperationType() == OperationType.IF) {
                orConditions.add(new IfCondition(struct, this,
                        new ArrayList<CodeStruct>(newOps)));
                newOps.clear();
            }
        }

        andConditions.add(orConditions);
    }

    public void analyze(Block block) {
        for (Iterator<List<IfCondition>> i = andConditions.iterator(); i
                .hasNext();) {
            List<IfCondition> orConditions = i.next();
            for (Iterator<IfCondition> j = orConditions.iterator(); j.hasNext();) {
                IfCondition cond = (IfCondition) j.next();
                cond.analyze(block);
            }
        }

        // Can be break in back loop
        List<IfCondition> firstOrConditions = andConditions.get(0);
        int target = ((IfCondition) firstOrConditions.get(firstOrConditions
                .size() - 1)).getIfOperation().getTargetIndex();
        int start = ((IfCondition) firstOrConditions.get(firstOrConditions
                .size() - 1)).getIfOperation().getByteIndex();
        if (block.getLastOperation().getByteIndex() < target
                && block instanceof Loop) {
            Block par = block;
            do {
                par = par.getParent();
                if (par == null)
                    break;
            } while (par.getOperationByStartByte(target) == null);

            if (par != null
                    && (CodeStruct) par.getOperationBefore(target) instanceof Loop) {
                FakeGoto got = new FakeGoto(start, target);
                got.setBreak(true);
                // TODO
                // ops.add(ops.size(), got);
                addOperation(this.getOperations().size(), got);
                isNegConditions = true;
            }
        }
    }

    private int stackSizeChange;
    private boolean isPushShortForm = false;

    public void preAnalyze(Block block) {
        stackSizeChange = getMethodContext().size();
    }

    public void postAnalyze(Block block) {
        stackSizeChange = getMethodContext().size() - stackSizeChange;
        isPushShortForm = stackSizeChange == 1;
    }

    public boolean isIsPushShortForm() {
        return isPushShortForm;
    }

    @Override
    public String toString() {
        return String.format("[%s:]", this.getClass().getSimpleName());
    }
}
