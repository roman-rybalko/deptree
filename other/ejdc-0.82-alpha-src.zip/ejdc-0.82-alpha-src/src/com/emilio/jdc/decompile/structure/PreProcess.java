package com.emilio.jdc.decompile.structure;

public interface PreProcess {
    public void preAnalyze(Block block);
}
