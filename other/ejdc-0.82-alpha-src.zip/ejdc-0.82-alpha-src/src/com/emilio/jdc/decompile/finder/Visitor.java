package com.emilio.jdc.decompile.finder;

import com.emilio.jdc.core.attribute.ExceptionTable;
import com.emilio.jdc.decompile.structure.Block;

public interface Visitor {
    public void visitBackLoop(Block block);
    public void visitEndlessBackLoop(Block block);
    public void visitLoop(Block block);
    public void visitTryCatch(Block block,ExceptionTable table);
    public void visitSwitch(Block block);
    public void visitIf(Block block);
}
