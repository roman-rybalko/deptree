package com.emilio.jdc.decompile.structure;

public interface PostProcess {
    public void postAnalyze(Block block);
}
