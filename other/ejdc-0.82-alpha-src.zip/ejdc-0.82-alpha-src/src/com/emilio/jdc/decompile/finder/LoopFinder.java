package com.emilio.jdc.decompile.finder;

import java.util.List;

import com.emilio.jdc.core.operation.Goto;
import com.emilio.jdc.core.operation.If;
import com.emilio.jdc.core.operation.OperationType;
import com.emilio.jdc.decompile.structure.Block;
import com.emilio.jdc.decompile.structure.CodeStruct;
import com.emilio.jdc.decompile.structure.Loop;

/**
 * 
 * @author Emilio Liang
 *
 */
public class LoopFinder implements BlockFinder{
    
    public void analyze(Block block){
        
        //Iterator<CodeStruct> it = block.iterator();
        
        //TODO
        //block.reset();
        for (CodeStruct  op: block.getOperations()){
            if (!(op.getOperationType().equals(OperationType.IF))) {
                continue;
            }
            
            If ifOp = (If) op;

            CodeStruct priorTarget = block.getOperationBefore(ifOp.getTargetIndex());

            if (priorTarget != null && priorTarget.getOperationType() == OperationType.IF ){
                priorTarget = block.getOperationBefore(((If) priorTarget).getTargetIndex());
            }

            // Inner loop
            if (priorTarget == null) priorTarget = block.getLastOperation();   // TODO better detection of target operation

            if ((priorTarget == null) || (!(priorTarget.getOperationType() == OperationType.GOTO))){
                continue;
            }

            Goto priorTargetGoTo = (Goto) priorTarget;

            if (!priorTargetGoTo.isForward() && (priorTargetGoTo.getTargetIndex() <= ifOp.getByteIndex()) && (priorTargetGoTo.getLoop() != null || !isIfContinue(block, priorTargetGoTo))){
                createForwardLoop(block, ifOp);
                continue;
            }
        }
    }

    private boolean isIfContinue(Block block, Goto priorTarget){
        // priorTarget - backward goto, but this is not loop
        // Case: if - continue for while (...) {...} block
        Block loop = block;
        while (loop != null)
        {
            if ((loop instanceof Loop) && (((Loop) loop).getBeginPc() == priorTarget.getTargetIndex()))
            {
                // This is "if - continue" case
                return true;
            }
            loop = loop.getParent();
        }

        return false;
    }

    private boolean isCompoundForwardLoop(Block block, If ifCond){
        if (ifCond.getTargetIndex() <= block.getLastOperation().getByteIndex()){
            return false;
        }
        
        if (!(block instanceof Loop)){
            return false;
        }

        CodeStruct next = block.getParent().getOperationAfter(block.getByteIndex());
        return next != null && next.getByteIndex() == ifCond.getTargetIndex();
    }

    private void createForwardLoop(Block block, If firstIf){
        CodeStruct firstPriorOp = block.getOperationBefore(firstIf.getTargetIndex());
        If ifOp = firstPriorOp.getOperationType() == OperationType.IF? (If) firstPriorOp : firstIf;

        if (isCompoundForwardLoop(block, ifOp)){
            //TODO add one
            List<CodeStruct> conditions = block.createSubBlock(0, ifOp.getByteIndex() + 1, null);
            ((Loop) block).addAndConditions(conditions);
            return;
        }

        if (firstPriorOp.getOperationType() == OperationType.GOTO && block.getOperationByStartByte(((Goto) firstPriorOp).getTargetIndex()) == null){ 
            return;
        }

        Loop loop = new Loop(block, false);
        block.createSubBlock(ifOp.getByteIndex() + 1, ifOp.getTargetIndex(), loop);
        //List firstConditions = block.createSubBlock(firstIf.getStartByte(), ifCond.getStartByte() + 1, null);
        //TODO add one
        List<CodeStruct> firstConditions = block.createSubBlock(loop.getBeginPc(), ifOp.getByteIndex() + 1, null);
        loop.addAndConditions(firstConditions);
    }
}
