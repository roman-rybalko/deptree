package com.emilio.jdc.decompile.structure;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.emilio.jdc.core.operation.If;

public class IfCondition extends CodeBlock {
    // private ConditionType conditionType;
    private boolean needReverse = true;
    // private boolean isVar1Boolean;
    private If op;

    // private Loop loop;
    // private List<Operation> conditions;

    public IfCondition(CodeStruct op, Block parent, List<CodeStruct> ops) {
        // TODO
        super(ops != null ? ops : Collections.<CodeStruct> emptyList(), parent);
        this.op = (If) op;
        // this.loop = loop;
    }

    public boolean isNeedReverse() {
        return needReverse;
    }

    public void setNeedReverse(boolean needReverse) {
        this.needReverse = needReverse;
    }

    public If getIfOperation() {
        return op;
    }

    public void analyze(Block block) {
        // TODO still need reset?
        // reset();

        op.analyze(block);

        Iterator<CodeStruct> it = iterator();

        while (it.hasNext()) {
            CodeStruct citem = it.next();
            if (it.hasNext()) {
                citem.analyze(this); // Don't analyze last If
            }
        }

        analyzeIf(block);
    }

    private void analyzeIf(Block block) {

    }

    @Override
    public String toText() {
        System.out.println("needReverse-----" + needReverse);
        if (op.getExpression() != null) {
            return op.getExpression().toText();
        } else {
            return "null";
        }
    }

    // public List<String> getView() {
    // List<String> src = new ArrayList<String>();
    // if (isVar1Boolean && "0".equals(var2str)) {
    // String oper = needReverse ? (String) reversedOps.get(operation) :
    // operation;
    // if ("==".equals(oper)) {
    // src.add("!");
    // src.add(var1);
    // return src;
    // } else if ("!=".equals(oper)) {
    // src.add(var1);
    // return src;
    // }
    // }
    // if ("".equals(var2str)) {
    // if (var2 instanceof PopView) {
    // src.add("(");
    // src.add(var2);
    // src.add(")");
    // } else {
    // src.add(var2);
    // }
    // } else {
    // src.add(var2str);
    // }
    // src.add(" ");
    // if (needReverse) {
    // src.add(reversedOps.get(operation));
    // } else {
    // src.add(operation);
    // }
    // src.add(" ");
    // src.add(var1);
    // return src;
    // }

    @Override
    public String toString() {
        return String.format("[%s:]", this.getClass().getSimpleName());
    }
}
