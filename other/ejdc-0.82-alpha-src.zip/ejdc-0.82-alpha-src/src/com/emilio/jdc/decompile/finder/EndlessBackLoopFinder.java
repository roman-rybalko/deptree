package com.emilio.jdc.decompile.finder;

import java.util.Iterator;

import com.emilio.jdc.core.operation.Goto;
import com.emilio.jdc.core.operation.OperationType;
import com.emilio.jdc.decompile.structure.Block;
import com.emilio.jdc.decompile.structure.Catch;
import com.emilio.jdc.decompile.structure.CodeStruct;
import com.emilio.jdc.decompile.structure.Loop;

/**
 * 
 * @author Emilio Liang
 *
 */
public class EndlessBackLoopFinder implements BlockFinder{

    /**
     * @param block
     */
    public void analyze(Block block){
        //block.reset();
        
        Iterator<CodeStruct> it = block.iterator();
        
        while (it.hasNext()){
            CodeStruct citem = it.next();
            if (!(citem.getOperationType() ==  OperationType.GOTO)) continue;

            Goto gt = (Goto) citem;
            if (gt.isBreak() || gt.isContinue() || gt.getLoop() != null) continue;
            if (!gt.isForward()){
                //if (isLastGoToWithSameTarget(block, gt))
                if (!isIfContinue(block, gt)){
                    createBackLoop(block, gt);
                }else{
                    gt.setContinue(true);
                }
            }
        }
    }

//    private boolean isLastGoToWithSameTarget(Block block, Goto gt)
//    {
//        List<CodeStruct> ops = block.getOperations();
//        for (CodeStruct op:ops){
//            if (!(op.getOperationType() == OperationType.GOTO) || op.getByteIndex() <= gt.getByteIndex()) continue;
//            Goto gt2 = (Goto) op;
//            if (gt2.getTargetIndex() == gt.getTargetIndex()){
//                return false;
//            }
//        }
//        if (block.getParent() == null) return true;
//        return isLastGoToWithSameTarget(block.getParent(), gt);
//    }

    private boolean isIfContinue(Block block, Goto priorTarget){
        // priorTarget - backward goto, but this is not loop
        // Case: if - continue for while (...) {...} block
        Block loop = block;
        while (loop != null){
            if ((loop instanceof Loop) && (((Loop) loop).getBeginPc() == priorTarget.getTargetIndex())){
                // This is "if - continue" case
                return true;
            }
            loop = loop.getParent();
        }

        return false;
    }

    /**
     * 
     * @param block
     * @param gotoView
     */
    private void createBackLoop(Block block, Goto gotoView){
        // Searching for outermost block for loop
        Block parent = block;
        Block foundBlock;
        CodeStruct target;
        do{
            target = parent.getOperationByStartByte(gotoView.getTargetIndex());
            foundBlock = parent;
            parent = parent.getParent();
        }
        while (target == null && parent != null);

        if (parent == null && target == null)
        {
            if (block instanceof Catch)
            {
                foundBlock = block.getParent();
            }
            else
            {
                foundBlock = block;
            }
        }

        Loop loop = new Loop(foundBlock, false);
        foundBlock.createSubBlock(gotoView.getTargetIndex(), gotoView.getByteIndex(), loop);
        loop.setAlwaysTrueCondition(true);
        block.removeOperation(gotoView.getByteIndex());
    }
}
