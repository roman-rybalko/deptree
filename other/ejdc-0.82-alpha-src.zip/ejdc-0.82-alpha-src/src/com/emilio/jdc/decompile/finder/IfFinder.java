package com.emilio.jdc.decompile.finder;

import java.util.List;

import com.emilio.jdc.core.operation.Goto;
import com.emilio.jdc.core.operation.If;
import com.emilio.jdc.core.operation.OperationType;
import com.emilio.jdc.decompile.structure.Block;
import com.emilio.jdc.decompile.structure.CodeStruct;
import com.emilio.jdc.decompile.structure.Else;
import com.emilio.jdc.decompile.structure.IfBlock;
import com.emilio.jdc.decompile.structure.Loop;
import com.emilio.jdc.decompile.structure.SwitchBlock;

/**
 * 
 * @author Emilio Liang
 *
 */
public class IfFinder implements BlockFinder{

    public void analyze(Block block){
        //TODO
        //block.reset();
       
        //Iterator<CodeStruct> it = block.iterator();
        
        for (CodeStruct struct : block.getOperations())
        {
            //CodeStruct citem = it.next();
            if (!(struct.getOperationType() == OperationType.IF)) continue;
            If ifOp = (If) struct;

            if (!ifOp.isForward()) continue;

            CodeStruct priorTarget = block.getOperationBefore(ifOp.getTargetIndex());
            CodeStruct firstPriorTarget = priorTarget;

            //find the last if target
            if (priorTarget != null && priorTarget.getOperationType() ==  OperationType.IF)
            {
                priorTarget = block.getOperationBefore(((If) priorTarget).getTargetIndex());
            }
            
            //find the goto before else
            if ((priorTarget == null) || (!(priorTarget.getOperationType() == OperationType.GOTO))){
                createIf(block, ifOp, firstPriorTarget);
                continue;
            }

            Goto priorTargetGoTo = (Goto) priorTarget;

            if (priorTargetGoTo.isForward())
            {
                createIf(block, ifOp, firstPriorTarget);
                continue;
            }
            else if (isIfContinue(block, priorTargetGoTo))
            {
                createIfContinue(block, ifOp, firstPriorTarget);
                continue;
            }
        }
    }

    /**
     * 
     * @param block
     * @param firstIf
     * @param firstPriorTarget
     */
    private void createIf(Block block, If firstIf, CodeStruct firstPriorTarget){
        
        If ifCond = firstPriorTarget.getOperationType() ==  OperationType.IF ? (If) firstPriorTarget : firstIf;
        CodeStruct priorOp = firstPriorTarget.getOperationType() ==  OperationType.IF  ? block.getOperationBefore(((If) firstPriorTarget).getTargetIndex()) : firstPriorTarget;

        if (isCompoundIf(block, ifCond)){
            List<CodeStruct> compoundConditions = block.createSubBlock(0, ifCond.getByteIndex() + 1, null);
            ((IfBlock) block).addAndConditions(compoundConditions);
            return;
        }

        IfBlock ifBlock = new IfBlock(block);
        block.createSubBlock(ifCond.getByteIndex() + 1, ifCond.getTargetIndex(), ifBlock);
        List<CodeStruct> firstConditions = block.createSubBlock(firstIf.getByteIndex(), ifCond.getByteIndex() + 1, null);
        ifBlock.addAndConditions(firstConditions);
        
        if (priorOp != null && priorOp.getOperationType() ==  OperationType.GOTO && ((Goto) priorOp).isForward()){
            detectElse(block, ifBlock, ifCond, (Goto) priorOp);
        }
    }

    private boolean isCompoundIf(Block block, If ifCond)
    {
        if (!(block instanceof IfBlock))
        {
            return false;
        }
        if (ifCond.getTargetIndex() <= block.getLastOperation().getByteIndex())
        {
            return false;
        }

        // If-continue case
        if (block.getLastOperation().getOperationType() ==  OperationType.GOTO && ((Goto) block.getLastOperation()).isContinue())
        {
            return true;
        }

        CodeStruct next = block.getParent().getOperationAfter(block.getByteIndex());
        return (next instanceof Else) && (next.getByteIndex() == ifCond.getTargetIndex());
    }

    private boolean isIfContinue(Block block, Goto priorTarget)
    {
        // priorTarget - backward goto, but this is not loop
        // Case: if - continue for while (...) {...} block
        Block loop = block;
        while (loop != null)
        {
            if ((loop instanceof Loop) && (((Loop) loop).getBeginPc() == priorTarget.getTargetIndex()))
            {
                // This is "if - continue" case
                return true;
            }
            loop = loop.getParent();
        }
        return false;
    }

    private void createIfContinue(Block block, If firstIf, CodeStruct firstPriorTarget){
        If ifCond = firstPriorTarget.getOperationType() == OperationType.IF ? (If) firstPriorTarget : firstIf;
        Goto priorTarget = (Goto) (firstPriorTarget.getOperationType() == OperationType.IF ? block.getOperationBefore(((If) firstPriorTarget).getTargetIndex()) : firstPriorTarget);

        if (isCompoundIf(block, ifCond))
        {
            List<CodeStruct> compoundConditions = block.createSubBlock(0, ifCond.getByteIndex() + 1, null);
            ((IfBlock) block).addAndConditions(compoundConditions);
            return;
        }

        priorTarget.setContinue(true);

        IfBlock ifBlock = new IfBlock(block);
        block.createSubBlock(ifCond.getByteIndex() + 1, ifCond.getTargetIndex(), ifBlock);
                                                                                                      
        List<CodeStruct> firstConditions = block.createSubBlock(firstIf.getByteIndex(), ifCond.getByteIndex() + 1, null);
        ifBlock.addAndConditions(firstConditions);
    }

    
    private void detectElse(Block block, IfBlock ifBlock, If ifCond, Goto ifPriorTarget)
    {
        // Generic Else block
        if (block.getLastOperation().getByteIndex() >= ifPriorTarget.getTargetIndex())
        {
            Else elseBlock = new Else(block);
            block.createSubBlock(ifCond.getTargetIndex(), ifPriorTarget.getTargetIndex(), elseBlock);
            ifBlock.setElseBlock(elseBlock);
            elseBlock.postCreate();
            return;
        }

        int ifPriorTarget_pc = ifPriorTarget.getTargetIndex();

        // Trying to find target operation
        Block ff_block = block;
        CodeStruct ff_oper;
        do
        {
            ff_oper = ff_block.getOperationByStartByte(ifPriorTarget_pc);
            if (ff_oper != null) break;
            ff_block = ff_block.getParent();
        }
        while (ff_block != null);
        if (ff_oper == null) return;

        CodeStruct prevFFOper = ff_block.getOperationBefore(ifPriorTarget_pc);
        if (prevFFOper instanceof Loop){
            ifPriorTarget.setBreak(true); // Set goto to break
            return;
        }
        else if (prevFFOper instanceof Else || prevFFOper instanceof IfBlock)   // Else block
        {
            Else elseBlock = new Else(block);
            block.createSubBlock(ifCond.getTargetIndex(), ifPriorTarget_pc, elseBlock);
            ifBlock.setElseBlock(elseBlock);
            elseBlock.postCreate();
            return;
        }
        else if (prevFFOper instanceof SwitchBlock)
        {
            Else elseBlock = new Else(block);
            block.createSubBlock(ifCond.getTargetIndex(), ifPriorTarget_pc, elseBlock);
            ifBlock.setElseBlock(elseBlock);
            elseBlock.postCreate();
            return;
        }

        if (ff_block instanceof Loop)    // this is continue in for loop
        {
            if (!((Loop) ff_block).isBackLoop())
            {
                ((Loop) ff_block).setIncrementalPartStartOperation(ff_oper.getByteIndex());
            }
            ifPriorTarget.setContinue(true);
            return;
        }

        // Add return in previous "if" if adding new "if" 
    }
}
