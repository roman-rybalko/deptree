package com.emilio.jdc.decompile.structure;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.emilio.jdc.core.operation.Goto;
import com.emilio.jdc.core.operation.Operation;
import com.emilio.jdc.core.operation.OperationType;

public class Loop extends CodeBlock {
    private List<List<IfCondition>> andConditions = new ArrayList<List<IfCondition>>();
    private boolean alwaysTrueCondition = false;

    private boolean printPrecondition; // WHILE(){} vs DO{}WHILE()
    private boolean isBackLoop; // If conditions at the end of block then true

    private int startPc;

    // For-style specific variables
    private boolean isInForStyle = false;
    private long incPartStartByte;

    public Loop(Block parent, boolean isBackLoop) {
        // TODO
        super(parent);
        this.isBackLoop = isBackLoop;
        this.printPrecondition = !isBackLoop;
    }

    public void setPrintPrecondition(boolean precondition) {
        this.printPrecondition = precondition;
    }

    public boolean isPrintPrecondition() {
        return printPrecondition;
    }

    public boolean isAlwaysTrueCondition() {
        return alwaysTrueCondition;
    }

    public void setAlwaysTrueCondition(boolean alwaysTrueCondition) {
        this.alwaysTrueCondition = alwaysTrueCondition;
    }

    public void postCreate() {
        // Remove last goto
        if (!isBackLoop
                && (getLastOperation().getOperationType() == OperationType.GOTO)) {
            // TODO bug for inner loops
            // GoToView lastGoto = (GoToView) removeLastOperation();
            Goto lastGoto = (Goto) getLastOperation();
            lastGoto.setLoop(this);
            startPc = lastGoto.getTargetIndex();
        } else {
            startPc = getFirstOperation().getByteIndex();
        }
    }

    public void addAndConditions(List<CodeStruct> ops) {
        List<IfCondition> orConditions = new ArrayList<IfCondition>();
        List<CodeStruct> newOps = new ArrayList<CodeStruct>();
        Iterator<CodeStruct> i = ops.iterator();
        while (i.hasNext()) {
            CodeStruct ci = i.next();
            newOps.add(ci);
            if (ci.getOperationType() == OperationType.IF) {
                IfCondition cond = new IfCondition(ci, this,
                        new ArrayList<CodeStruct>(newOps));
                // TODO ?
                cond.setNeedReverse(!isBackLoop);
                orConditions.add(cond);
                newOps.clear();
            }
        }
        andConditions.add(orConditions);
    }

    public void addAndConditions2(List<List<IfCondition>> conditions) {
        andConditions.addAll(conditions);
    }

    public List<List<IfCondition>> getConditions() {
        return andConditions;
    }

    public boolean isBackLoop() {
        return isBackLoop;
    }

    public void setIncrementalPartStartOperation(long incPartStartByte) {
        this.incPartStartByte = incPartStartByte;
        isInForStyle = true;
    }

    public int getBeginPc() {
        return startPc;
    }

    @Override
    public String toText() {
        StringBuilder text = new StringBuilder();
        if (isInForStyle) {
            // text.append(indent);
            text.append("for (; ");
            for (Iterator<List<IfCondition>> i = andConditions.iterator(); i
                    .hasNext();) {
                List<IfCondition> orConditions = i.next();
                if (orConditions.size() > 1) {
                    text.append("(");
                }
                for (Iterator<IfCondition> j = orConditions.iterator(); j
                        .hasNext();) {
                    IfCondition cond = j.next();
                    if (j.hasNext() && orConditions.size() > 1) {
                        cond.setNeedReverse(false);
                    }
                    // TODO
                    // text.append(cond.str());
                    text.append(cond.toText());

                    if (j.hasNext())
                        text.append(" || ");
                }
                if (orConditions.size() > 1) {
                    text.append(")");
                }
                if (i.hasNext())
                    text.append(" && ");
            }
            text.append(";");
            for (Iterator<CodeStruct> i = super.iterator(); i.hasNext();) {
                Operation citem = (Operation) i.next();
                if (citem.getByteIndex() >= incPartStartByte) {
                    // Suppose there are no Blocks
                    String opStr = citem.getExpression().toText();
                    if (opStr != null && !"".equals(opStr)) {
                        text.append(" " + opStr);
                    }
                }
            }
            text.append(")").append(LINE_SEPARATOR);

            // text.append(indent);
            text.append("{");
            text.append(LINE_SEPARATOR);

            // TODO
            // text.append(super.getOperationsSource((int) incPartStartByte));

            // text.append(indent);
            text.append("}");
            text.append(LINE_SEPARATOR);
            return text.toString();
        }
        if (!printPrecondition) {
            // text.append(indent);
            text.append("do").append(LINE_SEPARATOR);
            text.append(super.toText());
        }

        // text.append(indent)
        text.append("while ");
        if (alwaysTrueCondition) {
            text.append("(true)");
        } else {
            if (andConditions.size() > 1) {
                text.append("(");
            }
            for (Iterator<List<IfCondition>> i = andConditions.iterator(); i
                    .hasNext();) {
                List<IfCondition> orConditions = i.next();
                if (orConditions.size() > 1) {
                    text.append("(");
                }
                for (Iterator<IfCondition> j = orConditions.iterator(); j
                        .hasNext();) {
                    IfCondition cond = j.next();
                    if (j.hasNext() && orConditions.size() > 1)
                        cond.setNeedReverse(false);
                    // text.append("(" + cond.str() + ")");
                    // TODO ok ?
                    text.append("(");
                    text.append(cond.toText());
                    text.append(")");

                    if (j.hasNext())
                        text.append(isBackLoop ? " && " : " || ");
                }
                if (orConditions.size() > 1)
                    text.append(")");
                if (i.hasNext())
                    text.append(isBackLoop ? " || " : " && ");
            }
            if (andConditions.size() > 1)
                text.append(")");
            text.append(printPrecondition ? "" : ";");
        }
        text.append(LINE_SEPARATOR);

        if (printPrecondition) {
            text.append(super.toText());
        }
        return LINE_SEPARATOR.toString();
    }

    public void preAnalyze(Block block) {
        if (isBackLoop) {
            return;
        }

        // All other conditions are analyzed with themselves
        for (Iterator<List<IfCondition>> i = andConditions.iterator(); i
                .hasNext();) {
            List<IfCondition> orConditions = i.next();
            for (Iterator<IfCondition> j = orConditions.iterator(); j.hasNext();) {
                IfCondition cond = (IfCondition) j.next();
                cond.analyze(block);
            }
        }
    }

    public void postAnalyze(Block block) {
        if (!isBackLoop) {
            return;
        }

        // TODO how does this work?
        // this.seekEnd();

        // All other conditions are analyzed with themselves
        for (Iterator<List<IfCondition>> i = andConditions.iterator(); i
                .hasNext();) {
            List<IfCondition> orConditions = i.next();
            for (Iterator<IfCondition> j = orConditions.iterator(); j.hasNext();) {
                IfCondition cond = j.next();
                cond.analyze(this);
            }
        }
    }

    @Override
    public String toString() {
        return String.format("[%s:]", this.getClass().getSimpleName());
    }
}
