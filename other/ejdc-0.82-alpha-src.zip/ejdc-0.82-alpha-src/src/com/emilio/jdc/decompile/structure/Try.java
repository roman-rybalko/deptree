package com.emilio.jdc.decompile.structure;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.emilio.jdc.core.attribute.ExceptionTableEntry;
import com.emilio.jdc.core.operation.Goto;
import com.emilio.jdc.core.operation.OperationType;

public class Try extends CodeBlock {
    private List<Catch> catchBlocks = new ArrayList<Catch>();
    private List<ExceptionTableEntry> finallyExceptions = new ArrayList<ExceptionTableEntry>();
    private List<int[]> suspiciousFinallies = null;
    private int goto_cmd = -1;
    private int startPc;
    private int endPc;

    public Try(int startPc, int endPc, Block parent) {
        super(parent);
        this.startPc = startPc;
        this.endPc = endPc;
    }

    public void setSuspiciousFinallies(List<int[]> suspiciousFinallies) {
        this.suspiciousFinallies = suspiciousFinallies;
    }

    public void addCatchBlock(Catch _catch) {
        catchBlocks.add(_catch);
    }

    public List<Catch> getCatchBlocks() {
        return catchBlocks;
    }

    public void setFinallyException(List<ExceptionTableEntry> excTable) {
        finallyExceptions = excTable;
    }

    public int getStartPC() {
        return startPc;
    }

    public int getEndPC() {
        return endPc;
    }

    public int getRetrieveOperation() {
        return goto_cmd;
    }

    @Override
    public String toText() {
        // return indent + "try" + NL + super.getSource();
        return "try" + LINE_SEPARATOR + super.toText();

    }

    public void postCreate() {
        CodeStruct gop = getLastOperation();

        if (gop.getOperationType() == OperationType.GOTO
                && ((Goto) gop).isForward()) {
            goto_cmd = (int) ((Goto) gop).getTargetIndex();
        } else {
            goto_cmd = Integer.MAX_VALUE;
        }
    }

    public void removeSuspiciousInlinedFinallyBlocks() {
        // Checking inlined finally block in try block
        if (suspiciousFinallies != null && !suspiciousFinallies.isEmpty()) {
            for (Iterator<int[]> sif = suspiciousFinallies.iterator(); sif
                    .hasNext();) {
                int[] gap = sif.next();
                if (gap[0] > startPc && gap[1] < endPc) {
                    CodeStruct retItem = getOperationBefore(gap[1]);
                    if (retItem.getOperationType() == OperationType.RETURN) {
                        boolean isFinallyExists = false;
                        for (int k = 0; k < catchBlocks.size(); k++) {
                            if (((Catch) catchBlocks.get(k)).isFinally()) {
                                isFinallyExists = true;
                                break;
                            }
                        }
                        if (isFinallyExists) {
                            for (int f_byte = gap[0]; f_byte < retItem
                                    .getByteIndex(); f_byte++) {
                                removeOperation(f_byte);
                            }
                        }
                    }
                }
            }
        }
    }

    public void postProcess() {
        // Checking inlined finally block in try block
        // For jsr-ret constructions it also truncates jsr + goto operations
        if (endPc < getLastOperation().getByteIndex()) {
            truncate(startPc);
        }

        // Checking inlined finally block in catch blocks
        Iterator<ExceptionTableEntry> i = finallyExceptions.iterator();
        while (i.hasNext()) {
            ExceptionTableEntry et = i.next();

            for (Iterator<Catch> cit = catchBlocks.iterator(); cit.hasNext();) {
                Catch _catch = cit.next();

                if (et.getEndPc() > _catch.getFirstOperation().getByteIndex()
                        && et.getEndPc() < _catch.getLastOperation()
                                .getByteIndex()
                        && et.getHandlerPc() > _catch.getLastOperation()
                                .getByteIndex()) {
                    _catch.truncate(et.getEndPc());
                }
            }
        }

        // Checking last goto: break or continue
        if (getLastOperation().getOperationType() == OperationType.GOTO) {
            if (!checkLastGoTo((Goto) getLastOperation())) {
                removeLastOperation();
            }
        }
    }

    private boolean checkLastGoTo(Goto oper) {
        Block ff_block = this;
        CodeStruct ff_oper;
        do {
            ff_oper = ff_block.getOperationByStartByte(oper.getTargetIndex());
            if (ff_oper != null)
                break;
            ff_block = ff_block.getParent();
        } while (ff_block != null);
        if (ff_oper == null) {
            return false;
        }

        CodeStruct prevFF = ff_block.getOperationBefore(ff_oper.getByteIndex());
        if (prevFF instanceof Loop) {
            oper.setBreak(true);
            return true;
        }
        if (ff_block instanceof Loop) {
            Loop ff_loop = (Loop) ff_block;
            if (!ff_loop.isBackLoop()
                    && (ff_loop.getBeginPc() == oper.getTargetIndex())) {
                oper.setContinue(true);
                return true;
            } else if (ff_loop.isBackLoop()) {
                if (!(prevFF instanceof Catch)) {
                    oper.setContinue(true);
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public String toString() {
        return String.format("[%s:startPc=%d,endPc=%d]", this.getClass()
                .getSimpleName(), startPc, endPc);
    }
}
