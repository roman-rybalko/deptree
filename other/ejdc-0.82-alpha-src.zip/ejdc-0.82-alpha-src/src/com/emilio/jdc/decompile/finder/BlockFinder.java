package com.emilio.jdc.decompile.finder;

import com.emilio.jdc.decompile.structure.Block;

/**
 * 
 * @author Emilio Liang
 * 
 *
 */
public interface BlockFinder{
    public void analyze(Block block);
}
