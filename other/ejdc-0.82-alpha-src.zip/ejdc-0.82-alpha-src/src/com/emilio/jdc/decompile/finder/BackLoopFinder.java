package com.emilio.jdc.decompile.finder;

import java.util.List;

import com.emilio.jdc.core.operation.Goto;
import com.emilio.jdc.core.operation.If;
import com.emilio.jdc.core.operation.OperationType;
import com.emilio.jdc.decompile.structure.Block;
import com.emilio.jdc.decompile.structure.Catch;
import com.emilio.jdc.decompile.structure.CodeStruct;
import com.emilio.jdc.decompile.structure.Loop;
import com.emilio.jdc.decompile.structure.Try;

/**
 * 
 * @author Emilio Liang
 *
 */
public class BackLoopFinder implements BlockFinder{

    public void analyze(Block block){
        //block.reset();
        
        //Iterator<CodeStruct> it = block.iterator();
        
        for (CodeStruct struct : block.getOperations()){
            //CodeStruct op = it.next();
            if (!(struct.getOperationType().equals(OperationType.IF))){ 
                continue;
            }
            
            If ifCond = (If) struct;
            if (!ifCond.isForward()){
                //TODO open this method
                createBackLoop(block, ifCond);
            }
        }
    }
    
    /**
     * 
     * @param block
     * @param ifCond
     */
    private void createBackLoop(Block block, If ifCond){
        CodeStruct preLoop = block.getOperationBefore(ifCond.getTargetIndex());
        boolean printCondition = false;
        if (preLoop != null && preLoop.getOperationType() == OperationType.GOTO &&
            ((Goto) preLoop).isForward() &&
            ((Goto) preLoop).getTargetIndex() < ifCond.getByteIndex())
        {
            printCondition = true;
            block.removeOperation(preLoop.getByteIndex());
            // TODO set label for conditions
        }

        Loop loop = new Loop(block, true);
        loop.setPrintPrecondition(printCondition);

        //try-catch inside loop with break in try block results in loop block inside catch
        boolean isLoopCreated = false;
        if (block instanceof Catch)
        {
            Try tryBlock = (Try) block.getParent().getOperationBefore(block.getByteIndex());
            if (tryBlock.getByteIndex() >= ifCond.getTargetIndex())
            {
                block.getParent().createSubBlock(ifCond.getTargetIndex(), ifCond.getByteIndex(), loop);
                isLoopCreated = true;
            }
        }

        if (!isLoopCreated)
        {
            block.createSubBlock(ifCond.getTargetIndex(), ifCond.getByteIndex(), loop);
        }

        List<CodeStruct> firstConditions = block.createSubBlock(ifCond.getByteIndex(), ifCond.getByteIndex() + 1, null);
        loop.addAndConditions(firstConditions); // TODO smth with multiple conditions
    }

    /**
     * 
     * @param block
     * @return
     */
    public Loop collapseBackLoops(Block block){
        if (!(block instanceof Loop) || (block.size() > 2) || (block.size() == 0) || !(block.getFirstOperation() instanceof Loop)) return null;
        if ((block.size() == 2) && !(block.getLastOperation().getOperationType() ==  OperationType.NOP)) return null;

        Loop loop = ((Loop) block.getFirstOperation());
        if (!loop.isBackLoop()) return null;
        loop.addAndConditions2(((Loop) block).getConditions());
        loop.setParent(block.getParent());
        return loop;
    }
}
