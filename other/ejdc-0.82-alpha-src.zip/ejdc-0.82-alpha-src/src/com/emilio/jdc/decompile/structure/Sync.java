package com.emilio.jdc.decompile.structure;

import java.util.List;

import com.emilio.jdc.core.operation.Operation;
import com.emilio.jdc.core.operation.OperationType;

public class Sync extends CodeBlock {
    private Operation syncObject;

    public Sync(Operation syncObject, Block parent, List<Operation> ops) {
        super(ops, parent);
        this.syncObject = syncObject;

        // Removing last push and monitorexit operations
        CodeStruct monitorExit = getLastOperation();
        if (!(monitorExit.getOperationType() == OperationType.SYNC))// MonitorExitView))
        {
            // TODO in some cases it can be consumed by nested blocks
            // throw new
            // RuntimeException("monitorexit opcode's not found in Sync block");
        } else {
            CodeStruct push = getOperationBefore(monitorExit.getByteIndex());
            if (!(push instanceof Operation)
                    || !((Operation) push).isPushType()) {
                throw new RuntimeException(
                        "push opcode for monitorexit's not found in Sync block");
            }
            removeOperation(monitorExit.getByteIndex());
            removeOperation(push.getByteIndex());
        }
    }

    @Override
    public String toText() {
        StringBuilder text = new StringBuilder();
        // text.append(indent);
        text.append("synchronized (");
        text.append(syncObject.toText());
        text.append(")");
        text.append(LINE_SEPARATOR);
        // text.append(NL);
        text.append(super.toText());
        return text.toString();
    }

    @Override
    public String toString() {
        return String.format("[%s:]", this.getClass().getSimpleName());
    }
}
