package com.emilio.jdc.decompile.structure;

import java.util.ArrayList;
import java.util.List;

import com.emilio.jdc.core.operation.Operation;
import com.emilio.jdc.core.operation.Switch;

public class SwitchBlock extends CodeBlock {
    private Operation switchOp;
    private List<CaseBlock> caseBlocks = new ArrayList<CaseBlock>();

    public SwitchBlock(Block parent) {
        // TODO
        super(parent);
        // super(null, parent);
    }

    public void addCaseBlock(Switch.CaseBranch caseBranch, Block block) {
        CaseBlock caseBlock = new CaseBlock(caseBranch, this, block);
        caseBlocks.add(caseBlock);
        // TODO ops.add(caseBlock)
        // ops.add(caseBlock);
    }

    @Override
    public String toText() {
        StringBuilder text = new StringBuilder();
        // text.append(indent);
        text.append("switch (");
        text.append(switchOp.getExpression().toText());
        text.append(")");
        text.append(LINE_SEPARATOR);
        // text.append(indent);
        text.append("{");
        text.append(LINE_SEPARATOR);
        for (CaseBlock caseBlock : caseBlocks) {
            // cb.setIndent(indent + "    ");
            text.append(caseBlock);
        }
        // sb.append(indent)
        text.append("}");
        text.append(LINE_SEPARATOR);
        return text.toString();
    }

    /**
     * 
     * @return
     */
    public List<CaseBlock> getCaseBlocks() {
        return caseBlocks;
    }

    /**
     * 
     */
    public void analyze(Block block) {
        // TODO following lines
        // OperationView intVal = context.pop();
        // switchVar = intVal;
    }

    @Override
    public String toString() {
        return String.format("[%s:]", this.getClass().getSimpleName());
    }
}
