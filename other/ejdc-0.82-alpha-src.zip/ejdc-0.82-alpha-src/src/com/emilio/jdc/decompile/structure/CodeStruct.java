package com.emilio.jdc.decompile.structure;

import com.emilio.jdc.core.operation.OperationType;
import com.emilio.jdc.core.operation.expr.Expression;

public interface CodeStruct extends Expression {
    public int getByteIndex();

    public void analyze(Block block);

    public OperationType getOperationType();
}
