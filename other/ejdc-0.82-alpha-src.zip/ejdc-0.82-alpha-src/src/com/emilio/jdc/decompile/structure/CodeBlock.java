package com.emilio.jdc.decompile.structure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.operation.Operation;
import com.emilio.jdc.core.operation.OperationType;
import com.emilio.jdc.core.operation.expr.Expression;

public class CodeBlock implements Block, CodeStruct, Expression {
    private MethodContext context;
    // private ListIterator<Operation> iterator;
    // private NavigableMap<Integer,CodeStruct> map = new
    // ConcurrentSkipListMap<Integer,CodeStruct>();

    private List<CodeStruct> ops = new CopyOnWriteArrayList<CodeStruct>();
    private Block parent;

    private int fakeStartByte;

    public CodeBlock(List<? extends CodeStruct> list, Block parent) {
        this.parent = parent;
        // for(CodeStruct op : list){
        // map.put(op.getByteIndex(), op);
        // }

        ops.addAll(list);
    }

    // public CodeBlock(NavigableMap<Integer,CodeStruct> map,Block parent){
    // this.parent = parent;
    // this.map = map;
    // }

    public CodeBlock(Block parent) {
        this(Collections.<Operation> emptyList(), parent);
    }

    public CodeBlock(List<? extends CodeStruct> list, Block parent,
            MethodContext context) {
        this(list, parent);
        this.context = context;
    }

    public void postAnalyze(Block block) {

    }

    public void preAnalyze(Block block) {

    }

    public void postProcess() {

    }

    public LocalVariableTable getLocalVariableTable() {
        return getMethodContext().getLocalVariableTable();
    }

    public MethodContext getMethodContext() {
        Block preBlock = this;
        while (preBlock.getParent() != null) {
            preBlock = preBlock.getParent();
        }
        return preBlock.getCurrentMethodContext();
    }

    public MethodContext getCurrentMethodContext() {
        return this.context;
    }

    public String getOperationsSource(int endByte) {
        StringBuilder text = new StringBuilder();
        // boolean withLN =
        // "yes".equals(getMethodView().getClazzView().getDecompileParameter(ClazzSourceView.WITH_LINE_NUMBERS))
        // &&
        // (getMethodView().getMethod().getCodeBlock() != null) &&
        // (getMethodView().getMethod().getLineNumberTable() != null);

        boolean withLN = true;

        for (Iterator<CodeStruct> it = this.iterator(); it.hasNext();) {
            CodeStruct citem = it.next();
            if (endByte != -1 && citem.getByteIndex() >= endByte)
                break;

            // TODO remove
            String indent = "    ";

            if (withLN == true
                    && (!(citem instanceof Block) || (citem instanceof IfBlock) || (citem instanceof Loop && (((Loop) citem)
                            .isPrintPrecondition())))) {
//                int byteIndex = 0;
//                if (citem instanceof Loop) {
//                    IfCondition cond0 = (IfCondition) (((Loop) citem)
//                            .getConditions().get(0)).get(0);
//                    byteIndex = (int) cond0.getIfOperation().getByteIndex();
//                } else {
//                	byteIndex = (int) citem.getByteIndex();
//                }

//                 TODO line number support
//                 int ln =
//                 getMethodContext().getLineNumberTable().getLineNumber(instruction);
//                 if (ln != -1)
//                 {
//                 // TODO improve printing line numbers
//                 text.append(indent).append("    ").append("/* ").append(ln).append(" */");
//                 }
            }

            if (citem instanceof Block) {
                // ((Block) citem).setIndent(indent + "    ");
                text.append(citem.toText());
            } else {
                Operation op = (Operation) citem;
                
                System.out.println(op.isVisibleText());
                // TODO add if ?
                if (op.isVisibleText()){
                String opSource = op.toText();
                if (opSource != null) {
                    text.append(indent);
                    text.append("    ");
                    text.append(opSource);
                    text.append(";");
                    text.append(LINE_SEPARATOR);
                }
                }
                // }
            }
        }
        return text.toString();
    }

    // public void setMap(NavigableMap<Integer,CodeStruct> map){
    // this.map = map;
    // }
    //
    public void setParent(Block parent) {
        this.parent = parent;
    }

    public List<CodeStruct> toValues() {
        return ops;
    }

    public Iterator<CodeStruct> iterator() {
        return ops.iterator();
    }

    public void analyze(Block block) {

    }

    public void postCreate() {

    }

    // public List<CodeStruct> createSubBlock(int startOp, int endOp, Block
    // subBlock){
    // System.out.println("startOp-------------------"+startOp);
    // System.out.println("endOp-------------------"+endOp);
    //
    // NavigableMap<Integer,CodeStruct> sub =
    // map.subMap(map.floorKey(startOp),true,map.lowerKey(endOp),true);
    //
    // NavigableMap<Integer,CodeStruct> newSub = new
    // ConcurrentSkipListMap<Integer,CodeStruct>(sub);
    //
    // for(Integer key :sub.keySet()){
    // //if(key > startOp){
    // map.remove(key);
    // //}
    // }
    //
    // if (subBlock != null){
    // subBlock.setMap(newSub);
    //
    // map.put(subBlock.getByteIndex(), subBlock);
    //
    //
    // subBlock.setParent(this);
    // subBlock.postCreate();
    // }
    //
    // List<CodeStruct> subOps = new ArrayList<CodeStruct>(newSub.values());
    //
    // System.out.println("Begin################################");
    //
    // for(int key : map.keySet()){
    // System.out.println("key---"+key);
    // }
    //
    // System.out.println("End################################");
    // return subOps;
    // boolean moving = false;
    // int pos = 0;
    // while (pos < ops.size())
    // {
    // Operation citem = (Operation) ops.get(pos);
    // if (citem.getByteIndex() >= startOp) moving = true;
    // if (citem.getByteIndex() >= endOp) break;
    //
    // if (moving)
    // {
    // subops.add(citem);
    // if (subblock != null && citem instanceof Block) ((Block)
    // citem).setParent(subblock);
    // ops.remove(pos);
    // if (ext_pos > pos && pos != 0) ext_pos--;
    // }
    // else
    // {
    // pos++;
    // }
    // }
    //
    // if (subblock != null)
    // {
    // ops.add(pos, subblock);
    // subblock.setOperations(subops);
    // if (subops.isEmpty())
    // {
    // subblock.setFakeStartByte(startOp);
    // }
    // subblock.setParent(this);
    // subblock.postCreate();
    // }
    // return subops;

    // }

    public List<CodeStruct> createSubBlock(int startOp, int endOp,
            Block subblock) {
        List<CodeStruct> subops = new ArrayList<CodeStruct>();

        boolean moving = false;
        int pos = 0;
        while (pos < ops.size()) {
            CodeStruct citem = ops.get(pos);
            if (citem.getByteIndex() >= startOp)
                moving = true;
            if (citem.getByteIndex() >= endOp)
                break;

            if (moving) {
                subops.add(citem);
                if (subblock != null && citem instanceof Block)
                    ((Block) citem).setParent(subblock);
                ops.remove(pos);
                // if (ext_pos > pos && pos != 0) ext_pos--;

                // System.out.println("Begin################################");
                //
                // for(int i =0 ;i <ops.size() ;i++){
                // System.out.println("key---"+((CodeItem)ops.get(i)).getStartByte());
                // }
                //
                // System.out.println("End################################");
                //
            } else {
                pos++;
            }
        }

        if (subblock != null) {
            ops.add(pos, subblock);
            subblock.setOperations(subops);
            if (subops.isEmpty()) {
                subblock.setFakeStartByte(startOp);
            }

            subblock.setParent(this);
            subblock.postCreate();
        }

        return subops;
    }

    public void setFakeStartByte(int fakeStartByte) {
        this.fakeStartByte = fakeStartByte;
    }

    /**
     *
     */
    public CodeStruct removeOperation(int key) {
        return ops.remove(key);
    }

    public CodeStruct getFirstOperation() {
        if (!ops.isEmpty()) {
            return ops.get(0);
        } else {
            return null;
        }
    }

    public CodeStruct getLastOperation() {
        if (!ops.isEmpty()) {
            return ops.get(ops.size() - 1);
        } else {
            return null;
        }
    }

    /**
     * 
     * @param startByte
     * @return
     */
    // public CodeStruct getOperationAfter(int startIndex){
    // return map.get(map.higherKey(startIndex));
    // }
    //
    public CodeStruct getOperationAfter(long start_byte) {
        for (int i = 0; i < ops.size(); i++) {
            if ((ops.get(i)).getByteIndex() > start_byte) {
                return ops.get(i);
            }
        }
        return null;
    }

    /**
     * 
     * @param startIndex
     * @return
     */
    // public CodeStruct getOperationBefore(int startIndex){
    // return map.get(map.lowerKey(startIndex));
    // }

    public CodeStruct getOperationBefore(int startPc) {
        for (int i = 0; i < ops.size(); i++) {
            if ((ops.get(i)).getByteIndex() >= startPc) {
                if (i == 0)
                    return null;
                return ops.get(i - 1);
            }
        }
        return getLastOperation();
    }

    /**
     * 
     * @param startIndex
     * @return
     */
    // public CodeStruct getOperationByStartByte(int startIndex){
    // return map.get(startIndex);
    // }

    public CodeStruct getOperationByStartByte(long start_byte) {
        for (int i = 0; i < ops.size(); i++) {
            if ((ops.get(i)).getByteIndex() == start_byte) {
                return ops.get(i);
            }
        }
        return null;
    }

    public List<CodeStruct> getOperations() {
        return ops;
    }

    // public Operation getFirstOperation(){
    // if (!ops.isEmpty()){
    // return ops.get(0);
    // }else{
    // return null;
    // }
    // }
    //
    // public Operation getLastOperation(){
    // if (!ops.isEmpty()){
    // return ops.get(ops.size()-1);
    // }else{
    // return null;
    // }
    // }

    // public Operation removeLastOperation(){
    // if (!ops.isEmpty()){
    // return ops.remove(ops.size()-1);
    // }else{
    // return null;
    // }
    // }
    //
    // public Operation removeFirstOperation(){
    // if (!ops.isEmpty()){
    // return ops.remove(0);
    // }else{
    // return null;
    // }
    // }

    // public CodeStruct removeLastOperation(){
    // if (!map.isEmpty()){
    // return map.remove(map.lastKey());
    // }else{
    // return null;
    // }
    // }
    //
    // public CodeStruct removeFirstOperation(){
    // if (!map.isEmpty()){
    // return map.remove(map.firstKey());
    // }else{
    // return null;
    // }
    // }

    public CodeStruct removeLastOperation() {
        return ops.isEmpty() ? null : removeOperation(ops.size() - 1);
    }

    public CodeStruct removeFirstOperation() {
        if (!ops.isEmpty()) {
            return removeOperation(0);
        }
        return null;
    }

    public void addOperation(int index, Operation element) {
        ops.add(index, element);
    }

    // public void addOperation(int index, CodeStruct element){
    // map.put(index, element);
    // }

    // TODO
    // public void replaceCurrentOperation(CodeStruct op){
    // map.put(op.getByteIndex(), map.get(op.getByteIndex()));
    // }

    // //TODO
    // public Operation next(){
    // return null;
    // }
    //
    // //TODO
    // public boolean hasNext(){
    // return true;
    // }
    //

    // public int getStartByte() {
    // if (map.isEmpty()) {
    // return fakeStartByte;
    // }
    //
    // return map.get(map.firstKey()).getByteIndex();
    // }

    public Block getParent() {
        return parent;
    }

    // public int getByteIndex(){
    // if (map.isEmpty()){
    // return fakeStartByte;
    // }
    // return map.get(map.firstKey()).getByteIndex();
    // }

    public int getByteIndex() {
        if (ops == null || ops.isEmpty()) {
            return fakeStartByte;
        }
        return ops.get(0).getByteIndex();
    }

    /**
     * 
     * @param fromIndex
     */
    // public void truncate(int fromIndex){
    // Set<Integer> set = map.keySet();
    //
    // for (Integer key: set){
    // if (key >= fromIndex)
    // map.remove(key);
    // }
    // }

    public void truncate(int fromStartByte) {
        Iterator<CodeStruct> it = ops.iterator();
        while (it.hasNext()) {
            CodeStruct cs = it.next();
            if (cs.getByteIndex() >= fromStartByte) {
                it.remove();
            }
        }
    }

    /**
     * 
     */
    public int size() {
        return ops.size();
    }

    public OperationType getOperationType() {
        return OperationType.UNKNOWN;
    }

    public String toText() {
        return getOperationsSource(-1);
    }

    public String toString() {
        return "[CodeBlock]";
    }

    // public boolean add(Operation element){
    // return ops.add(element);
    // }
    //
    // public void add(int index, Operation element){
    //
    // }
    //
    // public boolean addAll(Collection<? extends Operation> c){
    // return ops.addAll(c);
    // }
    //
    // public boolean addAll(int index, Collection<? extends Operation> c){
    // return ops.addAll(index, c);
    // }
    //
    // public void clear(){
    //
    // }
    //
    // public boolean contains(Object o) {
    // return ops.contains(o);
    // }
    //
    // public boolean containsAll(Collection<?> c){
    // return ops.containsAll(c);
    // }
    //
    // public boolean equals(Object o){
    // return ops.equals(o);
    // }
    //
    // public Operation get(int index){
    // return ops.get(index);
    // }
    //
    // public int hashCode(){
    // return ops.hashCode();
    // }
    //
    // public int indexOf(Object o){
    // return ops.indexOf(o);
    // }
    //
    // public boolean isEmpty(){
    // return ops.isEmpty();
    // }
    //
    // public Iterator<Operation> iterator(){
    // return ops.iterator();
    // }
    //
    // public int lastIndexOf(Object o){
    // return ops.lastIndexOf(o);
    // }
    //
    // public ListIterator<Operation> listIterator(){
    // return ops.listIterator();
    // }
    //
    // public ListIterator<Operation> listIterator(int index){
    // return ops.listIterator(index);
    // }
    //
    // public Operation remove(int index){
    // return ops.remove(index);
    // }
    //
    // public boolean remove(Object o){
    // return ops.remove(o);
    // }
    //
    // public boolean removeAll(Collection<?> c) {
    // return ops.removeAll(c);
    // }
    //
    // public boolean retainAll(Collection<?> c) {
    // return ops.retainAll(c);
    // }
    //
    // public Operation set(int index, Operation element){
    // return ops.set(index, element);
    // }
    //
    // public int size() {
    // return ops.size();
    // }
    //
    // public List<Operation> subList(int fromIndex, int toIndex){
    // return ops.subList(fromIndex, toIndex);
    // }
    //
    // public Object[] toArray() {
    // return ops.toArray();
    // }
    //
    // public <T> T[] toArray(T[] a) {
    // return ops.toArray(a);
    // }

    public static void main(String args[]) {
//        NavigableMap<Integer, String> map = new TreeMap<Integer, String>();
//
//        map.put(1, "1");
//        map.put(2, "2");
//        map.put(5, "5");
//
//        map.put(7, "7");
//        map.put(9, "9");
//        map.put(12, "12");
//
//        NavigableMap<Integer, String> sub = map.subMap(5, true, 9, true);
//
//        NavigableMap<Integer, String> subnew = new TreeMap<Integer, String>(sub);
//
//        map.remove(5);
//        System.out.println(map);
//        System.out.println(sub);
//        System.out.println(subnew);

    }

    public CodeStruct getOperationAfter(int startByte) {
        // TODO Auto-generated method stub
        return null;
    }

    public CodeStruct getOperationByStartByte(int startByte) {
        // TODO Auto-generated method stub
        return null;
    }

    public void setOperations(List<CodeStruct> list) {
        this.ops = list;
    }

    // public boolean hasMoreOperations() {
    // // TODO Auto-generated method stub
    // return false;
    // }

    public void addOperation(int index, CodeStruct op) {
        // TODO Auto-generated method stub

    }

    public int getStartByte() {
        // TODO Auto-generated method stub
        return 0;
    }

    public void replaceOperation(int start_byte, CodeStruct newop) {
        for (int i = 0; i < ops.size(); i++) {
            if (ops.get(i).getByteIndex() == start_byte) {
                ops.remove(i);
                ops.add(i, newop);
                return;
            }
        }
    }

}
