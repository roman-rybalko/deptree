package com.emilio.jdc.decompile.finder;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.emilio.jdc.core.attribute.ExceptionTable;
import com.emilio.jdc.core.attribute.ExceptionTableEntry;
import com.emilio.jdc.core.constant.ConstantClass;
import com.emilio.jdc.core.operation.OperationType;
import com.emilio.jdc.decompile.structure.Block;
import com.emilio.jdc.decompile.structure.Catch;
import com.emilio.jdc.decompile.structure.CodeStruct;
import com.emilio.jdc.decompile.structure.Try;

/**
 * 
 * @author Emilio Liang
 *
 */
public class TryCatchFinder  implements BlockFinder{
    private List<ExceptionTableEntry> fakeFinallies = new ArrayList<ExceptionTableEntry>();
    private List<int[]> suspiciousFinallies = new ArrayList<int[]>();
    private List<ExceptionTableEntry> tableList;

    public TryCatchFinder(ExceptionTable exceptionTable) {
        // Copy protection
    	    	
        tableList = new ArrayList<ExceptionTableEntry>(exceptionTable.getExceptionTableList());

        if (tableList == null || tableList.size() == 0) {
            return;
        }

        // Removing fake finally blocks for each catch block
        for (int i = 0; i < tableList.size(); i++) {
            ExceptionTableEntry exTableEntry = tableList.get(i);
            // TODO needs this check?
            if (exTableEntry.getCatchType() == null
                    && !isReallyFinally(tableList, exTableEntry)) {
                fakeFinallies.add(exTableEntry);
                tableList.remove(i);
            }
        }

        for (int i = 0; i < tableList.size(); i++) {
            ExceptionTableEntry outerEntry = tableList.get(i);

            for (int j = 0; j < tableList.size(); j++) {
                ExceptionTableEntry innerEntry = tableList.get(j);

                if (outerEntry.getStartPc() == innerEntry.getStartPc()
                        && outerEntry.getEndPc() == innerEntry.getEndPc()
                        && outerEntry.getHandlerPc() == innerEntry
                                .getHandlerPc()) {
                    continue;
                }

                if (outerEntry.getEndPc() == innerEntry.getEndPc()
                        && outerEntry.getStartPc() > innerEntry.getEndPc()) {
                    // Removing etn as it is simply continue of cet
                    suspiciousFinallies.add(new int[] { innerEntry.getEndPc(),
                            outerEntry.getStartPc() });
                    // fit.remove();
                    tableList.remove(i);
                    // etn.end_pc = cet.end_pc;
                    innerEntry.setEndPc(innerEntry.getEndPc());
                    break;
                }
            }
        }
        //TODO
        // // sorting try-catches
        // Collections.sort(trys, new Comparator()
        // {
        // public int compare(Object o1, Object o2)
        // {
        // Code.ExceptionTable cet1 = (Code.ExceptionTable) o1;
        // Code.ExceptionTable cet2 = (Code.ExceptionTable) o2;
        //
        // if (cet1.end_pc < cet2.start_pc)
        // {
        // int comparison = cet1.end_pc - cet2.end_pc;
        // if (comparison == 0) comparison = cet1.handler_pc - cet2.handler_pc;
        // return comparison;
        // }
        // else
        // {
        // return cet1.start_pc - cet2.start_pc;
        // }
        // }
        // });
        // }
    }

    /**
     * 
     * @param tableList
     * @param entry
     * @return
     */
    private boolean isReallyFinally(List<ExceptionTableEntry> tableList,
            ExceptionTableEntry entry) {
        if (entry.getStartPc() == entry.getHandlerPc()) {
            return false;
        }

        for (int i = 0; i < tableList.size(); i++) {
            ExceptionTableEntry tableEntry = tableList.get(i);
            if ((tableEntry.getCatchType() != null)
                    && (tableEntry.getHandlerPc() == entry.getStartPc())) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param block
     */
    public void analyze(Block block) {
        if (tableList == null || tableList.size() == 0) {
            return;
        }
        
        // Creating blocks
        Iterator<ExceptionTableEntry> it = tableList.iterator();
        boolean hasMoreTries = true;
        ExceptionTableEntry etn = null;
        do {
            if (!it.hasNext() && etn == null)
                break;
            ExceptionTableEntry et = etn == null ? it.next() : etn;

            if ((et.getStartPc() < block.getByteIndex())|| (et.getEndPc() > block.getLastOperation().getByteIndex())) {
                etn = null;
                continue;
            }
            if (findSubBlock(block, et.getStartPc(), et.getEndPc())) {
                etn = null;
                continue;
            }

            // If trys are sorted correctly then next iterator value will be
            // first catch for this try block
            // We assume that its start byte will be end byte for try
            CodeStruct gop = block.getOperationBefore(et.getHandlerPc());

            Try _try = new Try(et.getStartPc(), et.getEndPc(), block);
            _try.setFinallyException(fakeFinallies);
            _try.setSuspiciousFinallies(suspiciousFinallies);
            //TODO why add one
            //block.createSubBlock(et.getStartPc(), gop.getByteIndex() + 1, _try);
            block.createSubBlock(et.getStartPc(), gop.getByteIndex(), _try);

            it.remove();

            // Processing several catch blocks (except last)
            Catch _catch = new Catch(et.getHandlerPc(), (ConstantClass)et.getCatchType(), block);
            hasMoreTries = false;
            while (it.hasNext()) {
                etn = it.next();
                
                if (((etn.getStartPc() != et.getStartPc()) || (etn.getEndPc() != et.getEndPc() && etn.getEndPc() > gop
                        .getByteIndex()))) {
                    hasMoreTries = true;
                    break;
                }

                block.createSubBlock(et.getHandlerPc(), etn.getHandlerPc(), _catch);
                _try.addCatchBlock(_catch);
                et = etn;
                _catch = new Catch(et.getHandlerPc(), (ConstantClass)et.getCatchType(), block);
                it.remove();
            }
            // Processing last catch block
            int retr_pc = _try.getRetrieveOperation();
            for (Iterator<Catch> cit = _try.getCatchBlocks().iterator(); cit.hasNext();) {
                Catch __catch = cit.next();
                if (__catch.getRetrievePc() < retr_pc) {
                    retr_pc = __catch.getRetrievePc();
                }
            }
            if (retr_pc == Integer.MAX_VALUE
                    && block.getLastOperation().getOperationType() ==  OperationType.GOTO) {
                retr_pc = block.getLastOperation().getByteIndex();
            }
            
            block.createSubBlock(et.getHandlerPc(), retr_pc, _catch);
            _try.addCatchBlock(_catch);
            _try.removeSuspiciousInlinedFinallyBlocks();
        } while (hasMoreTries);
    }

    /**
     * 
     * @param block
     * @param start_pc
     * @param end_pc
     * @return
     */
    private boolean findSubBlock(Block block, int start_pc, int end_pc) {
        CodeStruct ci = block.getOperationByStartByte(start_pc);
        if (ci instanceof Block) {
            return ((Block) ci).getLastOperation().getByteIndex() > end_pc;
        }
        return ci == null;
    }

}
