package com.emilio.jdc.decompile.structure;

import com.emilio.jdc.core.operation.Goto;
import com.emilio.jdc.core.operation.OperationType;
import com.emilio.jdc.core.operation.Switch;

public class CaseBlock extends CodeBlock {
    private Switch.CaseBranch caseBranch;
    private long exitGoto = 0;

    public CaseBlock(Switch.CaseBranch caseBranch, SwitchBlock switchBlock,
            Block block) {
        // TODO
        super(block.getOperations(), switchBlock);

        this.caseBranch = caseBranch;

        // TODO
        // Try to find last goto, which means the end of switch block
        if (getLastOperation().getOperationType() == OperationType.GOTO) {
            exitGoto = ((Goto) removeLastOperation()).getTargetIndex();
        }
    }

    public int getByteIndex() {
        return caseBranch.getOffset();
    }

    // TODO
    public long getLastGotoOffset() {
        return exitGoto;
    }

    public String getSource() {
        StringBuffer sb = new StringBuffer();
        // if (_case.isDeafult() && isEmpty()) return ""; // absence of default
        // block
        // if (_case.isDeafult()){
        // sb.append(indent).append("default");
        // }
        // else{
        // sb.append(indent).append("case ").append(_case.getValue());
        // }
        // sb.append(":").append(NL);
        //
        // if (!isEmpty()){
        // sb.append(super.getOperationsSource());
        // }
        // else{
        // // Empty case block
        // }
        // if (exitGoto != 0){
        // sb.append(indent).append("    break;").append(NL);
        // }
        return sb.toString();
    }

    @Override
    public String toString() {
        return String.format("[%s:]", this.getClass().getSimpleName());
    }
}
