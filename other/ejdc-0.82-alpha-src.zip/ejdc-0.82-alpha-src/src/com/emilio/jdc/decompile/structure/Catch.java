package com.emilio.jdc.decompile.structure;

import com.emilio.jdc.core.constant.ConstantClass;
import com.emilio.jdc.core.operation.Goto;
import com.emilio.jdc.core.operation.OperationType;

public class Catch extends CodeBlock {
    private ConstantClass exceptionClassInfo;
    private int handler_pc;

    private int retrieve_pc = Integer.MAX_VALUE;

    // private LocalVariable lv;

    public Catch(int handler_pc, ConstantClass cl_info, Block parent) {
        super(parent);
        this.handler_pc = handler_pc;
        exceptionClassInfo = cl_info;
    }

    @Override
    public int getByteIndex() {
        return handler_pc;
    }

    public void postCreate() {
        if (getLastOperation().getOperationType() == OperationType.GOTO) {
            if (!checkLastGoTo((Goto) getLastOperation())) {
                retrieve_pc = ((Goto) getLastOperation()).getTargetIndex();
            }
        }
    }

    public void postProcess() {
        // Removing first POP operation
        // TODO what about OperationType.ARRAYSTORE and OperationType.POP
        OperationType type = getFirstOperation().getOperationType();
        if (type == OperationType.STORE) {
            //Store pop = (Store) removeFirstOperation();
            if (exceptionClassInfo != null) {
                // TODO Why
                // lv =
                // getLocalVariable(pop.getVarNum(),exceptionClassInfo.getName(),
                // (int) pop.getByteIndex());
                // +1 because in catch block first operation usually "store"
                // lv.ensure((int) handler_pc + 1);
            }
        } else if (type == OperationType.ARRAYSTORE
                || type == OperationType.POP) {
            removeFirstOperation();
        }

        // Removing last goto operation for catch blocks
        if (getLastOperation().getOperationType() == OperationType.GOTO) {
            if (!checkLastGoTo((Goto) getLastOperation())) {
                removeLastOperation();
            }
        }

        // Removing last jsr operation for catch blocks
        if (getLastOperation().getOperationType() == OperationType.JSR) {
            removeLastOperation();
        }

        // Removing last PUSH and THROW operations for finally blocks
        if (exceptionClassInfo == null) {
            // Support jsr-ret finally constructions
            if (getFirstOperation().getOperationType() == OperationType.JSR) {
                // Here we have the following instructions: jsr, push, throw,
                // store, ..., ret
                removeFirstOperation();
                removeFirstOperation();
                removeFirstOperation();
                removeFirstOperation();
                removeLastOperation();
            } else {
                if (getLastOperation().getOperationType() == OperationType.THROW) {
                    removeLastOperation();
                    if (getLastOperation().getOperationType() == OperationType.LOAD) {
                        removeLastOperation();
                    }
                }
            }
        }
    }

    private boolean checkLastGoTo(Goto oper) {
        Block ff_block = this;
        CodeStruct ff_oper;
        do {
            ff_oper = ff_block.getOperationByStartByte(oper.getTargetIndex());
            if (ff_oper != null)
                break;
            ff_block = ff_block.getParent();
        } while (ff_block != null);
        if (ff_oper == null)
            return false;

        CodeStruct prevFF = ff_block.getOperationBefore(ff_oper.getByteIndex());
        if (prevFF instanceof Loop) {
            oper.setBreak(true);
            return true;
        }
        if (ff_block instanceof Loop) {
            Loop ff_loop = (Loop) ff_block;
            if (!ff_loop.isBackLoop()
                    && (ff_loop.getBeginPc() == oper.getTargetIndex())) {
                oper.setContinue(true);
                return true;
            } else if (ff_loop.isBackLoop()) {
                if (!(prevFF instanceof Catch)) {
                    oper.setContinue(true);
                    return true;
                }
            }
        }

        return false;
    }

    public int getRetrievePc() {
        return retrieve_pc;
    }

    public String getExceptionType() {
        return exceptionClassInfo != null ? exceptionClassInfo.getName() : null;
    }

    public String toText() {
        StringBuilder text = new StringBuilder();
        // text.append(indent);
        if (exceptionClassInfo != null) {
            text.append("catch (");
            text.append(exceptionClassInfo.getName());
            // TODO
            // alias(exceptionClassInfo.getFullyQualifiedName()))
            text.append(BLANK_SPACE);
            // text.append(lv != null ? lv.getName() : "")
            text.append("ex");
            text.append(")");
            // TODO
            // lv.setPrinted(true);
        } else {
            text.append("finally");
        }
        text.append(LINE_SEPARATOR);
        text.append(super.toText());
        return text.toString();
    }

    public boolean isFinally() {
        return exceptionClassInfo == null;
    }

    @Override
    public String toString() {
        return String.format("[%s:]", this.getClass().getSimpleName());
    }
}
