package com.emilio.jdc.decompile.structure;

import com.emilio.jdc.core.operation.Goto;
import com.emilio.jdc.core.operation.OperationType;

public class Else extends CodeBlock {
    public Else(Block parent) {
        super(parent);
    }

    public String toText() {
        StringBuilder text = new StringBuilder();
        if (((size() == 1) && (getFirstOperation() instanceof IfBlock))
                || ((size() == 2) && (getFirstOperation() instanceof IfBlock) && (getLastOperation() instanceof Else))) {
            IfBlock ifb = (IfBlock) getFirstOperation();
            ifb.setElseIf(true);
            // ifb.setIndent(getIndent());
            // TODO
            text.append(ifb.toText());
            if (size() == 2) {
                Else elb = (Else) getLastOperation();
                // elb.setIndent(getIndent());
                text.append(elb.toText());
            }
        } else {
            // text.append(indent);
            text.append("else");
            text.append(LINE_SEPARATOR);
            text.append(super.toText());
        }

        // TODO whey printedSize
        // if ( ((printedSize() == 1) && (getFirstPrintedOperation() instanceof
        // IfBlock)) ||
        // ((printedSize() == 2) && (getFirstPrintedOperation() instanceof
        // IfBlock) && (getLastPrintedOperation() instanceof Else)) )
        // {
        // IfBlock ifb = (IfBlock) getFirstPrintedOperation();
        // ifb.setElseIf(true);
        // ifb.setIndent(getIndent());
        // text.append(ifb.getSource());
        // if (printedSize() == 2)
        // {
        // Else elb = (Else) getLastPrintedOperation();
        // elb.setIndent(getIndent());
        // text.append(elb.getSource());
        // }
        // }
        //
        // else
        // {
        // text.append(indent);
        // text.append("else");
        // text.append(LINE_SEPARATOR);
        // text.append(super.getSource());
        // }
        return text.toString();
    }

    public void postCreate() {

        // Last "goto" in else block can be "break" or "continue" if enclosed in
        // loop
        if (!(getLastOperation().getOperationType() == OperationType.GOTO))
            return;

        int target_byte = ((Goto) getLastOperation()).getTargetIndex();
        // Checking if last goto forwards to the begining of loop block, thus it
        // is "continue"
        if (!((Goto) getLastOperation()).isForward()) {
            Block prevBlock = getParent();
            while (prevBlock != null && !(prevBlock instanceof Loop)) {
                prevBlock = prevBlock.getParent();
            }
            if (prevBlock != null) {
                if (((Loop) prevBlock).getBeginPc() == target_byte) {
                    ((Goto) getLastOperation()).setContinue(true);
                    return;
                }
            }
        }

        // Trying to find target operation for "break"
        Block prevBlock = getParent();
        while (prevBlock != null) {
            CodeStruct ff_oper = prevBlock.getOperationByStartByte(target_byte);
            if (ff_oper != null) {
                CodeStruct prev_ff = prevBlock.getOperationBefore(target_byte);
                if (prev_ff instanceof Loop) // Found target operation after
                                             // loop
                {
                    ((Goto) getLastOperation()).setBreak(true); // Set goto to
                                                                // break
                    return;
                }
            }
            prevBlock = prevBlock.getParent();
        }
    }

    private int stackSizeChange;

    public void preAnalyze(Block block) {
        stackSizeChange = getMethodContext().size();
    }

    public void postAnalyze(Block block) {
        stackSizeChange = getMethodContext().size() - stackSizeChange;

        // TODO handle condition like (? 1 : 2)
        // if (stackSizeChange == 1)
        // {
        // // Convert to "condition ? op1 : op2" form
        // CodeStruct item = block.getOperationBefore(getStartByte());
        // if (item instanceof IfBlock && ((IfBlock) item).isIsPushShortForm())
        // {
        // Operation elsePush = getMethodContext().pop();
        // Operation ifPush = getMethodContext().pop();
        // FakeConditionalPushView fakePush = new
        // FakeConditionalPushView(getMethodView(), (IfBlock) item, ifPush,
        // elsePush);
        //
        // // Placing Fake Push View instead of If and Else Blocks
        // getMethodContext().push(fakePush);
        // block.removeOperation(item.getByteIndex());
        // block.removeOperation(this.getByteIndex());
        // }
        // }
    }

    @Override
    public String toString() {
        return String.format("[%s:]", this.getClass().getSimpleName());
    }
}
