package com.emilio.jdc.decompile.engine;

import java.util.Iterator;
import java.util.List;

import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.operation.Operation;
import com.emilio.jdc.decompile.finder.BackLoopFinder;
import com.emilio.jdc.decompile.finder.BlockFinder;
import com.emilio.jdc.decompile.finder.EndlessBackLoopFinder;
import com.emilio.jdc.decompile.finder.IfFinder;
import com.emilio.jdc.decompile.finder.LoopFinder;
import com.emilio.jdc.decompile.finder.SwitchFinder;
import com.emilio.jdc.decompile.finder.TryCatchFinder;
import com.emilio.jdc.decompile.structure.Block;
import com.emilio.jdc.decompile.structure.CodeBlock;
import com.emilio.jdc.decompile.structure.CodeStruct;
import com.emilio.jdc.decompile.structure.Loop;

public class Decompiler {
	
	/**
	 * Detect blocks with all possible finder
	 * @param topBlock
	 * @param context
	 * @return
	 */
    private static Block detectBlocks(Block topBlock, MethodContext context) {

        detectBlocks(topBlock, new TryCatchFinder(context.getExceptionTable()));

        detectBlocks(topBlock, new SwitchFinder());

        detectBlocks(topBlock, new BackLoopFinder());
        detectBlocks(topBlock, new LoopFinder());

        detectBlocks(topBlock, new IfFinder());

        detectBlocks(topBlock, new EndlessBackLoopFinder());

        // Pass 2
        detectBlocks(topBlock, new IfFinder());
        return topBlock;
    }

    /**
     * Convert operation list and MethodContext to Block
     * 
     * @param operations
     * @param msv
     * @return
     */
    public static Block toBlock(List<Operation> operations,
            MethodContext context) {
        return new CodeBlock(operations, Block.ROOT, context);
    }

    /**
     * Analyze block recursively with detector LY
     * 
     * @param block
     * @param detector
     */
    private static void detectBlocks(Block block, BlockFinder finder) {
        if (block == null)
            return;
        finder.analyze(block);

        // block.reset();
        Iterator<CodeStruct> it = block.iterator();

        while (it.hasNext()) {
            CodeStruct ci = it.next();
            if (ci instanceof Block) {
                detectBlocks((Block) ci, finder);
            }
        }
    }

    /**
     * Called by MethodSourceView and topBlock already constructed by operation
     * list.
     * 
     * @param topBlock
     * @param msv
     * @return
     */
    public static Block decompile(Block topBlock, MethodContext context) {
        detectBlocks(topBlock, context);
        postProcess(topBlock);
        analyze(topBlock);
        detectCompoundBackLoops(topBlock, new BackLoopFinder());
        return topBlock;
    }

    private static void postProcess(Block block) {
        if (block == null)
            return;
        // block.reset();
        Iterator<CodeStruct> it = block.iterator();

        while (it.hasNext()) {
            CodeStruct citem = it.next();
            if (citem instanceof Block) {
                ((Block) citem).postProcess();
                postProcess((Block) citem);
            }
        }
    }

    private static void analyze(Block block) {
        if (block == null)
            return;
        Iterator<CodeStruct> it = block.iterator();

        while (it.hasNext()) {
            CodeStruct citem = it.next();
            citem.analyze(block);

            if (citem instanceof Block) {
                ((Block) citem).preAnalyze(block);
                analyze((Block) citem);
                ((Block) citem).postAnalyze(block);
            }
        }
    }

    private static Loop detectCompoundBackLoops(Block block,
            BackLoopFinder detector) {
        if (block == null)
            return null;
        Loop innerLoop = detector.collapseBackLoops(block);
        if (innerLoop != null) {
            return innerLoop;
        }

        Iterator<CodeStruct> it = block.iterator();

        List<CodeStruct> list = block.getOperations();

        for (int i = 0; i < list.size(); i++) {
            CodeStruct ci = it.next();
            if (ci instanceof Block) {
                Block loop = (Block) ci;
                do {
                    loop = detectCompoundBackLoops(loop, detector);
                    if (loop != null) {
                        // TODO needs test;
                        list.remove(i);
                        list.add(i, loop);
                        // .replaceCurrentOperation(loop);
                    }
                } while (loop != null);

            }
        }
        // while (it.hasNext())
        // {
        // CodeStruct ci = it.next();
        // if (ci instanceof Block)
        // {
        // Block loop = (Block) ci;
        // do
        // {
        // loop = detectCompoundBackLoops(loop, detector);
        // if (loop != null) block.replaceCurrentOperation(loop);
        // }
        // while (loop != null);
        // }
        // }
        return null;
    }
}
