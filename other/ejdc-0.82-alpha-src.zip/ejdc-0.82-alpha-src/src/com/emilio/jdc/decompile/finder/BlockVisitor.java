package com.emilio.jdc.decompile.finder;

import com.emilio.jdc.core.attribute.ExceptionTable;
import com.emilio.jdc.decompile.structure.Block;

/**
 * 
 * @author Emilio Liang
 *
 */
public class BlockVisitor implements Visitor {
    private BackLoopFinder backLoopFinder = new BackLoopFinder();
    private EndlessBackLoopFinder endlessBackLoopFinder = new EndlessBackLoopFinder();
    private IfFinder ifFinder = new IfFinder();
    private LoopFinder loopFinder = new LoopFinder();
    private SwitchFinder switchFinder = new SwitchFinder();
    private TryCatchFinder tryCatchFinder;
    
    public void visitBackLoop(Block block) {
        // TODO Auto-generated method stub
        backLoopFinder.analyze(block);
    }

    public void visitEndlessBackLoop(Block block) {
        // TODO Auto-generated method stub
        endlessBackLoopFinder.analyze(block);
    }

    public void visitIf(Block block) {
        // TODO Auto-generated method stub
        ifFinder.analyze(block);
    }

    public void visitLoop(Block block) {
        // TODO Auto-generated method stub
        loopFinder.analyze(block);
    }

    public void visitSwitch(Block block) {
        // TODO Auto-generated method stub
        switchFinder.analyze(block);
    }

    public void visitTryCatch(Block block, ExceptionTable table) {
        // TODO Auto-generated method stub
        tryCatchFinder = new TryCatchFinder(table);
        tryCatchFinder.analyze(block);
    }

}
