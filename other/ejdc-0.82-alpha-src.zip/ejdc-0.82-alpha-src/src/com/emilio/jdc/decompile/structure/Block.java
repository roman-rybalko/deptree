package com.emilio.jdc.decompile.structure;

import java.util.List;

import com.emilio.jdc.core.attribute.LocalVariableTable;
import com.emilio.jdc.core.attribute.MethodContext;
import com.emilio.jdc.core.operation.expr.Expression;

/**
 * 
 * @author Emilio Liang
 * 
 * Interface for code block
 *
 */
public interface Block extends CodeStruct, Expression, PreProcess, PostProcess,
        Iterable<CodeStruct> {
    public static final Block ROOT = null;

    public CodeStruct getFirstOperation();

    public CodeStruct getLastOperation();

    public CodeStruct removeLastOperation();

    public CodeStruct removeFirstOperation();

    public CodeStruct removeOperation(int startByte);

    public CodeStruct getOperationAfter(int startByte);

    public CodeStruct getOperationBefore(int startByte);

    public CodeStruct getOperationByStartByte(int startByte);

    public void setOperations(List<CodeStruct> list);

    public void setFakeStartByte(int fakeStartByte);

    // public void replaceCurrentOperation(CodeStruct op);
    public void replaceOperation(int start_byte, CodeStruct newop);

    public List<CodeStruct> createSubBlock(int startOp, int endOp, Block block);

    public List<CodeStruct> getOperations();

    public void addOperation(int index, CodeStruct op);

    public void truncate(int fromByteIndex);

    public Block getParent();

    void setParent(Block block);

    public int size();

    public void postAnalyze(Block block);

    public void preAnalyze(Block block);

    public void postCreate();

    public void postProcess();

    public LocalVariableTable getLocalVariableTable();

    public MethodContext getMethodContext();

    public MethodContext getCurrentMethodContext();

    public String toText();

}
