package com.emilio.jdc.gui;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.prefs.Preferences;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;

import com.emilio.jdc.core.Class;
import com.emilio.jdc.core.exception.ClassException;
import com.emilio.jdc.core.exception.UnsupportedTypeException;
import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.operation.expr.ListExpression;
import com.emilio.jdc.core.type.ClassElemType;
import com.emilio.jdc.gui.view.ClassView;
import com.emilio.jdc.gui.view.FieldView;
import com.emilio.jdc.gui.view.MethodView;

/**
 * 
 * @author Emilio Liang
 *
 * Main class to start application UI.
 * 
 */
public class MainUI implements TreeSelectionListener,ActionListener{
    private static final String LAST_OPENED_DIR = "LAST_OPENED_DIR";
    
    private JFrame frame;
    private JScrollPane leftPane;
    private JScrollPane rightPane;
    private JTree tree;
    private JTextArea text;
    private JTable table;
    private JMenuItem deompiler;
    private JMenuItem byteCode;
    private JButton decompileButton;
    private JSplitPane splitPane;
    private File lastOpenedDir;
    private Class thisClass;
    
    private enum MenuType{
        FILE("File"),        
        OPEN("Open"),
        EXIT("Exit"),
        DECOMPILE("Decompile"),
        BYTECODE("ByteCode"),
        HELP("Help");
        
        public final String NAME;
        
        private MenuType(String title){
            this.NAME = title;
        }
        
        public static MenuType fromString(String name){
            return valueOf(name.toUpperCase());
        }
        
        @Override
        public String toString(){
            return NAME;
        }
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        MainUI frame = new MainUI();
        frame.initUI();
    }
    
    /**
     * 
     */
    private void initUI(){
        // Create the frame
        String title = "JavaDeCompiler";
        frame = new JFrame(title);
        
        // Set to exit on close
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.getContentPane().add(buildSplitPane(), BorderLayout.CENTER);
        frame.getContentPane().add(buildToolBar(), BorderLayout.NORTH);
        
        frame.setJMenuBar(buildMenuBar());

        // Show the frame
        frame.setSize(450, 600);
        frame.setVisible(true);
    }

    /**
     * 
     * @return
     */
    private JComponent buildSplitPane(){
        DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode("The Java Series");
         
        tree = new JTree(rootNode);
        tree.setRootVisible(false);
        //tree.setCellRenderer(new ClassTreeRenderer());
        tree.addTreeSelectionListener(this);
        
        text = new JTextArea("Wellcome to EJDC...");
        table = new JTable();
        
        // Create a component to add to the frame
        leftPane = new JScrollPane(tree);
        rightPane = new JScrollPane(table) ;
        
        //table.setTableHeader(null);
        //rightPane.setColumnHeaderView(null);
        
        splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPane, rightPane);
        
        // Add the component to the frame's content pane;
        // by default, the content pane has a border layout
        splitPane.setOneTouchExpandable(true);
        splitPane.setDividerLocation(150);
        
        return splitPane;
    }

    /**
     * 
     * buildToolBar
     * 
     * @return JComponent
     */
    private JComponent buildToolBar(){
        // Create a vertical tool bar
        JToolBar toolbar = new JToolBar(null, JToolBar.HORIZONTAL);

        toolbar.setFloatable(false);
        toolbar.setRollover(true);

        // Get icon
        ImageIcon runIcon = new ImageIcon("images/run.png");
        runIcon.setImage(runIcon.getImage().getScaledInstance(24,24,Image.SCALE_DEFAULT)); 

        decompileButton = new JButton(runIcon);
        decompileButton.setMargin(new Insets(0, 0, 0, 0));
        decompileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Decompile.....", "Notice",
                        JOptionPane.INFORMATION_MESSAGE);
                decompile();
            }
        });
        toolbar.add(decompileButton);
        decompileButton.setEnabled(false);
        
        
        ImageIcon helpIcon = new ImageIcon("images/help.png");
        helpIcon.setImage(helpIcon.getImage().getScaledInstance(24,24,Image.SCALE_DEFAULT));
        
        // Add a toggle button; remove the label and margin before adding
        JButton helpButton = new JButton(helpIcon);
        helpButton.setMargin(new Insets(0, 0, 0, 0));
        helpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Help.....", "Notice",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        toolbar.add(helpButton);
        
        
        return toolbar;
    }
    
    /**
     * 
     * buildMenuBar
     * 
     * @return JMenuBar
     */
    private JMenuBar buildMenuBar(){
        // Create a menu bar
        JMenuBar menuBar = new JMenuBar();
                
        menuBar.add(buildFileMenu());
        menuBar.add(buildOperationMenu());
        menuBar.add(buildHelpMenu());
        
        return menuBar;
    }
    
    /**
     * buildFileMenu
     * 
     * @return JComponent fileMenu
     */
    private JComponent buildFileMenu(){
        // Create a menu
        JMenu fileMenu = new JMenu(MenuType.FILE.NAME);
        
        // Add a menu item
        JMenuItem openItem = new JMenuItem(MenuType.OPEN.NAME);
        openItem.addActionListener(this);
        fileMenu.add(openItem);

        // Add separator
        fileMenu.add(new JSeparator());
        
        // Add another menu item
        JMenuItem exitItem = new JMenuItem(MenuType.EXIT.NAME);
        exitItem.addActionListener(this);
        fileMenu.add(exitItem);
        
        return fileMenu;
    }

    /**
     * buildHelpMenu
     * 
     * @return JComponent help menu
     */
    private JComponent buildHelpMenu(){
        // Create a menu
        JMenu helpMenu = new JMenu(MenuType.HELP.NAME);        
        
        JMenuItem helpItem = new JMenuItem(MenuType.HELP.NAME);
        helpItem.addActionListener(this);

        helpMenu.add(helpItem);
        
        return helpMenu;
    }
    
    /**
     * buildOperationMenu
     * 
     * @return JComponent 
     */
    private JComponent buildOperationMenu(){
        // Create a menu
        JMenu opMenu = new JMenu("Operation");        
        
        deompiler = new JMenuItem(MenuType.DECOMPILE.NAME);
        deompiler.setEnabled(false);
        deompiler.addActionListener(this);

        byteCode = new JMenuItem(MenuType.BYTECODE.NAME);
        byteCode.setEnabled(false);
        byteCode.addActionListener(this);
        
        opMenu.add(deompiler);
        opMenu.add(byteCode);
        
        return opMenu;
    }
    
    /**
     * 
     * @param classElements
     * @return TreeModel
     */
    private TreeModel buildTreeModel(Map<ClassElemType, Object> classElements){
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Root");
        
        for (ClassElemType type : ClassElemType.values()){
            Object value = classElements.get(type);
            if(value instanceof ListExpression){
                DefaultMutableTreeNode newChild = new DefaultMutableTreeNode(value);
                root.add(newChild);
                ListExpression list = (ListExpression)value;
                for(Expression expr : list.listExpressions()){
                    newChild.add(new DefaultMutableTreeNode(expr));
                }
            }else{
                root.add(new DefaultMutableTreeNode(value));
            }

        }
        
        return new DefaultTreeModel(root);
    }

    /**
     * actionPerformed implements ActionListener
     * @param e
     */
    public void actionPerformed(ActionEvent e){
        switch(MenuType.fromString(e.getActionCommand())){
            case OPEN:
                openFile();
                break;
            case EXIT:
                System.exit(0);
                break;
            case DECOMPILE:
                JOptionPane.showMessageDialog(frame, "Decompile.....", "Notice",JOptionPane.INFORMATION_MESSAGE);
                decompile();
                break;
            case BYTECODE:
                JOptionPane.showMessageDialog(frame, "ByteCode.....", "Notice",JOptionPane.INFORMATION_MESSAGE);
                toByteCode();
                break;            
            case HELP:
                JOptionPane.showMessageDialog(frame, "Help.....", "Notice",
                        JOptionPane.INFORMATION_MESSAGE);
                break;
            default:
                throw new UnsupportedOperationException();
             
        }
    }
       
    
    /**
     * valueChanged implements TreeSelectionListener
     * @param e
     */
    public void valueChanged(TreeSelectionEvent e) {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)
                           tree.getLastSelectedPathComponent();
        Object value = node.getUserObject();
        
        if ( value instanceof Expression){
            Expression expr = (Expression)value;
            text.setText(expr.toText());
            rightPane.setViewportView(text);
        }else if (value instanceof ListExpression){
            ListExpression exprList = (ListExpression)value;
            
            rightPane.setViewportView(table);

            DefaultTableModel model = new DefaultTableModel(buildTableData(exprList.listExpressions()), buildTableColumn());
            table.setModel(model); 
//          table.repaint();
//          table.updateUI();

        }else{
            throw new UnsupportedTypeException("not support node :"+node.getUserObject());
        }
        
        text.setText(node.getUserObject().toString());

        //if (node == null) return;

        //Object nodeInfo = node.getUserObject();
//        if (node.isLeaf()) {
//            BookInfo book = (BookInfo)nodeInfo;
//            displayURL(book.bookURL);
//            if (DEBUG) {
//                System.out.print(book.bookURL + ":  \n    ");
//            }
//        } else {
//            displayURL(helpURL); 
//        }
//        if (DEBUG) {
//            System.out.println(nodeInfo.toString());
//        }
    }
    
    /**
     * buildTableData
     * @param list
     * @return Vector<Vector<Expression>> 
     */
    private Vector<Vector<Expression>> buildTableData(List<Expression> list){
        Vector<Vector<Expression>> data = new Vector<Vector<Expression>>();
        
        for(Expression expr : list){
            Vector<Expression> vect = new Vector<Expression>();
            vect.add(expr);
            data.add(vect);
        }
        
        return data;
    }
    
    /**
     * buildTableColumn
     * @return Vector<String> 
     */
    private Vector<String> buildTableColumn(){
        Vector<String> columns = new Vector<String>();

        columns.addElement("Title");
        
        return columns;
    }
    
    /**
     * openFile
     */
    private void openFile() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileFilter() {

            public boolean accept(File pathname) {
                return pathname.getName().endsWith(".class")
                        || pathname.isDirectory();
            }

            public String getDescription() {
                return "Java class files";
            }
        });
        
        if (lastOpenedDir != null) {
            chooser.setCurrentDirectory(lastOpenedDir);
        }else{
            String lastOpened = getPrefs(LAST_OPENED_DIR);
            if(lastOpened != null){
                chooser.setCurrentDirectory(new File(lastOpened));
            }
        }

        int returnVal = chooser.showOpenDialog(frame);
        
                
        if (returnVal != JFileChooser.APPROVE_OPTION) {
            JOptionPane.showMessageDialog(frame, "No class selected",
                    "Exiting...", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        lastOpenedDir = chooser.getSelectedFile().getParentFile();
        
        putPrefs(LAST_OPENED_DIR,lastOpenedDir.getAbsolutePath());

        try {
            thisClass = new Class();
            thisClass.load(chooser.getSelectedFile());
        } catch (ClassException ce) {
            JOptionPane.showMessageDialog(frame, ce.toString(),
                    "Clazz Exception", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(frame, ioe.toString(),
                    "Input/Output Exception", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        frame.setTitle(thisClass.getClassInfo().getThisClass().getName());
        
        enableOperationMenu();
        
        tree.setModel(buildTreeModel(thisClass.getClassElements()));
        
        //decompileMenuItem.setEnabled(true);
        //tree.setModel(new ClazzTreeUI(this.clazz).getTreeModel());
        //tree.setSelectionRow(0);
        //pack();
    }
    
    /**
     * enableOperationMenu
     */
    private void enableOperationMenu(){
        deompiler.setEnabled(true);
        byteCode.setEnabled(true);
        decompileButton.setEnabled(true);
    }

    /**
     * 
     */
    private void decompile(){
        ClassView clas = new ClassView.Builder(thisClass.getClassInfo())
        .buildFields(new FieldView(thisClass.getFieldInfo()))
        .buildMethods(new MethodView(thisClass.getMethodInfo())).build();
                
        text.setText(clas.toSource());
        rightPane.setViewportView(text);
        
    }
    
    /**
     * 
     */
    private void toByteCode(){
        ClassView clas = new ClassView.Builder(thisClass.getClassInfo())
        .buildFields(new FieldView(thisClass.getFieldInfo()))
        .buildMethods(new MethodView(thisClass.getMethodInfo())).build();
                
        text.setText(clas.toText());
        rightPane.setViewportView(text);
    }
    
    /**
     * 
     * @param key
     * @param value
     */
    private void putPrefs(String key, String value){
        Preferences prefs = Preferences.userNodeForPackage(this.getClass());
        prefs.put(key, value);
    }
    
    /**
     * 
     * @param key
     * @return
     */
    private String getPrefs(String key){
        Preferences prefs = Preferences.userNodeForPackage(this.getClass());
        return prefs.get(key, null);
    }
}
