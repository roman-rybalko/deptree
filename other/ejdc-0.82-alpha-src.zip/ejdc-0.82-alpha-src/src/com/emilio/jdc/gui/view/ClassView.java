package com.emilio.jdc.gui.view;

import java.util.List;
import java.util.Set;

import com.emilio.jdc.core.ClassInfo;
import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.operation.expr.Source;
import com.emilio.jdc.core.type.access.ClassAccFlagType;

/**
 * 
 * @author Emilio Liang
 *
 */
public class ClassView implements Expression, Source{
    private FieldView fieldView;
    private MethodView methodView;
    private ClassInfo classInfo;
    
    /**
     * Constructor
     * @param builder
     */
    private ClassView(Builder builder) {
        methodView = builder.methodView;
        fieldView =  builder.fieldView;
        classInfo = builder.classInfo;
    }
    /**
     * @return String
     */
    public String toText(){
        StringBuilder text = new StringBuilder();
        
        text.append(fieldView.toText());
        text.append(methodView.toText());
        
        return text.toString();
    }
    
    /**
     * @return String
     */
    public String toSource(){
        StringBuilder source = new StringBuilder();

        source.append(buildHeader());
        source.append(fieldView.toSource());
        source.append(methodView.toSource());
        source.append(buildTailer());
        
        return source.toString();
    }
    
    /**
     * 
     * @param classInfo
     * @return String
     */
    private String buildHeader(){
        StringBuilder header = new StringBuilder();
        
        Set<ClassAccFlagType> set = classInfo.getAccFlagSet();
        if(set.contains(ClassAccFlagType.PUBLIC)){
        	header.append("public");
        }else if(set.contains(ClassAccFlagType.FINAL)){
        	header.append("final");        	
        }else if(set.contains(ClassAccFlagType.ABSTRACT)){
        	header.append("abstract");        	
        }else if(set.contains(ClassAccFlagType.INTERFACE)){
        	header.append("interface");        	
        }
        
        header.append(BLANK_SPACE);
        header.append(classInfo.getThisClass().getName());
        header.append(BLANK_SPACE);
        
        if(!classInfo.getSuperClass().equals("java.lang.Object")){
        	header.append("extends ");
        	header.append(classInfo.getSuperClass().getName());
        }
        
        List<String> interfaceNames = classInfo.getInterfaceNames();
        
        if(interfaceNames.size() > 0){
        	header.append(" implements ");
        	for(int i =0 ;i < interfaceNames.size() ;++i){
        		header.append(interfaceNames.get(i));
        		if(i != interfaceNames.size() -1){
            		header.append(", ");
        		}
        	}
        }
        
        header.append(" {");
        header.append(LINE_SEPARATOR);
        
        return header.toString();
    }
    
    /**
     * 
     * @return
     */
    private String buildTailer(){
    	return "}".concat(LINE_SEPARATOR);
    }

    /**
     * 
     * Internal builder class for 
     *
     */
    public static class Builder {
    	private ClassInfo classInfo;
        private FieldView fieldView;
        private MethodView methodView;
       
        public Builder(ClassInfo classInfo){
        	this.classInfo = classInfo;
        }
        
        /**
         * 
         * @param fieldView
         * @return Builder
         */
        public Builder buildFields(FieldView fieldView) {
            this.fieldView = fieldView;
            return this;
        }

        /**
         * 
         * @param methodView
         * @return Builder
         */
        public Builder buildMethods(MethodView methodView) {
            this.methodView = methodView;
            return this;
        }
        
        public ClassView build(){
            return new ClassView(this);
        }
    }
}
