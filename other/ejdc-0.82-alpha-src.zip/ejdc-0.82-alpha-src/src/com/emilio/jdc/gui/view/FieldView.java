package com.emilio.jdc.gui.view;

import com.emilio.jdc.core.FieldInfo;
import com.emilio.jdc.core.FieldInfoItem;
import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.operation.expr.Source;

/**
 * 
 * @author Emilio Liang
 *
 */
public class FieldView implements Expression, Source{
    private FieldInfo field;
    
    /**
     * Constructor
     * @param field
     */
    public FieldView(FieldInfo field){
        this.field = field;
    }
    
    /**
     * 
     * @param String
     */
    public String toText() {
        StringBuilder text = new StringBuilder();
        for (Expression expr : field.listExpressions()){
            text.append(expr.toText());
        }
        
        text.append(LINE_SEPARATOR);
        
        return text.toString();
    }
    
    /**
     * @return String
     */
    public String toSource(){
    	StringBuilder source = new StringBuilder();
		
    	for(FieldInfoItem item : field.getList()){
    		source.append(item.toText());
    	}
    	
    	source.append(LINE_SEPARATOR);
    	
    	return source.toString();	
    }
    
}
