package com.emilio.jdc.gui.view;

import com.emilio.jdc.core.FieldDescriptor;
import com.emilio.jdc.core.MethodDescriptor;
import com.emilio.jdc.core.MethodInfo;
import com.emilio.jdc.core.MethodInfoItem;
import com.emilio.jdc.core.ReturnDescriptor;
import com.emilio.jdc.core.operation.expr.Expression;
import com.emilio.jdc.core.operation.expr.Source;
import com.emilio.jdc.core.type.access.MethodAccFlagType;

/**
 * 
 * @author Emilio Liang
 *
 */
public class MethodView implements Expression, Source{
    private MethodInfo method;
    
    /**
     * Constructor
     * @param method
     */
    public MethodView(MethodInfo method){
        this.method = method;
    }
    
    /**
     * 
     * @param string
     */
    public String toText() {
        StringBuilder text = new StringBuilder();
        for (Expression expr : method.listExpressions()){
            text.append(expr.toText());
        }
        
        return text.toString();
    }
    
    /**
     * @return string
     */
    public String toSource(){
    	StringBuilder source = new StringBuilder();
    	
    	for(MethodInfoItem item : method.getList()){
        	source.append(toHeader(item));
    		source.append(item.getCode().decompile());
    		source.append(toTailer());
    	}
    	
    	return source.toString();	
    }
    
    /**
     * 
     * @param item
     * @return
     */
    private String toHeader(MethodInfoItem item){
    	StringBuilder methodHead  = new StringBuilder();
    	
        for (MethodAccFlagType accFlag : item.getAccFlagSet()) {
        	methodHead.append(accFlag);
        	methodHead.append(BLANK_SPACE);
        }
        
        MethodDescriptor methodDesc = item.getMethodDesc();
        
        ReturnDescriptor retType = methodDesc.getReturnType();
        
        methodHead.append(retType.toText());
        methodHead.append(BLANK_SPACE);
        methodHead.append(item.getMethodName());
        methodHead.append(LEFT_PARENTHESIS);
        
        for(int i = 0; i < methodDesc.getParameters().size() ;i++){
            FieldDescriptor fd = methodDesc.getParameters().get(i);
            methodHead.append(fd.toText());
            if (i != methodDesc.getParameters().size() -1){
            	methodHead.append(" ,");
            }
        }

        methodHead.append(") {");
        methodHead.append(LINE_SEPARATOR);
        
    	return methodHead.toString();
    }

    /**
     * 
     * @return String
     */
    private String toTailer(){
    	return "}".concat(LINE_SEPARATOR).concat(LINE_SEPARATOR);
    }

}
