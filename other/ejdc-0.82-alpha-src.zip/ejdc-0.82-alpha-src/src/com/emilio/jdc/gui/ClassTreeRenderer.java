package com.emilio.jdc.gui;

import java.awt.Component;

import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellRenderer;

/**
 * 
 * @author Emilio Liang
 *
 */
public class ClassTreeRenderer extends DefaultTreeCellRenderer implements TreeCellRenderer {
    //private final DefaultTreeCellRenderer render = new DefaultTreeCellRenderer();

    /**
     * 
     */
    private static final long serialVersionUID = -1596718926531376659L;

    public Component getTreeCellRendererComponent(JTree tree, Object value,
            boolean sel, boolean expanded, boolean leaf, int row,
            boolean hasFocus) {
        //TODO implements
        //DefaultTreeCellRenderer render = (DefaultTreeCellRenderer)tree.getCellRenderer();

        //render.setEnabled(true);
        return super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
    }
}
