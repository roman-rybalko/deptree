package com.emilio.jdc.func.ok;
public class ArrayInitEmpty {

    //OK
    public static void main(String [] args) {
        int [] i = {};
    }
}
