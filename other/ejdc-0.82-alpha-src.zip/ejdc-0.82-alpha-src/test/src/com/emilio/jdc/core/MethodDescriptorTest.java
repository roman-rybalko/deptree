package com.emilio.jdc.core;

import org.junit.Test;

public class MethodDescriptorTest {

    @Test
    public void testParse() {
        MethodDescriptor m1 = new MethodDescriptor();
        m1.parse("([[Lru/andrew/jclazz/core/constants/CONSTANT_Utf8;[[Lru/andrew/jclazz/core/Clazz;)I");
        
        MethodDescriptor m2 = new MethodDescriptor();
        m2.parse("");
    }
}
