package com.emilio.jdc.core.type;

import org.junit.Test;

public class AttributeTypeTest {

    @Test
    public void testGetAttributeType() {
        String attrTyps[] = new String[]{
        "SourceFile",
        "ConstantValue",
        "Code",
        "ExceptionTableEntry",
        "InnerClasses",
        "EnclosingMethod",
        "Synthetic",
        "Signature",
        "SourceDebugExtension",
        "LineNumberTable",
        "LocalVariableTable",
        "LocalVariableTypeTable",
        "DeprecatedAttribute",
        "RuntimeVisibleAnnotations",
        "RuntimeInvisibleAnnotations",
        "RuntimeVisibleParameterAnnotations",
        "RuntimeInvisibleParameterAnnotations",
        "AnnotationDefault",
        "StackMapTable"};

    }

}
