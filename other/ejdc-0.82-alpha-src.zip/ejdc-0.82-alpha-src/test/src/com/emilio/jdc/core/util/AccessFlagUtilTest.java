package com.emilio.jdc.core.util;

import java.util.Set;

import junit.framework.Assert;

import org.junit.Test;

import com.emilio.jdc.core.type.access.AccessFlagTypeUtil;
import com.emilio.jdc.core.type.access.MethodAccFlagType;

public class AccessFlagUtilTest {

	@Test
	public void testCreateAccFlagSet() {
		int accessFlag = 0;
		
		for(MethodAccFlagType methodAccFlag:MethodAccFlagType.values()){
			accessFlag  = accessFlag | methodAccFlag.getAccessFlag();
		}
		
		Set<MethodAccFlagType> set = AccessFlagTypeUtil.ofAccFlagSet(MethodAccFlagType.class,accessFlag);
		Assert.assertNotNull(set);
		
		for(MethodAccFlagType methodAccFlag:MethodAccFlagType.values()){
			Assert.assertTrue(set.contains(methodAccFlag));
		}
	}

}
