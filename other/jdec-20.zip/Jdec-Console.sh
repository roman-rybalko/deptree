exec java -cp .:jdec20.jar net.sf.jdec.main.ConsoleLauncher
