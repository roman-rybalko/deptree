export PATH=`pwd`/dex2jar-0.0.9.7:`pwd`/jad158e:`pwd`/AXMLPrinter:`pwd`/smali:`pwd`/arm-eabi-toolchain:$PATH
export SMALI_BOOTCLASSPATH_DIR=`pwd`/../fs/framework
export SMALI_BOOTCLASSPATH=:am.jar:android.policy.jar:android.test.runner.jar:bmgr.jar:bouncycastle.jar:com.android.future.usb.accessory.jar:com.android.location.provider.jar:com.cequint.platform.jar:com.google.android.maps.jar:com.samsung.device.jar:core-junit.jar:core.jar:ext.jar:framework.jar:ime.jar:input.jar:javax.obex.jar:monkey.jar:pm.jar:sec_feature.jar:sec_platform_library.jar:seccamera.jar:sechardware.jar:secmediarecorder.jar:services.jar:sqlite-jdbc.jar:svc.jar:twframework.jar
export SMALI_APILVL=10
